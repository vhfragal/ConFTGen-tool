package experiments;

import java.util.ArrayList;
import java.util.Random;

import org.junit.Test;

import br.usp.icmc.feature.logic.FFSMProperties;
import br.usp.icmc.feature.logic.FSMProperties;
import br.usp.icmc.ffsm.Cond_in_seq;
import br.usp.icmc.ffsm.FFSM;
import br.usp.icmc.ffsm.FTransition;
import br.usp.icmc.fsm.common.FileHandler;
import br.usp.icmc.fsm.common.TestSuite;
import br.usp.icmc.model_gen.FFSMModel;
import br.usp.icmc.model_gen.FFeatureModel;

public class part1
{
	
	//most transitions should be part of the core and then a few are specific
	String[] features = {"A","B","C","D","E","F","G","H","I","J",
			"A1","B1","C1","D1","E1","F1","G1","H1","I1","J1",
			"true","true","true","true","true","true","true","true","true","true",
			"true","true","true","true","true","true","true","true","true","true",
			"true","true","true","true","true","true","true","true","true","true",
			"true","true","true","true","true","true","true","true","true","true"};
	String[] only_features = {"A","B","C","D","E","F","G","H","I","J",
			"A1","B1","C1","D1","E1","F1","G1","H1","I1","J1"};
	String[] inputs = {"a","b","c","d","e","f","g","h","i","j",
			"a1","b1","c1","d1","e1","f1","g1","h1","i1","j1",
			"a3","b3","c3","d3","e3","f3","g3","h3","i3","j3",
			"a4","b4","c4","d4","e4","f4","g4","h4","i4","j4",
			"a2","b2","c2","d2","e2","f2","g2","h2","i2","j2"};
			
	boolean islog;
	boolean isplog;
	boolean debug;
	boolean pop_file;
	
	String path;		
	int iterations;
	
	int max_states;
	int min_states;
	int max_inputs;
	int min_inputs;
	int max_outputs;
	int min_outputs;
		
	String exp_folder;
	String folder;
	String ffsm_folder; 
	String fsm_folder;
	String fm_folder;	
	String ffsm_state_suite_folder; 
	String ffsm_transition_suite_folder; 
	String ffsm_full_suite_folder;
	String fsm_pruned_state_suite_folder; 
	String fsm_pruned_transition_suite_folder; 
	String fsm_pruned_full_suite_folder;
	String fsm_derived_full_suite_folder;
	String lpath;

	@Test
	public void gen_random_experiment_1() throws Exception	{
		
		islog = false;
		isplog = true;
		debug = false;
		pop_file = false;
		
		path = "";		
		iterations = 10;
		
		max_states = 10;
		min_states = 5;
		max_inputs = 10;
		min_inputs = 5;
		max_outputs = 10;
		min_outputs = 5;
		
		exp_folder = "experiments_1";
		folder = "./../../../../Documents/"+exp_folder+"/temp/";
		ffsm_folder = "./../../../../Documents/"+exp_folder+"/ffsm/";
		fsm_folder = "./../../../../Documents/"+exp_folder+"/fsm_core/";		
		fm_folder = "./../../../../Documents/"+exp_folder+"/fm/";	
		ffsm_state_suite_folder = "./../../../../Documents/"+exp_folder+"/ffsm/suite/state/";
		ffsm_transition_suite_folder = "./../../../../Documents/"+exp_folder+"/ffsm/suite/transition/";
		ffsm_full_suite_folder = "./../../../../Documents/"+exp_folder+"/ffsm/suite/full/";
		fsm_pruned_state_suite_folder = "./../../../../Documents/"+exp_folder+"/fsm_core/suite/pruned/state/";
		fsm_pruned_transition_suite_folder = "./../../../../Documents/"+exp_folder+"/fsm_core/suite/pruned/transition/";
		fsm_pruned_full_suite_folder = "./../../../../Documents/"+exp_folder+"/fsm_core/suite/pruned/full/";
		fsm_derived_full_suite_folder = "./../../../../Documents/"+exp_folder+"/fsm_core/suite/derived/full/";
		lpath = "./../../../../Documents/"+exp_folder+"/logs/log_FFSM.txt";
		
		call_random_part();
	}
	
	public void call_random_part() throws Exception	{
		
		FileHandler fh = new FileHandler();		
		Random ran = new Random();
	
		int state_seed = max_states - min_states;
		int input_seed = max_inputs - min_inputs;
		int output_seed = max_outputs - min_outputs;
		
		String log = "";
		String statelog = "states1 = c(";
		String tranlog = "transitions1 = c(";
	    String timelog = "check_FFSM_time1 = c(";
		String timefsmlog = "check_FSM_time1 = c(";
		String timegenlog = "gen_FFSM_time1 = c(";
		String timefsmgenlog = "gen_FSM_time1 = c(";
		String size_hsilog = "size_pruned_HSI_suite1 = c(";
		String size_derived_hsilog = "size_derived_HSI_suite1 = c(";
		String size_ffsm_hsilog = "size_FFSM_HSI_suite1 = c(";
		String size_fsm_hsilog = "size_FSM_HSI_suite1 = c(";
	    
	    if(isplog) log = log.concat("---------------------------------------\n");
		if(isplog) log = log.concat("FFSM INFO...\n");
		if(isplog) log = log.concat("Number of machines generated: "+iterations+"\n");
		if(isplog) log = log.concat("States: "+min_states+"-"+max_states+"\n");
		if(isplog) log = log.concat("Inputs: "+min_inputs+"-"+max_inputs+"\n");
		if(isplog) log = log.concat("Outputs: "+min_outputs+"-"+max_outputs+"\n");
		if(isplog) log = log.concat("Transitions: "+(min_states*min_inputs)+"-"+(max_states*max_inputs)*2+"\n");
		if(isplog) log = log.concat("OBS. We randomize the number of transitions"
				+ ", and attempt to generate this amount without breaking the FFSM determinism property.\n"
				+ "After generated the FFSM is checked for initially connected and minimal properties.\n"
				+ "Moreover, most of states and transitions are part of the core specification as in an SPL.\n"
				+ "If the FFSM is valid, then we store this model and generate the next, otherwise we ignore it.\n\n");
		
		if(isplog) log = log.concat("Feature Model INFO...\n");
		if(isplog) log = log.concat("Fixed number of non-mandatory features: "+only_features.length+"\n");
		if(isplog) log = log.concat("Random type of features: optional, alternativeXOR, alternativeOR \n");
		if(isplog) log = log.concat("Random tree structure: each node has a random number of childs\n");
		if(isplog) log = log.concat("OBS. 1/3 of the states and transitions have a feature as a condition.\n"
				+ "Here we assume an SPL where 2/3 of the elements are part of the core architecture.\n\n");
		
		if(isplog) log = log.concat("Model Mapping INFO...\n");
		if(isplog) log = log.concat("If both FFSM and Feature Model have the same name, then they are binded\n\n");
		
		if(isplog) log = log.concat("Model Derivation INFO...\n");
		if(isplog) log = log.concat("Each FSM derived is the core model where only the root feature is included\n");
		if(isplog) log = log.concat("1 - check (F)FSM time: The time spent to check determinism, init. connect., and minimal "
				+ "for the FFSM or all FSMs configurations \n");
		if(isplog) log = log.concat("2 - gen (F)FSM time: The time spent to generate HSI suites "
				+ "for the FFSM or all FSMs configurations \n");
		if(isplog) log = log.concat("OBS. The time for FSMs is the time to check/gen for the base(core) model times the number of "
				+ "configurations\n");
		if(isplog) log = log.concat("3 - size pruned HSI suite: The size of the HSI suite pruned from the HSI suite of the FFSM \n");
		if(isplog) log = log.concat("4 - size derived HSI suite: The size of the HSI suite for the FSM derived \n");
		if(isplog) log = log.concat("OBS. The size of each HSI suite may vary for FFSM and a core FSM.\n"
				+ "The harmonized sets Hi for each state Si may vary on each single FSM after the reduction from the W set."
				+ "\n However, the Hi sets are constant for an FFSM. Thus, every derived FSM has a pre-established Hi set from the FFSM.\n\n");
		
		
		//gen feature models
		FFSMModel gen = new FFSMModel();
    	FFeatureModel fm_gen = new FFeatureModel();
    	
    	//generate FFSMs	
		int i=1;
		while(i<=iterations){
			FFSMProperties p = new FFSMProperties(folder, islog, debug);
	    	//initialize the fm
			fm_gen.gen_single_FM_random(fm_folder, only_features, i);		
	    	String fm_path = fm_folder+"fm_"+i+".xml";			
			String header = p.read_XML_FeatureModel(fm_path);
			int fm_configs = gen.get_configs_for_ffsm_fm(p.get_fmroot());
			p.set_fm_header(header);
			
	    	//gen FFSM model
			path = ffsm_folder+"ffsm_"+i+".txt";
			int n_states = ran.nextInt(state_seed) + min_states;
			int n_inputs = ran.nextInt(input_seed) + min_inputs;
			int n_outputs = ran.nextInt(output_seed) + min_outputs;
			int min_transitions = (n_states * n_inputs);
			int max_transitions = (n_states * n_inputs)*2;
			int transition_seed = max_transitions - min_transitions;
			int n_transitions = ran.nextInt(transition_seed) + min_transitions;
		
			String result = "";			
			FFSM ffsm = p.create_random_FFSM(n_states, n_inputs, n_outputs,
					n_transitions, features, inputs);
			if(debug) System.out.println("GOT FFSM ");
			for(FTransition f : ffsm.getFTransitions()){
				result = result.concat(f.toString()+"\n");
			}
			long startTime = System.nanoTime();
			//check properties 
			if(p.is_valid_FFSM()){
				long stopTime = System.nanoTime();
			    long elapsedTime = stopTime - startTime;
			    elapsedTime = elapsedTime / 1000000;
			    timelog = timelog.concat(elapsedTime+",");
									
				fh.print_file(result, path);
				//if(debug)System.out.println(result);				
				if(isplog) log = log.concat("---------------------------------------\n");
				if(isplog) log = log.concat("Feature Model number: "+i+"\n");
				if(isplog) log = log.concat("Feature Model file: "+fm_path+"\n");
				if(isplog) log = log.concat("Feature Model number of configurations: "+fm_configs+"\n\n");
				if(isplog) log = log.concat("FFSM number: "+i+"\n");
				if(isplog) log = log.concat("FFSM file: "+path+"\n");
				if(isplog) log = log.concat("States: "+ffsm.getFStates().size()+"\n");
				if(isplog) log = log.concat("Inputs: "+ffsm.getInputAlphabet().size()+"\n");
				if(isplog) log = log.concat("Outputs: "+ffsm.getOutputAlphabet().size()+"\n");
				if(isplog) log = log.concat("Transitions: "+ffsm.getFTransitions().size()+"\n");
				
				//generate DOT files - state and transition cover							
		    	String dotpath = ffsm_folder+"ffsm_"+i+".dot";	    	
		    	gen.gen_dot_FFSM3(path, dotpath, pop_file);
		    	p.find_transition_cover_set();
		    	String dot_name = "suite_"+i;		    	
		    	p.gen_state_tree(ffsm_state_suite_folder, dot_name, pop_file);
		    	p.gen_transition_tree(ffsm_transition_suite_folder, dot_name, pop_file);
				
				//get distinguish sequences and build HSI		    	
		    	//if(debug)p.print_predecessor_table();	
		    	long startTimegen = System.nanoTime();					
				p.generate_W_set();			
				p.generate_hsi_table();
				p.gen_hsi();
				long stopTimegen = System.nanoTime();
			    long elapsedTimegen = stopTimegen - startTimegen;
			    elapsedTimegen = elapsedTimegen / 1000000;
			    timegenlog = timegenlog.concat(elapsedTimegen+",");
				
				//print suite files
				String state_suite = p.getStateSuite();
				String transition_suite = p.getTransitionSuite();
				String full_suite = p.getFullSuite();
				String state_suitepath = ffsm_state_suite_folder+"suite_"+i+".txt";
				String transition_suitepath = ffsm_transition_suite_folder+"suite_"+i+".txt";
				String full_suitepath = ffsm_full_suite_folder+"suite_"+i+".txt";
				fh.print_file(state_suite, state_suitepath);
				fh.print_file(transition_suite, transition_suitepath);
				fh.print_file(full_suite, full_suitepath);
				
				String full_ffsm_suites = ""; 
				String full_fsm_suites = ""; 				
				
				int att = 0;
				//derive FSM base - derivation operator
				for(int j=0; j<20; j++){
					int n_true = ran.nextInt(only_features.length)+1;
					ArrayList<String> choosen = new ArrayList<String>();
					for(int f=1; f<=n_true; f++){
						int s_true = ran.nextInt(only_features.length);
						if(!choosen.contains(only_features[s_true])){
							choosen.add(only_features[s_true]);
						}
					}
					
					String der_op = "(and ";				
					der_op = der_op.concat(only_features[0]+" ");
					if(j == 0){						
						for(int f=1; f<only_features.length; f++){
							der_op = der_op.concat("(not "+only_features[f]+") ");							
						}
					}else{
						for(int f=1; f<only_features.length; f++){
							if(choosen.contains(only_features[f])){
								der_op = der_op.concat(only_features[f]+" ");
							}else{
								der_op = der_op.concat("(not "+only_features[f]+") ");
							}
						}
					}					
					der_op = der_op.concat(")");
					if(debug)System.out.println("Derivation operator: "+der_op);
					if(!p.check_condition(der_op) && j > 0){
						att++;
						if(att < 1000)j--;
						continue;
					}
										
					//print pruned suites
					ArrayList<Cond_in_seq> suite = p.getStateSet();
					if(debug)System.out.println("Prune state cover suite");			
					String dstate_suite = p.derive_suite(suite, der_op);				
					String dstate_suitepath = fsm_pruned_state_suite_folder+"suite_"+i+"_"+j+".txt";
					fh.print_file(dstate_suite, dstate_suitepath);
					
					if(debug)System.out.println("Prune transition cover suite");
					suite = p.getTransitionSet();
					String dtransition_suite = p.derive_suite(suite, der_op);							
					String dtransition_suitepath = fsm_pruned_transition_suite_folder+"suite_"+i+"_"+j+".txt";
					fh.print_file(dtransition_suite, dtransition_suitepath);
					
					if(debug)System.out.println("Prune HSI suite");
					suite = p.getHSISet();				
					String dfull_suite = p.derive_suite(suite, der_op);							
					String dfull_suitepath = fsm_pruned_full_suite_folder+"suite_"+i+"_"+j+".txt";
					fh.print_file(dfull_suite, dfull_suitepath);
					full_ffsm_suites = full_ffsm_suites.concat(dfull_suite+"\n");
					
					//print derived FSM
					ArrayList<FTransition> transitions = ffsm.getFTransitions();
					String result_ffsm = p.derive_FSM_model(transitions, der_op);
					if(result_ffsm.equals("")) continue;
					String fsm_path = fsm_folder+"fsm_"+i+"_"+j+".txt";
					fh.print_file(result_ffsm, fsm_path);					    	
					String fsm_dotname = "fsm_"+i+"_"+j;
					String fsmdotpath = fsm_folder+"fsm_"+i+"_"+j+".dot";	 
			    	gen.gen_dot_derived_FSM(fsm_path, fsmdotpath, fsm_folder, fsm_dotname, pop_file);
			    			    	
			    	//check properties for derived FSM		    	
					FSMProperties pFSM = new FSMProperties(folder, islog, debug, fsm_path);
					startTime = System.nanoTime();
			    	boolean valid_FSM = pFSM.isvalid();
			    	stopTime = System.nanoTime();
				    elapsedTime = stopTime - startTime;
				    elapsedTime = (elapsedTime * fm_configs) / 1000000;
				    if(j == 0)timefsmlog = timefsmlog.concat(elapsedTime+",");
			    	if(!valid_FSM){
			    		if(isplog) log = log.concat("Invalid FSM fsm_model_"+i+"_"+j+".txt\n");
			    		System.out.println("Invalid FSM fsm_model_"+i+"_"+j+".txt\n");
			    	}
			    			    	
			    	//generate HSI for derived base		    	
			    	startTime = System.nanoTime();
			    	String derived_hsi = p.get_HSI_FSM(fsm_path);
			    	stopTime = System.nanoTime();
				    elapsedTime = stopTime - startTime;
				    elapsedTime = (elapsedTime * fm_configs) / 1000000;	
				    if(j == 0) timefsmgenlog = timefsmgenlog.concat(elapsedTime+",");
			    	String fsm_hsi_path = fsm_derived_full_suite_folder+"suite_"+i+"_"+j+".txt";
					fh.print_file(derived_hsi, fsm_hsi_path);
					full_fsm_suites = full_fsm_suites.concat(derived_hsi+"\n");
			    	
			    	//calculate size of suites
			    	TestSuite aux = new TestSuite();
			    	int full_suite_size = aux.new_test_size(dfull_suitepath);
			    	int derived_suite_size = aux.new_test_size(fsm_hsi_path);
			    	if(j == 0)size_hsilog = size_hsilog.concat(full_suite_size+",");
			    	if(j == 0)size_derived_hsilog = size_derived_hsilog.concat(derived_suite_size+",");
				}
				
				//size_fsm_hsilog
				String dfull_suitepath = fsm_pruned_full_suite_folder+"merged_suite_"+i+".txt";
				String fsm_hsi_path = fsm_derived_full_suite_folder+"merged_suite_"+i+".txt";
				int full_suite_size = p.get_FSM_suite_size(full_ffsm_suites,dfull_suitepath);
				int derived_suite_size = p.get_FSM_suite_size(full_fsm_suites,fsm_hsi_path);
				size_ffsm_hsilog = size_ffsm_hsilog.concat(full_suite_size+",");
				size_fsm_hsilog = size_fsm_hsilog.concat(derived_suite_size+",");
		    	
			    //print log			
				statelog = statelog.concat(ffsm.getFStates().size()+",");
				tranlog = tranlog.concat(ffsm.getFTransitions().size()+",");	
				
				
				statelog = statelog.substring(0,statelog.length()-1);
				tranlog = tranlog.substring(0,tranlog.length()-1);
				timelog = timelog.substring(0,timelog.length()-1);
				timefsmlog = timefsmlog.substring(0,timefsmlog.length()-1);
				timegenlog = timegenlog.substring(0,timegenlog.length()-1);
				timefsmgenlog = timefsmgenlog.substring(0,timefsmgenlog.length()-1);
				size_hsilog = size_hsilog.substring(0,size_hsilog.length()-1);
				size_derived_hsilog = size_derived_hsilog.substring(0,size_derived_hsilog.length()-1);
				size_ffsm_hsilog = size_ffsm_hsilog.substring(0,size_ffsm_hsilog.length()-1);
				size_fsm_hsilog = size_fsm_hsilog.substring(0,size_fsm_hsilog.length()-1);
				
				statelog = statelog.concat(")");
				tranlog = tranlog.concat(")");
				timelog = timelog.concat(")");
				timefsmlog = timefsmlog.concat(")");
				timegenlog = timegenlog.concat(")");
				timefsmgenlog = timefsmgenlog.concat(")");
				size_hsilog = size_hsilog.concat(")");
				size_derived_hsilog = size_derived_hsilog.concat(")");
				size_ffsm_hsilog = size_ffsm_hsilog.concat(")");
				size_fsm_hsilog = size_fsm_hsilog.concat(")");
				
				if(isplog) log = log.concat(statelog+"\n");
				if(isplog) log = log.concat(tranlog+"\n");				
		    	if(isplog) log = log.concat(timelog+"\n");
		    	if(isplog) log = log.concat(timefsmlog+"\n");
		    	if(isplog) log = log.concat(timegenlog+"\n");
		    	if(isplog) log = log.concat(timefsmgenlog+"\n");
		    	if(isplog) log = log.concat(size_hsilog+"\n");
		    	if(isplog) log = log.concat(size_derived_hsilog+"\n");
		    	if(isplog) log = log.concat(size_ffsm_hsilog+"\n");
		    	if(isplog) log = log.concat(size_fsm_hsilog+"\n");
		    	
		    	statelog = statelog.substring(0,statelog.length()-1);
				tranlog = tranlog.substring(0,tranlog.length()-1);
				timelog = timelog.substring(0,timelog.length()-1);
				timefsmlog = timefsmlog.substring(0,timefsmlog.length()-1);
				timegenlog = timegenlog.substring(0,timegenlog.length()-1);
				timefsmgenlog = timefsmgenlog.substring(0,timefsmgenlog.length()-1);
				size_hsilog = size_hsilog.substring(0,size_hsilog.length()-1);
				size_derived_hsilog = size_derived_hsilog.substring(0,size_derived_hsilog.length()-1);
				size_ffsm_hsilog = size_ffsm_hsilog.substring(0,size_ffsm_hsilog.length()-1);
				size_fsm_hsilog = size_fsm_hsilog.substring(0,size_fsm_hsilog.length()-1);
				
				statelog = statelog.concat(",");
				tranlog = tranlog.concat(",");
				timelog = timelog.concat(",");
				timefsmlog = timefsmlog.concat(",");
				timegenlog = timegenlog.concat(",");
				timefsmgenlog = timefsmgenlog.concat(",");
				size_hsilog = size_hsilog.concat(",");
				size_derived_hsilog = size_derived_hsilog.concat(",");
				size_ffsm_hsilog = size_ffsm_hsilog.concat(",");
				size_fsm_hsilog = size_fsm_hsilog.concat(",");
		    	
		    	
		    	//add W and HSI sets to log
		    	if(isplog) log = log.concat("W set for FFSM \n");
		    	if(isplog) log = log.concat(p.getPrintW()+"\n");
		    	if(isplog) log = log.concat("W set for FSM \n");
		    	if(isplog) log = log.concat(p.getPrintFSM_W()+"\n");
		    	if(isplog) log = log.concat("HSI set for FFSM \n");
		    	if(isplog) log = log.concat(p.getPrintHSI()+"\n");
		    	if(isplog) log = log.concat("HSI set for FSM \n");
		    	if(isplog) log = log.concat(p.getPrintFSM_HSI()+"\n");
		    			    			
				fh.print_file(log, lpath);
				
				//increment index
		    	i++;
			}else{
				if(debug) System.out.println("invalid FFSM "+"ffsm_"+i);
			}
		}
	}
}
