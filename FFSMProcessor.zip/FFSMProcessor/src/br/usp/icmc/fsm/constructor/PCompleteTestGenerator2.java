package br.usp.icmc.fsm.constructor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.usp.icmc.fsm.common.CostTuple;
import br.usp.icmc.fsm.common.DivergenceGraph;
import br.usp.icmc.fsm.common.FiniteStateMachine;
import br.usp.icmc.fsm.common.FsmCoverage;
import br.usp.icmc.fsm.common.HashList;
import br.usp.icmc.fsm.common.Pair;
import br.usp.icmc.fsm.common.Ruler;
import br.usp.icmc.fsm.common.Ruler.AddedTo;
import br.usp.icmc.fsm.common.State;
import br.usp.icmc.fsm.common.TestSequence;
import br.usp.icmc.fsm.common.TestSet;
import br.usp.icmc.fsm.common.Transition;
import br.usp.icmc.fsm.constructor.CharacterizationSetConstructor;

public class PCompleteTestGenerator2 {
	private static Logger logger = Logger.getAnonymousLogger();
	private FiniteStateMachine fsm;
	private ArrayList<String> initialTestSet;
	private ArrayList<String> finalTestSet;
	private int p;
	private ArrayList<String> W;
	private Ruler ruler;
	private ArrayList<String> CunionK;
	private ArrayList<String> Relative;
	private ArrayList<String> K_old;
	
	HashMap<String, ArrayList<String[]>> ret2 = new HashMap<String, ArrayList<String[]>>();
	
	HashMap<String, ArrayList<String>> C_data = new HashMap<String, ArrayList<String>>();
	HashMap<String, ArrayList<String>> D_data = new HashMap<String, ArrayList<String>>();
	
	Map<String, ArrayList<String>> C = new HashMap<String, ArrayList<String>>();			
	Map<String, ArrayList<String>> D = new HashMap<String, ArrayList<String>>();
	Map<String, ArrayList<String[]>> D3 = new HashMap<String, ArrayList<String[]>>();
	Map<String, ArrayList<String[]>> C3 = new HashMap<String, ArrayList<String[]>>();
	
	ArrayList<String[]> ident_rel = new ArrayList<String[]>();
	ArrayList<String[]> open_branch = new ArrayList<String[]>();
	private ArrayList<String> CUK_ini;
	
	HashMap<Pair, ArrayList<String>> decision = new HashMap<Pair, ArrayList<String>>();
	ArrayList<String> T2 = new ArrayList<String>();
	int iterator = 0;	
	
	public void set_iterator(int val){
		this.iterator = val;
	}

	public static Logger getLogger() {
		return logger;
	}

	public Ruler getRuler() {
		return ruler;
	}

	public PCompleteTestGenerator2(FiniteStateMachine fsm) {
		logger.setLevel(Level.OFF);
		this.fsm = fsm;
		initialTestSet = new ArrayList<String>();
		initialTestSet.add("EPSILON");
		p = fsm.getNumberOfStates();
		CharacterizationSetConstructor constructor = new CharacterizationSetConstructor(
				fsm);
		W = constructor.getWset();
	}

	public FiniteStateMachine getFsm() {
		return fsm;
	}

	public void setRuler(Ruler ruler) {
		this.ruler = ruler;
	}

	public void setInitialTestSet(ArrayList<String> initialTestSet) {
		this.initialTestSet = initialTestSet;
	}

	public void setP(int p) {
		this.p = p;
	}
	public ArrayList<String> getK() {
		return K_old;
	}

	public ArrayList<String> getFinalTestSet() {
		return TestSequence.getNoPrefixes(finalTestSet);
	}
	
	public ArrayList<String> getRelativeSet() {
		return TestSequence.getNoPrefixes(Relative);
	}	
	
	public void generate() {
		System.out.println("Try with K");
		//generate(null);
	}
	
	public ArrayList<String> generate(boolean is_empty_input, ArrayList<String> K_init) throws IOException {
		
		int n = fsm.getStates().size();
		
		ArrayList<String> T = new ArrayList<String>();
		
		if(is_empty_input){
			T.add("EPSILON");			
		}else{
			for (String s : initialTestSet){
				T.add(s);
			}				
		}
				
		/*----------------------------------------------------------------------------*/
		// -------STEP 1
		ArrayList<Pair> C = getIdentityRelation(T);		
		ArrayList<Pair> temp_D = getTSeparatedTestPairs(T);
		ArrayList<Pair> D = getTSeparatedTestPairs(T);
		
		ruler = new Ruler(C, D, T);
		
		// apply rules 1.3
		for (Pair p : temp_D) {
			ruler.applyRules(p, AddedTo.D);
		}
		if(T.size()<=0) return new ArrayList<String>();
		ArrayList<String> K = new ArrayList<String>();
		if(K_init!=null){
			K = K_init;
			CunionK = findCunionK(C, K);
			if((CunionK.size() < Math.min(p + 1, n))){
				K = findK(T, D);
			}
		}else{
			K = findK(T, D);
		}
				
		// -------STEP 1
		/*----------------------------------------------------------------------------*/
		
		while (K.size() < Math.min(p + 1, n)) // CONDITION 1
		{
			// -------STEP 2
			step02(T, C, D, K);
			System.out.println("step2");			
		}
		K_old = K;
		if (K.size() >= (p + 1)) // CONDITION 2
		{			
			finalTestSet = T;
		} else {
			// CONDITION 3
			CunionK = findCunionK(C, K);			
			print_set(CunionK,"CunionK");			
			FsmCoverage coverage = new FsmCoverage(fsm);
			while (!coverage.isInitializedTransitionCoverage2(CunionK, coverage)) {
				// CONDITION 4
				Pair p_fichi = findFiChi(T, CunionK, K, D);
				if (p_fichi != null) // C4 YES
				{
					step03(C, D, p_fichi);								
				} else // C4 NO
				{
					// CONDITION 5
					if (!CunionK.contains("EPSILON")) // C5 NO
					{
						// step 4 fi = epsilon
						Pair p_fichi2 = step04("EPSILON", K, D, C, T);
						step03(C, D, p_fichi2);											
					} else // C5 YES
					{
						String fi = step05(CunionK, T, C, D);						
						Pair p_fichi2 = step04(fi, K, D, C, T);
						step03(C, D, p_fichi2);						
					}
				}

				CunionK = findCunionK(C, K);			
				System.out.println("coverage: "
						+ coverage.transitionCoverage(CunionK));
				
			}			
			finalTestSet = T;				
		}
		return TestSequence.getNoPrefixes(T);
	}
	
public ArrayList<String> generate3(boolean is_empty_input) throws IOException, InterruptedException {
		
		int n = fsm.getStates().size();
		
		ArrayList<String> T = new ArrayList<String>();
		
		if(is_empty_input){
			T.add("EPSILON");			
		}else{			
			if(initialTestSet.isEmpty()){
				T.add("EPSILON");
			}else{
				for (String s : initialTestSet){
					T.add(s);
				}
			}
		}
				
		/*----------------------------------------------------------------------------*/
		// -------STEP 1	
		Map<String, ArrayList<String>> C = getIdentityRelation2(T);			
		Map<String, ArrayList<String>> D = getTSeparatedTestPairs3(T);
		Map<String, ArrayList<String>> temp_D = new HashMap<String, ArrayList<String>>();
		//temp_D.putAll(D);
		
		/*System.out.println("ret2 list ");		
		for(String alpha: ret2.keySet()){
			String aux_s = "";
			for(String [] s_a: ret2.get(alpha)){
				aux_s = aux_s.concat("beta: "+ s_a[0] + "(" +s_a[1]+ "), ");
			}
			System.out.println("alpha: "+ alpha + " list: " + aux_s);
		}*/		
		
		for (String a : D.keySet()) {
			ArrayList<String> aux = new ArrayList<String>();
			aux.addAll(D.get(a));
			String b = a;
			temp_D.put(b, aux); 
		}
		System.out.println("---------------------------------");
		
		ruler = new Ruler(C, D, T, fsm);
	
		// apply rules 1.3
		for (String a : temp_D.keySet()) {
			for (String b : temp_D.get(a)) {				
				ruler.applyRules3(new Pair(a,b), AddedTo.D);			
			}			
		}		
				
		if(T.size()<=0) return new ArrayList<String>();		
		//ArrayList<String> K = findK3(T, D);	
		ArrayList<String> K = new ArrayList<String>();	
				
		// -------STEP 1	
		while (K.size() < Math.min(p + 1, n)) // CONDITION 1
		{
			// -------STEP 2
			step02a(T, C, D, K);
			System.out.println("step2");			
		}
		
		K_old = K;
		if (K.size() >= (p + 1)) // CONDITION 2
		{			
			finalTestSet = T;
		} else {
			// CONDITION 3
			CunionK = findCunionK2(C, K);			
			print_set(CunionK,"CunionK");			
			FsmCoverage coverage = new FsmCoverage(fsm);
			while (!coverage.isInitializedTransitionCoverage(CunionK)) {	
				
				// CONDITION 4
				Pair p_fichi = findFiChi3(T, CunionK, K, D);
				
				if (p_fichi != null) // C4 YES
				{
					step03a(C, p_fichi);						
					System.out.println("step3 fi: "+ p_fichi);
					//print_set(CunionK,"CunionK");
					//print_map(C,"C");
					//print_map(D,"D");
				} else // C4 NO
				{
					// CONDITION 5
					if (!CunionK.contains("EPSILON")) // C5 NO
					{
						// step 4 fi = epsilon
						Pair p_fichi2 = step04a("EPSILON", K, D, C, T);
						step03a(C, p_fichi2);
						System.out.println("step4");
					} else // C5 YES
					{
						System.out.println("uncov " + coverage.getNonCoveredtransitions(CunionK));
						//print_set(CunionK,"CunionK");
						System.out.println("CunionK"+ CunionK);
						String fi = step05a(CunionK, T, C, D);						
						Pair p_fichi2 = step04a(fi, K, D, C, T);
						step03a(C, p_fichi2);
						System.out.println("step5 fi: "+ fi);						
					}
				}

				CunionK = findCunionK2(C, K);
				//print_set(CunionK,"CunionK");	
				System.out.println("coverage: "
						+ coverage.transitionCoverage(CunionK));
				
			}			
			finalTestSet = T;				
		}
		return TestSequence.getNoPrefixes(T);
	}

	public ArrayList<String> generate00(boolean is_empty_input) throws IOException, InterruptedException {
		
		int n = fsm.getStates().size();
		
		ArrayList<String> T = new ArrayList<String>();
		
		//ArrayList<String> T3 = new ArrayList<String>();
		//ArrayList<String> T4 = new ArrayList<String>();
		
		if(is_empty_input){
			T.add("EPSILON");			
		}else{			
			if(initialTestSet.isEmpty()){
				T.add("EPSILON");
			}else{
				for (String s : initialTestSet){
					T.add(s);
				}
			}
		}
				
		/*----------------------------------------------------------------------------*/
		// -------STEP 1	
		Map<String, ArrayList<String>> C = getIdentityRelation2(T);			
		Map<String, ArrayList<String>> D = getTSeparatedTestPairs3(T);
		Map<String, ArrayList<String>> temp_D = new HashMap<String, ArrayList<String>>();
				
		for (String a : D.keySet()) {
			ArrayList<String> aux = new ArrayList<String>();
			aux.addAll(D.get(a));
			String b = a;
			temp_D.put(b, aux); 
		}
		System.out.println("---------------------------------");
		
		ruler = new Ruler(C, D, T, fsm);
	
		// apply rules 1.3
		for (String a : temp_D.keySet()) {
			for (String b : temp_D.get(a)) {				
				ruler.applyRules3(new Pair(a,b), AddedTo.D);			
			}			
		}		
				
		if(T.size()<=0) return new ArrayList<String>();		
		//ArrayList<String> K = findK3(T, D);	
		ArrayList<String> K = new ArrayList<String>();	
				
		// -------STEP 1	
		while (K.size() < Math.min(p + 1, n)) // CONDITION 1
		{
			// -------STEP 2
			step02aaa(T, C, D, K);
			System.out.println("step2");			
		}
				
		CunionK = findCunionK2(C, K);			
		print_set(CunionK,"CunionK");
		
	/*	T2 = create_T2(T2);
		System.out.println("\n EXTRA ******");
		for(String t : T2){
			System.out.println(t);
		}
		System.out.println("\n END ******");
		*/
		
		
		K_old = K;
		if (K.size() >= (p + 1)) // CONDITION 2
		{			
			finalTestSet = T;
		} else {
			// CONDITION 3
			CunionK = findCunionK2(C, K);			
			print_set(CunionK,"CunionK");			
			FsmCoverage coverage = new FsmCoverage(fsm);
			while (!coverage.isInitializedTransitionCoverage(CunionK)) {	
				
				// CONDITION 4
				Pair p_fichi = findFiChi3(T, CunionK, K, D);
				
				if (p_fichi != null) // C4 YES
				{
					step03a(C, p_fichi);						
					System.out.println("step3 fi: "+ p_fichi);
					//print_set(CunionK,"CunionK");
					//print_map(C,"C");
					//print_map(D,"D");
				} else // C4 NO
				{
					// CONDITION 5
					if (!CunionK.contains("EPSILON")) // C5 NO
					{
						// step 4 fi = epsilon
						Pair p_fichi2 = step04aaa("EPSILON", K, D, C, T);
						step03a(C, p_fichi2);
						System.out.println("step4");
					} else // C5 YES
					{
						System.out.println("uncov " + coverage.getNonCoveredtransitions(CunionK));
						//print_set(CunionK,"CunionK");
						//System.out.println("CunionK"+ CunionK);
						System.out.println("step5");	
						String fi = step05aaa(CunionK, T, C, D);
						System.out.println("step4 fi: "+ fi);	
						Pair p_fichi2 = step04aaa(fi, K, D, C, T);
						System.out.println("step3 fi: "+ fi);	
						step03a(C, p_fichi2);						
						System.out.println("END step5 fi: "+ fi);						
					}
				}
	
				CunionK = findCunionK2(C, K);
				//print_set(CunionK,"CunionK");	
				System.out.println("coverage: "
						+ coverage.transitionCoverage(CunionK));
				
			}			
			finalTestSet = T;				
		}		
		return TestSequence.getNoPrefixes(T);
		//return TestSequence.getNoPrefixes(T3);
	}

	public ArrayList<String> generate_random(boolean is_empty_input) throws IOException, InterruptedException {
		
		int n = fsm.getStates().size();
		
		ArrayList<String> T = new ArrayList<String>();
		
		if(is_empty_input){
			T.add("EPSILON");			
		}else{			
			if(initialTestSet.isEmpty()){
				T.add("EPSILON");
			}else{
				for (String s : initialTestSet){
					T.add(s);
				}
			}
		}
				
		/*----------------------------------------------------------------------------*/
		// -------STEP 1	
		Map<String, ArrayList<String>> C = getIdentityRelation2(T);			
		Map<String, ArrayList<String>> D = getTSeparatedTestPairs3(T);
		Map<String, ArrayList<String>> temp_D = new HashMap<String, ArrayList<String>>();
				
		for (String a : D.keySet()) {
			ArrayList<String> aux = new ArrayList<String>();
			aux.addAll(D.get(a));
			String b = a;
			temp_D.put(b, aux); 
		}
		System.out.println("---------------------------------");
		
		ruler = new Ruler(C, D, T, fsm);
	
		// apply rules 1.3
		for (String a : temp_D.keySet()) {
			for (String b : temp_D.get(a)) {				
				ruler.applyRules3(new Pair(a,b), AddedTo.D);			
			}			
		}		
				
		if(T.size()<=0) return new ArrayList<String>();		
		//ArrayList<String> K = findK3(T, D);	
		ArrayList<String> K = new ArrayList<String>();	
				
		// -------STEP 1	
		while (K.size() < Math.min(p + 1, n)) // CONDITION 1
		{
			// -------STEP 2
			step02_random(T, C, D, K);
			System.out.println("step2");			
		}
				
		CunionK = findCunionK2(C, K);			
		print_set(CunionK,"CunionK");	
		K_old = K;
		if (K.size() >= (p + 1)) // CONDITION 2
		{			
			finalTestSet = T;
		} else {
			// CONDITION 3
			CunionK = findCunionK2(C, K);			
			print_set(CunionK,"CunionK");			
			FsmCoverage coverage = new FsmCoverage(fsm);
			while (!coverage.isInitializedTransitionCoverage(CunionK)) {	
				
				// CONDITION 4
				Pair p_fichi = findFiChi3(T, CunionK, K, D);				
				if (p_fichi != null) // C4 YES
				{
					step03a(C, p_fichi);						
					System.out.println("step3 fi: "+ p_fichi);					
				} else // C4 NO
				{
					// CONDITION 5
					if (!CunionK.contains("EPSILON")) // C5 NO
					{
						// step 4 fi = epsilon
						Pair p_fichi2 = step04_random("EPSILON", K, D, C, T);
						step03a(C, p_fichi2);
						System.out.println("step4");
					} else // C5 YES
					{
						System.out.println("uncov " + coverage.getNonCoveredtransitions(CunionK));						
						System.out.println("step5");	
						String fi = step05_random(CunionK, K, T, C, D);						
						Pair p_fichi2 = step04_random(fi, K, D, C, T);						
						step03a(C, p_fichi2);						
						System.out.println("END step5 fi: "+ fi);						
					}
				}
	
				CunionK = findCunionK2(C, K);
				//print_set(CunionK,"CunionK");	
				System.out.println("coverage: "
						+ coverage.transitionCoverage(CunionK));
				
			}			
			finalTestSet = T;				
		}		
		return TestSequence.getNoPrefixes(T);		
	}
	
	
	
	public ArrayList<String> generate_t_choice(boolean is_empty_input, 
		HashMap<Transition, ArrayList<ArrayList<CostTuple>>> t_choice
		) throws IOException, InterruptedException {
		
		int n = fsm.getStates().size();
		
		ArrayList<String> T = new ArrayList<String>();
		
		//ArrayList<String> T3 = new ArrayList<String>();
		//ArrayList<String> T4 = new ArrayList<String>();
		
		if(is_empty_input){
			T.add("EPSILON");			
		}else{			
			if(initialTestSet.isEmpty()){
				T.add("EPSILON");
			}else{
				for (String s : initialTestSet){
					T.add(s);
				}
			}
		}
				
		/*----------------------------------------------------------------------------*/
		// -------STEP 1	
		Map<String, ArrayList<String>> C = getIdentityRelation2(T);			
		Map<String, ArrayList<String>> D = getTSeparatedTestPairs3(T);
		Map<String, ArrayList<String>> temp_D = new HashMap<String, ArrayList<String>>();
				
		for (String a : D.keySet()) {
			ArrayList<String> aux = new ArrayList<String>();
			aux.addAll(D.get(a));
			String b = a;
			temp_D.put(b, aux); 
		}
		System.out.println("---------------------------------");
		
		ruler = new Ruler(C, D, T, fsm);
	
		// apply rules 1.3
		for (String a : temp_D.keySet()) {
			for (String b : temp_D.get(a)) {				
				ruler.applyRules3(new Pair(a,b), AddedTo.D);			
			}			
		}		
				
		if(T.size()<=0) return new ArrayList<String>();		
		//ArrayList<String> K = findK3(T, D);	
		ArrayList<String> K = new ArrayList<String>();	
				
		// -------STEP 1	
		while (K.size() < Math.min(p + 1, n)) // CONDITION 1
		{
			// -------STEP 2
			step02aaa(T, C, D, K);
			System.out.println("step2");			
		}
				
		CunionK = findCunionK2(C, K);			
		print_set(CunionK,"CunionK");
		
		
		K_old = K;
		if (K.size() >= (p + 1)) // CONDITION 2
		{			
			finalTestSet = T;
		} else {
			// CONDITION 3
			CunionK = findCunionK2(C, K);			
			print_set(CunionK,"CunionK");			
			FsmCoverage coverage = new FsmCoverage(fsm);
			while (!coverage.isInitializedTransitionCoverage(CunionK)) {	
				
				// CONDITION 4
				Pair p_fichi = findFiChi3(T, CunionK, K, D);
				
				if (p_fichi != null) // C4 YES
				{
					step03a(C, p_fichi);						
					System.out.println("step3 fi: "+ p_fichi);					
				} else // C4 NO
				{
					// CONDITION 5
					if (!CunionK.contains("EPSILON")) // C5 NO
					{
						// step 4 fi = epsilon
						Pair p_fichi2 = step04aaa("EPSILON", K, D, C, T);
						step03a(C, p_fichi2);
						System.out.println("step4");
					} else // C5 YES
					{
						System.out.println("uncov " + coverage.getNonCoveredtransitions(CunionK));
						//print_set(CunionK,"CunionK");
						//System.out.println("CunionK"+ CunionK);
						System.out.println("step5");	
						String fi = step05aaa(CunionK, T, C, D);
						System.out.println("step4 fi: "+ fi);	
						Pair p_fichi2 = step04aaa(fi, K, D, C, T);
						System.out.println("step3 fi: "+ fi);	
						step03a(C, p_fichi2);						
						System.out.println("END step5 fi: "+ fi);						
					}
				}
	
				CunionK = findCunionK2(C, K);
				//print_set(CunionK,"CunionK");	
				System.out.println("coverage: "
						+ coverage.transitionCoverage(CunionK));
				
			}			
			finalTestSet = T;				
		}		
		return TestSequence.getNoPrefixes(T);		
	}
	
	
	public HashMap<Transition, ArrayList<ArrayList<CostTuple>>> generate_preset() throws IOException, InterruptedException {
		
		int n = fsm.getStates().size();		
		ArrayList<String> T = new ArrayList<String>();
		ArrayList<String> T_all = new ArrayList<String>();
		T.add("EPSILON");			
					
		/*----------------------------------------------------------------------------*/
		// -------STEP 1	
		Map<String, ArrayList<String>> C = getIdentityRelation2(T);			
		Map<String, ArrayList<String>> D = getTSeparatedTestPairs3(T);
		Map<String, ArrayList<String>> temp_D = new HashMap<String, ArrayList<String>>();
				
		for (String a : D.keySet()) {
			ArrayList<String> aux = new ArrayList<String>();
			aux.addAll(D.get(a));
			String b = a;
			temp_D.put(b, aux); 
		}
		System.out.println("---------------------------------");
		
		ruler = new Ruler(C, D, T, fsm);
	
		// apply rules 1.3
		for (String a : temp_D.keySet()) {
			for (String b : temp_D.get(a)) {				
				ruler.applyRules3(new Pair(a,b), AddedTo.D);			
			}			
		}	
		ArrayList<String> K = new ArrayList<String>();	
				
		// -------STEP 1	
		while (K.size() < Math.min(p + 1, n)) // CONDITION 1
		{
			// -------STEP 2
			step02a(T, C, D, K);
			System.out.println("step2");			
		}
				
		System.out.println("K = "+K);
		CunionK = findCunionK2(C, K);			
		print_set(CunionK,"CunionK");
				
		//get all choices for minimal alpha
		ArrayList<Transition> all_trans = fsm.getTransitions();
		for(Transition t : all_trans){
			System.out.println(t);
			
			State s = t.getIn();
			ArrayList<ArrayList<CostTuple>> c_list = new ArrayList<ArrayList<CostTuple>>();
			for (String alpha0 : K) {
				if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha0) == s) {
					String fi = TestSequence.concat(alpha0,t.getInput());
					c_list = add_separ(K, fi, T_all, c_list, true);					
					break;
				}
			}
			//t_choice.put(t, c_list);			
		}	
		
		//check T_all
		System.out.println("T alpha iter 1");
		for (String s : TestSequence.getNoPrefixes(T_all)) {
			System.out.println(s);			
		}
		
		//add next alpha to each transition		
		HashMap<Transition, ArrayList<ArrayList<CostTuple>>> t_choice = new HashMap<Transition, ArrayList<ArrayList<CostTuple>>>();
		for(Transition t : all_trans){
			State s = t.getIn();
			ArrayList<ArrayList<CostTuple>> c_list = new ArrayList<ArrayList<CostTuple>>();
			for (String alpha : T_all) {
				if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha) == s) {
					String fi = TestSequence.concat(alpha,t.getInput());
					if(T_all.contains(fi)){
						//System.out.println(t);			
						//System.out.println("Alpha "+alpha+ " gamma "+ t.getInput()+ " fi "+fi);												
						c_list = add_separ(K, fi, T_all, c_list, false);
					}
				}
			}
			t_choice.put(t, c_list);
		}
		
		//check t_choice
		System.out.println("\n CHOICE");	
		for(Transition t: t_choice.keySet()){
			System.out.println("\n"+t);
			for(ArrayList<CostTuple> ct: t_choice.get(t)){
				System.out.println("TUPLA(fi:upsilon:gamma(0)) "+ ct.get(0).getBeta() + " ; "+ct.get(0).getAlpha()
						+ " ; "+ ct.get(0).getGamma());
				for(CostTuple c : ct){
					System.out.println(TestSequence.getNoPrefixes(c.getT()));
				}
			}
		}
				
		/*
		//find small solution		
		int min_cost = -1;
		ArrayList<CostTuple> min_path = new ArrayList<CostTuple>();
		//for(Transition t1: t_choice.keySet()){	
		Transition t1 = all_trans.get(0);
			System.out.println("\nTRANSITION 1 "+t1);
			for(ArrayList<CostTuple> ct1: t_choice.get(t1)){	//lista de tuplas alphax+upsilon
				for(CostTuple c1 : ct1){
					ArrayList<CostTuple> this_path = new ArrayList<CostTuple>();
					ArrayList<String> t_aux1 = TestSequence.getNoPrefixes(c1.getT());
					System.out.println("SET "+TestSequence.getNoPrefixes(c1.getT()));
					this_path.add(c1);
					//compare other upsilon
					for(ArrayList<CostTuple> ct10: t_choice.get(t1)){
						if(!ct1.equals(ct10)){
							int t10_min = -1;
							CostTuple t10_tuple = new CostTuple();
							boolean found1 = false;
							if(ct10.get(0).getBeta().equals(c1.getBeta()) 
									&& !ct10.get(0).getAlpha().equals(c1.getAlpha())){
								for(CostTuple c10 : ct10){
									//if(c1.getGamma().equals(c10.getGamma())){
										ArrayList<String> t_aux10 = TestSequence.getNoPrefixes(c10.getT());
										t_aux10.addAll(t_aux1);									
										int t10_cost = calc_size_T(t_aux10);
										if((t10_min < 0) || t10_cost < t10_min){
											t10_min = t10_cost;
											t10_tuple = c10;
											found1 = true;
										}
									//}									
								}
								if(found1){
									if(!this_path.contains(t10_tuple)) this_path.add(t10_tuple);
									t_aux1.addAll(TestSequence.getNoPrefixes(t10_tuple.getT()));
									System.out.println("ADDED "+TestSequence.getNoPrefixes(t10_tuple.getT()));
								}								
							}
						}						
					}
					//compare other transitions
					for(Transition t2: t_choice.keySet()){
						System.out.println("\nTRANSITION 2 "+t2);
						int t2_min = -1;
						ArrayList<CostTuple> t2_tuple = new ArrayList<CostTuple>();
						boolean found_compare = false;
						if(!t1.equals(t2)){													
							for(ArrayList<CostTuple> ct2: t_choice.get(t2)){
								for(CostTuple c2 : ct2){
									//combine with other upsilon
									boolean found2 = false;
									for(ArrayList<CostTuple> ct20: t_choice.get(t2)){
										if(!ct2.equals(ct20)){
											if(ct20.get(0).getBeta().equals(c2.getBeta()) 
													&& !ct20.get(0).getAlpha().equals(c2.getAlpha())){
												found_compare = true;
												for(CostTuple c20 : ct20){
													//if(c2.getGamma().equals(c20.getGamma())){
														ArrayList<String> t_aux2 = TestSequence.getNoPrefixes(c2.getT());
														t_aux2.addAll(t_aux1);
														t_aux2.addAll(TestSequence.getNoPrefixes(c20.getT()));
														int t2_cost = calc_size_T(t_aux2);
														if((t2_min < 0) || t2_cost < t2_min){
															t2_min = t2_cost;
															t2_tuple = new ArrayList<CostTuple>();
															if(!t2_tuple.contains(c2)) t2_tuple.add(c2);
															if(!t2_tuple.contains(c20)) t2_tuple.add(c20);
															found2 = true;
														}
													//}														
												}
											}
										}										
									}
									//if(!found2) found_compare = false;
									if(!found_compare){
										ArrayList<String> t_aux2 = TestSequence.getNoPrefixes(c2.getT());
										t_aux2.addAll(t_aux1);
										int t2_cost = calc_size_T(t_aux2);
										if((t2_min < 0) || t2_cost < t2_min){
											t2_min = t2_cost;
											t2_tuple = new ArrayList<CostTuple>();
											t2_tuple.add(c2);											
										}
									}																										
								}
							}
							if(found_compare){
								for(CostTuple ct : t2_tuple){
									if(!this_path.contains(ct)) this_path.add(ct);
									t_aux1.addAll(TestSequence.getNoPrefixes(ct.getT()));
								}
							}else{
								if(!this_path.contains(t2_tuple.get(0))) this_path.add(t2_tuple.get(0));
								t_aux1.addAll(TestSequence.getNoPrefixes(t2_tuple.get(0).getT()));
							}
							
						}						
					}
					//set minimal increment
					int t1_t2_all_size = calc_size_T(t_aux1);
					if((min_cost < 0) || (t1_t2_all_size < min_cost)){
						min_cost = t1_t2_all_size;
						min_path = this_path;
					}
				}
			}			
		//}
		
		//print min_path
		System.out.println("Alpha	Beta	Gamma");
		ArrayList<String> t_final = new ArrayList<String>();
		for(CostTuple ct : min_path){
			System.out.println(ct.getAlpha()+ "	"+ ct.getBeta()+"	"+ct.getGamma());
			for(String s : TestSequence.getNoPrefixes(ct.getT())){
				if(!t_final.contains(s)){
					t_final.add(s);
				}
			}
		}
			
		System.out.println("T final");
		for (String s : TestSequence.getNoPrefixes(t_final)) {
			System.out.println(s);			
		}
		*/
		
		return t_choice;		
	}
	
	public int calc_size_T(ArrayList<String> T){
		int size = 0;
		for(String t : TestSequence.getNoPrefixes(T)){
			String[] data = t.split(",");
			size += data.length;
			size++;
		}
		return size;		
	}
	
	public ArrayList<ArrayList<CostTuple>> add_separ(ArrayList<String> K, String fi, ArrayList<String> T_all,
			ArrayList<ArrayList<CostTuple>> c_list, boolean add_all){
						
		String chi = findChi(K, fi);					
		for (String upsilon : TestSet.minus(K, chi)) {			
									
			String alpha = upsilon;
			String beta = fi;	
			//System.out.println("A " + alpha);
			//System.out.println("B " + beta);
				
			ArrayList<CostTuple> l_tuple = selectGamma4(alpha, beta, new ArrayList<String>(), C);						
			for(CostTuple tu : l_tuple){
				alpha = tu.getAlpha();
				beta = tu.getBeta();
				String gamma = tu.getGamma();
				
				String seq1 = TestSequence.concat(alpha, gamma);
				String seq2 = TestSequence.concat(beta, gamma);
				ArrayList<String> m_set = new ArrayList<String>();
				TestSet.addAllPrefsOf(m_set, seq1);
				TestSet.addAllPrefsOf(m_set, seq2);
				tu.setT(m_set);
				if(add_all){
					TestSet.addAllPrefsOf(T_all, seq1);
					TestSet.addAllPrefsOf(T_all, seq2);
				}				
				
				//System.out.println("seq 1 " + alpha + " + "+ gamma);
				//System.out.println("seq 2 " + beta + " + "+ gamma);
			}
			c_list.add(l_tuple);
		}					
		return c_list;
	}
	
	public ArrayList<String> create_T2(ArrayList<String> T2){
		HashMap<String,Integer> g_map = new HashMap<String,Integer>();
		
		//contagem de gammas
		for(Pair p : decision.keySet()){			
			ArrayList<String> gammas = decision.get(p);
			for(String g : gammas){
				if(!g_map.containsKey(g)){
					g_map.put(g, 1);
				}else{
					int val = g_map.get(g);
					val++;					
					g_map.put(g, val);				
				}
			}			
		}		
		//adicionar valores em T2
		ArrayList<String> T_aux = new ArrayList<String>();
		for(Pair p : decision.keySet()){
			String a = p.getLeft();
			String b = p.getRight();
			ArrayList<String> gammas = decision.get(p);
			int max = 0;
			String y = "";
			int empate = 0;
			for(String g : gammas){
				int count = g_map.get(g);
				if(count > max){
					max = count;
					y = g;
				}
				if(count == max){
					String alphagamma = TestSequence.concat(a, g);
					String betagamma = TestSequence.concat(b, g);
					TestSet.addAllPrefsOf(T_aux, alphagamma);
					TestSet.addAllPrefsOf(T_aux, betagamma);
					ArrayList<String> temp = TestSequence.getNoPrefixes(T_aux);
					int size_temp = 0;
					for(String no : temp){
						size_temp += no.length();
					}
					if(empate == 0){
						empate = size_temp;
					}else if(size_temp < empate){
						empate = size_temp;
						y = g;
					}
				}
			}			
			System.out.println("data "+ a + "	"+b+ "	"+y);
			String alphagamma = TestSequence.concat(a, y);
			String betagamma = TestSequence.concat(b, y);
			TestSet.addAllPrefsOf(T2, alphagamma);
			TestSet.addAllPrefsOf(T2, betagamma);			
		}
		
		return TestSequence.getNoPrefixes(T2);
	}
	
	
	public void print_map3(Map<String, ArrayList<String[]>> MAP, String var){
		String aux_s = var + "\n";
		for(String alpha: MAP.keySet()){
			aux_s += "\nkey: "+ alpha + " -> ";
			for(String[] s_a: MAP.get(alpha)){
				aux_s += "(" +s_a[0]+ "|"+s_a[1]+ "), ";
			}			
		}
		System.out.println(aux_s);
	}
	
	public void print_map2(Map<Transition, ArrayList<String[]>> MAP, String var){
		String aux_s = var + "\n";
		for(Transition alpha: MAP.keySet()){
			aux_s += "\nkey: "+ alpha + " -> ";
			for(String[] s_a: MAP.get(alpha)){
				aux_s += "(" +s_a[0]+ "|"+s_a[1]+"|"+s_a[2]+ "), ";
			}			
		}
		System.out.println(aux_s);
	}
	
	public void print_map(Map<String, ArrayList<String>> MAP, String var){
		String aux_s = var + "\n";
		for(String alpha: MAP.keySet()){
			aux_s += "\nkey: "+ alpha + " -> ";
			for(String s_a: MAP.get(alpha)){
				aux_s += "(" +s_a+ "), ";
			}			
		}
		System.out.println(aux_s);
	}
	
	public ArrayList<String> get_relevant4_old5() throws IOException, InterruptedException {
		
		int n = fsm.getStates().size();
		
		ArrayList<String> T = new ArrayList<String>();
		T.add("EPSILON");	
		
		ArrayList<String> T4 = new ArrayList<String>(); 
		for (String s : initialTestSet){
			TestSet.addAllPrefsOf(T4, s);
		}
		get_C_D(T4);
		Relative = new ArrayList<String>();
						
		/*----------------------------------------------------------------------------*/
		// -------STEP 1	
		Map<String, ArrayList<String>> C = getIdentityRelation2(T);			
		Map<String, ArrayList<String>> D = getTSeparatedTestPairs3(T);
		Map<String, ArrayList<String>> temp_D = new HashMap<String, ArrayList<String>>();
				
		for (String a : D.keySet()) {
			ArrayList<String> aux = new ArrayList<String>();
			aux.addAll(D.get(a));
			String b = a;
			temp_D.put(b, aux); 
		}	
		
		ruler = new Ruler(C, D, T);	
		// apply rules 1.3
		for (String a : temp_D.keySet()) {
			for (String b : temp_D.get(a)) {				
				ruler.applyRules3(new Pair(a,b), AddedTo.D);			
			}			
		}		
				
		if(T.size()<=0) return new ArrayList<String>();		
		//ArrayList<String> K = findK3(T, D);	
		ArrayList<String> K = new ArrayList<String>();	
				
		// -------STEP 1	
		while (K.size() < Math.min(p + 1, n)) // CONDITION 1
		{
			// -------STEP 2
			step02c(T, T4, C, D, K);
			System.out.println("step2");			
		}
		
		for(Transition t : fsm.getTransitions()){
			step05c(t, K, T, T4, C, C_data, D, D_data);
		}
				
		return TestSequence.getNoPrefixes(T);
	}
	
public ArrayList<String> get_relevant4_ooold3() throws IOException, InterruptedException {
		
		int n = fsm.getStates().size();
		
		ArrayList<String> T = new ArrayList<String>();
		T.add("EPSILON");	
		
		ArrayList<String> T4 = new ArrayList<String>(); 
		for (String s : initialTestSet){
			TestSet.addAllPrefsOf(T4, s);
		}
		get_C_D(T4);
		Relative = new ArrayList<String>();
						
		/*----------------------------------------------------------------------------*/
		// -------STEP 1							
		FsmCoverage coverage = new FsmCoverage(fsm);
		ArrayList<Transition> non_cov_trans = coverage.getNonCoveredtransitions(T);
		for(Transition transition : non_cov_trans){
			State s = transition.getIn();			
			for (String alpha1 : T4) {			
				if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha1) == s) {
					String alphax = TestSequence.concat(alpha1,
							transition.getInput());
					System.out.println("alpha1 " + alpha1);								
					if(T4.contains(alphax)){					
						System.out.println("point 1");		
						//ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C4);
						ArrayList<String> Cfi = HashList.getPartition(alphax, C_data);
					}
				}
			}
		}
		
		
		return TestSequence.getNoPrefixes(T);
	}

public ArrayList<String> get_retest_set() throws IOException, InterruptedException {
	
	//int n = fsm.getStates().size();
	
	//ArrayList<String> T = new ArrayList<String>();
	//T.add("EPSILON");	
	
	ArrayList<String> T4 = new ArrayList<String>();
	if(initialTestSet.isEmpty()){
		T4.add("EPSILON");
	}else{
		for (String s : initialTestSet){
			TestSet.addAllPrefsOf(T4, s);
		}
	}		
	Relative = new ArrayList<String>();
	boolean found = get_C_D(T4);
	if(!found){
		Relative.clear();
		return new ArrayList<String>();
	}
	return TestSequence.getNoPrefixes(Relative);
}
	
	public ArrayList<String> get_relevant4_alt1() throws IOException, InterruptedException {
		
		int n = fsm.getStates().size();
		
		ArrayList<String> T = new ArrayList<String>();
		T.add("EPSILON");	
		
		ArrayList<String> T4 = new ArrayList<String>(); 
		for (String s : initialTestSet){
			TestSet.addAllPrefsOf(T4, s);
		}
		get_C_D(T4);
		Relative = new ArrayList<String>();
								
		/*----------------------------------------------------------------------------*/
		// -------STEP 1	
		Map<String, ArrayList<String>> C = getIdentityRelation2(T);			
		Map<String, ArrayList<String>> D = getTSeparatedTestPairs3(T);
		Map<String, ArrayList<String>> temp_D = new HashMap<String, ArrayList<String>>();
				
		for (String a : D.keySet()) {
			ArrayList<String> aux = new ArrayList<String>();
			aux.addAll(D.get(a));
			String b = a;
			temp_D.put(b, aux); 
		}	
		
		ruler = new Ruler(C, D, T, fsm);	
		// apply rules 1.3
		for (String a : temp_D.keySet()) {
			for (String b : temp_D.get(a)) {				
				ruler.applyRules3(new Pair(a,b), AddedTo.D);			
			}			
		}		
				
		if(T.size()<=0) return new ArrayList<String>();		
		//ArrayList<String> K = findK3(T, D);	
		ArrayList<String> K = new ArrayList<String>();	
				
		// -------STEP 1	
		while (K.size() < Math.min(p + 1, n)) // CONDITION 1
		{
			// -------STEP 2
			step02c(T, T4, C, D, K);
			System.out.println("step2");			
		}
				
		FsmCoverage coverage = new FsmCoverage(fsm);
		K_old = K;
		if (K.size() >= (p + 1)) // CONDITION 2
		{			
			finalTestSet = T;
		} else {
			// CONDITION 3
			CunionK = findCunionK2(C, K);			
			print_set(CunionK,"CunionK");
			//Transition last_non_t = null;
			while (!coverage.isInitializedTransitionCoverage(CunionK)) {	
				
				// CONDITION 4
				/*ArrayList<Pair> pre_fi_chi = findFiChi4(CunionK, K, D);
				for(Pair p : pre_fi_chi){
					step03a(C, p);						
					System.out.println("step3b fi: "+ p);
					System.out.println("prefix "+ p);
				}*/
				Pair p_fichi = findFiChi3(T, CunionK, K, D);
				
				if (p_fichi != null) // C4 YES
				{
					step03a(C, p_fichi);						
					System.out.println("step3 fi: "+ p_fichi);
					//ArrayList<Transition> current = fsm.reachedTransitionsWithSequence(fsm.getInitialState(), p_fichi.getLeft());
					//Transition transition = current.get(current.size()-1);
					//add_extra(p_fichi.getRight(), p_fichi.getLeft(), transition, coverage, 
					//		T, T4, C, C_data, D, D_data, K);
				} else // C4 NO
				{
					// CONDITION 5
					if (!CunionK.contains("EPSILON")) // C5 NO
					{
						// step 4 fi = epsilon
						Pair p_fichi2 = step04c("EPSILON", K, D, D_data, C, C_data, T, T4);
						step03a(C, p_fichi2);
						System.out.println("step4");
					} else // C5 YES
					{		
						// select the transition
						//Transition transition = selectTransition(CunionK, coverage, T);
						ArrayList<Transition> transitions = coverage.getNonCoveredtransitions(CunionK);
						System.out.println("NON-COV TRANS " + transitions);
						
						for(Transition t : transitions){
							String fi = step05b(t, K, CunionK, T, T4, C, C_data, D, D_data);
							System.out.println("\nstep5 fi: "+ fi);
							if(fi != null){
								break;
							}else{
								/*print_set(T4,"T4");
								for(String test : T4){
									if(!T.contains(test)){
										TestSet.addAllPrefsOf(T, test);
										TestSet.addAllPrefsOf(Relative, test);										
										updateC2(T, C);
										updateD2(D, T, test);
										break;
									}
								}*/
								System.out.println("\nstep5 FAIL fi: "+ fi);
								//return new ArrayList<String>();
							}
						}									
					}
				}

				CunionK = findCunionK2(C, K);
				//print_set(CunionK,"CunionK");
				//print_map(D,"D");
				System.out.println("CunionK"+CunionK);
				System.out.println("coverage: "
						+ coverage.transitionCoverage(CunionK));
				
			}			
			finalTestSet = T;				
		}
		//print_set(T,"T ");
		//print_set(CunionK,"CunionK");
	/*	get_C_D(CunionK);
		System.out.println("coverage: "
				+ coverage.transitionCoverage(CunionK));
		ArrayList<String> CUK = new ArrayList<String>();
		CUK.addAll(CunionK);
		get_C_D(T4);
		String fi = step05b(K, CUK, T, T4, C, C_data, D, D_data);
		if(fi != null){
			Pair p_fichi2 = step04c(fi, K, D, D_data, C, C_data, T, T4);
			step03a(C, p_fichi2);
			System.out.println("\nstep5 -! fi: "+ fi);
		}
		System.out.println("coverage: "
				+ coverage.transitionCoverage(CunionK));*/
		
		return TestSequence.getNoPrefixes(T);
	}
	
	public ArrayList<Transition> identify_t_sep(ArrayList<String> T, ArrayList<String> K){
		
		CunionK = findCunionK2(C, K);
		//identify convergent pairs using T-sep set
		Map<String, ArrayList<String[]>> req_sep = new HashMap<String, ArrayList<String[]>>();
		for (String fi : T) {				
			for (String chi : K) {				
				boolean in = true;				
				for (String upsilon : TestSet.minus(K, chi)) {					
					if (!HashList.pair_hash_in(D,fi, upsilon)){
						in = false;
						break;
					}
				}
				if (in && isConvergent(fi, chi)){
					ArrayList<Transition> current = fsm.reachedTransitionsWithSequence(fsm.getInitialState(), fi);
					if(current.size() != 0)	{
						Transition t = current.get(current.size() - 1);
						String[] node = new String[3];
						node[0] = t.toString();
						node[1] = chi;
						if(req_sep.keySet().contains(fi)){
							req_sep.get(fi).add(node);
						}else{
							ArrayList<String[]> list = new ArrayList<String[]>();
							list.add(node);
							req_sep.put(fi, list);
						}
						if(!CunionK.contains(fi)){
							CunionK.add(fi);
						}
					}					
				}					
			}
		}
		print_map3(req_sep,"req_sep");
		//identify those who attend requirements from convergent pairs
		System.out.println("CunionK "+ CunionK);		
		ArrayList<Transition> trans = fsm.getTransitions();
		Map<Transition, ArrayList<String[]>> requirement = new HashMap<Transition, ArrayList<String[]>>();		
		for(String test : CunionK){
			ArrayList<Transition> current = fsm.reachedTransitionsWithSequence(fsm.getInitialState(), test);			
			if(current.size() != 0)	{
				Transition t = current.get(current.size() - 1); //get the last
				String x = t.getInput();
				String alpha = TestSequence.getPrefixFrom(test, x);
				String[] node = new String[3];
				node[0] = t.toString();
				node[1] = alpha;
				node[2] = test;
				//if(CunionK.contains(alpha)){
				if(CunionK.containsAll(TestSequence.getAllPrefixesFrom(test))){	
					if(requirement.keySet().contains(t)){
						requirement.get(t).add(node);
					}else{
						ArrayList<String[]> list = new ArrayList<String[]>();
						list.add(node);
						requirement.put(t, list);
					}
				}					
			}
		}
		print_map2(requirement,"requirement met by T-sep pairs");
		FsmCoverage coverage = new FsmCoverage(fsm);
		System.out.println("coverage get-C_D: "
				+ coverage.transitionCoverage(CunionK));
		CUK_ini = new ArrayList<String>();
		CUK_ini.addAll(CunionK);
		
		//get preliminar relative T-sep-based set that attend requirements
		ArrayList<Transition> non_trans = new ArrayList<Transition>();
		for(Transition t : trans){
			if(requirement.get(t) != null){				
				//String alpha = requirement.get(t).get(0)[1];
				String fi = requirement.get(t).get(0)[2];
				String chi = findChi(K,fi);				
				for (String upsilon : TestSet.minus(K, chi)) {
					String upgamma = "";
					String figamma = "";					
					for(String[] node : D3.get(upsilon)){
						if(node[0].equals(fi)){
							upgamma = TestSequence.concat(upsilon, node[1]);
							figamma = TestSequence.concat(fi, node[1]);							
							break;
						}
					}					
					System.out.println("ADD T-set part all " + upgamma + " + "+ figamma);
					if(!upgamma.equals("") && !figamma.equals("")){
						add_relative(figamma, upgamma);
					}					
				}
			}else{
				non_trans.add(t);
			}
		}		
		System.out.println("RELATIVE " + TestSequence.getNoPrefixes(Relative));	
		System.out.println("RELATIVE " + Relative);	
		return non_trans;
	}
	
	public Map<Transition, ArrayList<String[]>> indentify_all(ArrayList<String> T, ArrayList<String> K){
		
		Map<String, ArrayList<String>> temp_D = new HashMap<String, ArrayList<String>>();
		
		//analyze all	
		for (String a : D.keySet()) {
			ArrayList<String> aux = new ArrayList<String>();
			aux.addAll(D.get(a));
			String b = a;
			temp_D.put(b, aux); 
		}
		ruler = new Ruler(C, D, T, fsm, C3, D3);		
		for (String a : temp_D.keySet()) {
			for (String b : temp_D.get(a)) {				
				ruler.applyRules5(new Pair(a,b), AddedTo.D);			
			}			
		}
		ArrayList<String> K2 = new ArrayList<String>();			
		int n = fsm.getStates().size();
		while (K2.size() < Math.min(p + 1, n)) // CONDITION 1
		{
			step02d(T, C, D, K2, K);						
		}
		//-------STEP  3 -------			
		CunionK = findCunionK2(C, K);							
		Pair p_fichi = findFiChi3(T, CunionK, K, D);
		while(p_fichi != null) {			
			if (HashList.add_pair_hash(C, p_fichi.getLeft(), p_fichi.getRight())) {
				ruler.applyRules5(p_fichi, AddedTo.C);
				System.out.println("ADD " + p_fichi);
			}
			CunionK = findCunionK2(C, K);						
			p_fichi = findFiChi3(T, CunionK, K, D);
		}
		System.out.println("CunionK "+ CunionK);
		Map<Transition, ArrayList<String[]>> requirement = new HashMap<Transition, ArrayList<String[]>>();		
		for(String test : CunionK)
		{
			ArrayList<Transition> current = fsm.reachedTransitionsWithSequence(fsm.getInitialState(), test);
			
			if(current.size() != 0)
			{
				Transition t = current.get(current.size() - 1); //get the last
				String x = t.getInput();
				String alpha = TestSequence.getPrefixFrom(test, x);
				String[] node = new String[3];
				node[0] = t.toString();
				node[1] = alpha;
				node[2] = test;
				if(CunionK.contains(alpha)){
					if(requirement.keySet().contains(t)){
						requirement.get(t).add(node);
					}else{
						ArrayList<String[]> list = new ArrayList<String[]>();
						list.add(node);
						requirement.put(t, list);
					}	
				}
			}
		}
		print_map2(requirement,"requirement");
		//print_map3(C3,"C3");
		//print_map3(D3,"D3");
				
		FsmCoverage coverage = new FsmCoverage(fsm);
		System.out.println("coverage get-C_D: "
				+ coverage.transitionCoverage(CunionK));
		
		if(coverage.transitionCoverage(CunionK) < 1){
			return null;
		}
		
		return requirement;	
	}
	
public boolean get_C_D(ArrayList<String> T){
		
		C = getIdentityRelation2(T);			
		D = getTSeparatedTestPairs5(T);
		//D3 = getTSeparatedTestPairs4(T);
		C3 = new HashMap<String, ArrayList<String[]>>();
		//Map<String, ArrayList<String>> temp_D = new HashMap<String, ArrayList<String>>();
					
		print_map3(D3,"D3 before T-sep alpha->beta|gamma");
	
		ArrayList<String> K = new ArrayList<String>();			
		int n = fsm.getStates().size();
		while (K.size() < Math.min(p + 1, n)) // CONDITION 1
		{
			step02c(T, C, D, K);						
		}
		System.out.println("K "+ K);
		ArrayList<Transition> non_trans = identify_t_sep(T, K);		
		Map<Transition, ArrayList<String[]>> requirement = indentify_all(T, K);
				
		System.out.println("non_trans "+ non_trans);
		if(requirement == null){
			return false;
		}
		//add new relatives from rules 
		//for each non covered transition by t-sep pairs
		for(Transition non_t : non_trans){
			//String alpha = requirement.get(non_t).get(0)[1];
			String fi = requirement.get(non_t).get(0)[2];
			String chi = findChi(K,fi);
			System.out.println("TRANS "+ non_t+ " fi "+ fi + " chi "+ chi );			
			//identify_rules(fi, chi, K);			
			//internal fi = alpha?
			for(String pre_fi : TestSequence.getAllPrefixesFrom(fi)){
				//if(!CUK_ini.contains(pre_fi)){
					identify_rules(pre_fi, findChi(K,pre_fi), K);
				//}
			}			
			//+++
			System.out.println("RELATIVE " + TestSequence.getNoPrefixes(Relative));	
			System.out.println("RELATIVE " + Relative);	
			
		}
		return true;
	}

public void identify_rules(String fi, String chi, ArrayList<String> K){
	System.out.println("RULE IDENTIFY " + fi + " "+ chi);
	for (String upsilon : TestSet.minus(K, chi)) {
		boolean found = false;
		String upgamma = "";
		String figamma = "";		
		for(String[] node : D3.get(upsilon)){
			if(node[0].equals(fi)){
				found = true;
				upgamma = TestSequence.concat(upsilon, node[1]);
				figamma = TestSequence.concat(fi, node[1]);
				break;
			}
		}
		System.out.println("IDENTIFY up "+ upsilon + " fi " + fi);
		//if exist as T-sep pair
		if(found){
			System.out.println("ADD T-set part 1 " + upgamma + " + "+ figamma);			
			add_relative(figamma, upgamma);
		}else{
			//deal with rules			
			identify_rule_rec(fi, upsilon, K);
		}
	}
				
}
	public void identify_rule_rec(String fi, String upsilon, ArrayList<String> K){
		System.out.println("RULE RECURSIVE " + fi + " "+ upsilon);		
		String[] w = new String[2];
		w[0]=fi;w[1]=upsilon;
		String[] w1 = new String[2];
		w1[0]=upsilon;w1[1]=fi;
		for(String[] y : ident_rel){
			if((y[0].equals(fi) && y[1].equals(upsilon)) 
					|| (y[0].equals(upsilon) && y[1].equals(fi))){
				System.out.println("CLOSED LEAF");
				return;
			}
		}
		if(!open_branch.contains(w)){
			open_branch.add(w);
		}
		if(!open_branch.contains(w1)){
			open_branch.add(w1);
		}
		boolean found = false;
		for(String key : D3.keySet()){
			for(String[] node : D3.get(key)){
				//System.out.println("NODE "+ node[0]);
				String left = "("+upsilon+";"+fi+")";
				String right = "("+fi+";"+upsilon+")";				
				if(node[0].equals(left) || node[0].equals(right)){
					String l = key.substring(1,key.indexOf(";"));
					String r = key.substring(key.indexOf(";")+1,key.length()-1);
					if(!node[0].equals("("+r+";"+l+")") && !node[0].equals("("+l+";"+r+")")){
						System.out.println("up "+ upsilon + " fi " + fi+
								" Deal with "+ node[0] + "|"+ node[1] + " + key " + key);
						
						if(node[1].equals("rule 4a")){
							found = identify_rule4a(key, node, left, right, fi, upsilon, K);							
							if(!found)continue;
							break;
						}
						if(node[1].equals("rule 4b")){
							found = identify_rule4b(key, node, left, right, fi, upsilon, K);
							if(!found)continue;
							break;
						}
						if(node[1].equals("rule 5a")){
							found = identify_rule5a(key, node, left, right, fi, upsilon, K);
							if(!found)continue;
							break;
						}
						if(node[1].equals("rule 5b")){
							found = identify_rule5b(key, node, left, right, fi, upsilon, K);
							if(!found)continue;
							break;
						}
						if(node[1].equals("rule 3")){
							found = identify_rule3(key, node, left, right, fi, upsilon, K);
							if(!found)continue;
							break;
						}
						if(node[1].equals("rule 6")){
							found = identify_rule6(key, node, left, right, fi, upsilon, K);
							if(!found)continue;
							break;
						}
						if(node[1].equals("rule 7")){
							found = identify_rule7(key, node, left, right, fi, upsilon, K);
							if(!found)continue;
							break;
						}
						if(node[1].equals("rule 8")){
							found = identify_rule8(key, node, left, right, fi, upsilon, K);
							if(!found)continue;
							break;
						}
						if(node[1].equals("rule 9")){
							found = identify_rule9(key, node, left, right, fi, upsilon, K);
							if(!found)continue;
							break;
						}
						if(node[1].equals("rule 10")){
							found = identify_rule10(key, node, left, right, fi, upsilon, K);
							if(!found)continue;
							break;
						}
					}					
				}
			}
			if(found) break;
		}
		open_branch.remove(w);
		open_branch.remove(w1);
		if(!ident_rel.contains(w)){
			ident_rel.add(w);
		}
		if(!ident_rel.contains(w1)){
			ident_rel.add(w1);
		}
	}
	
	public boolean identify_rule3(String key, String[] node, String left, String right, 
			String fi, String upsilon, ArrayList<String> K){
		System.out.println("RULE 3 "+ left + " "+ right);						
		String l = key.substring(1,key.indexOf(";"));
		String r = key.substring(key.indexOf(";")+1,key.length()-1);
		if(D.get(l).contains(r)){													
			//check which rule activated it D3
			boolean found = false;
			if(D3.get(l)!=null){
				for(String[] nd3 : D3.get(l)){
					if(nd3[0].equals(r)){
						found = true;
						String lgamma = TestSequence.concat(l, nd3[1]);
						String figamma = TestSequence.concat(r, nd3[1]);
						System.out.println("ADD T-set part 3 " 
								+ lgamma + " + "+ figamma);
						add_relative(figamma, lgamma);
						break;
					}
				}				
			}	
			if(!found){
				for(String[] y : open_branch){
					if((y[0].equals(l) && y[1].equals(r)) 
							|| (y[0].equals(r) && y[1].equals(l))){
						System.out.println("LOOP BRANCH");
						return false;
					}
				}
				identify_rule_rec(l, r, K);
			}
		}else{
			//find recursive
			System.out.println("ERROR RECURSIVE");
		}
		return true;
	}
	
	public boolean identify_rule6(String key, String[] node, String left, String right, 
			String fi, String upsilon, ArrayList<String> K){
		System.out.println("RULE 6 "+ left + " "+ right);			
		String l = key.substring(1,key.indexOf(";"));
		String r = key.substring(key.indexOf(";")+1,key.length()-1);
		if(D.get(l).contains(r)){													
			//check which rule activated it D3
			boolean found = false;
			if(D3.get(l)!=null){
				for(String[] nd3 : D3.get(l)){
					if(nd3[0].equals(r)){
						found = true;
						String lgamma = TestSequence.concat(l, nd3[1]);
						String figamma = TestSequence.concat(r, nd3[1]);
						System.out.println("ADD T-set part 6 " 
								+ lgamma + " + "+ figamma);
						add_relative(figamma, lgamma);
						break;
					}
				}				
			}	
			if(!found){
				for(String[] y : open_branch){
					if((y[0].equals(l) && y[1].equals(r)) 
							|| (y[0].equals(r) && y[1].equals(l))){
						System.out.println("LOOP BRANCH");
						return false;
					}
				}
				identify_rule_rec(l, r, K);
			}
		}else{
			//find recursive
			System.out.println("ERROR RECURSIVE");
		}
		return true;
	}
		
	public boolean identify_rule5a(String key, String[] node, String left, String right, 
			String fi, String upsilon, ArrayList<String> K){
		System.out.println("RULE 5A "+ left + " "+ right);				
		String l = key.substring(1,key.indexOf(";"));
		String r = key.substring(key.indexOf(";")+1,key.length()-1);
		if(D.get(l).contains(r)){			
			//check which rule activate it C3
			if(node[0].equals(left) && !l.equals(fi)){				
				boolean done = identify_rule2(K, fi, l);
				if(!done) return false;
			}if(node[0].equals(right) && !l.equals(upsilon)){
				boolean done = identify_rule2(K, upsilon, l);
				if(!done) return false;
			}																				
			//check which rule activated it D3
			boolean found = false;
			if(D3.get(l)!=null){
				for(String[] nd3 : D3.get(l)){
					if(nd3[0].equals(r)){
						found = true;
						String lgamma = TestSequence.concat(l, nd3[1]);
						String figamma = TestSequence.concat(r, nd3[1]);
						System.out.println("ADD T-set part 5a " 
								+ lgamma + " + "+ figamma);
						add_relative(figamma, lgamma);
						break;
					}
				}				
			}	
			if(!found){
				for(String[] y : open_branch){
					if((y[0].equals(l) && y[1].equals(r)) 
							|| (y[0].equals(r) && y[1].equals(l))){
						System.out.println("LOOP BRANCH");
						return false;
					}
				}
				identify_rule_rec(l, r, K);
			}
		}else{
			//find recursive
			System.out.println("ERROR RECURSIVE");
		}
		return true;
	}
	
	public boolean identify_rule5b(String key, String[] node, String left, String right, 
			String fi, String upsilon, ArrayList<String> K){
		System.out.println("RULE 5B "+ left + " "+ right);						
		String l = key.substring(1,key.indexOf(";"));
		String r = key.substring(key.indexOf(";")+1,key.length()-1);
		if(D.get(l).contains(r)){			
			//check which rule activate it C3
			if(node[0].equals(left)  && !r.equals(fi)){
				boolean done = identify_rule2(K, fi, r);
				if(!done) return false;
			}if(node[0].equals(right)  && !r.equals(upsilon)){
				boolean done = identify_rule2(K, upsilon, r);
				if(!done) return false;
			}																				
			//check which rule activated it D3
			boolean found = false;
			if(D3.get(l)!=null){
				for(String[] nd3 : D3.get(l)){
					if(nd3[0].equals(r)){
						found = true;
						String lgamma = TestSequence.concat(l, nd3[1]);
						String figamma = TestSequence.concat(r, nd3[1]);
						System.out.println("ADD T-set part 5b " 
								+ lgamma + " + "+ figamma);
						add_relative(figamma, lgamma);
						break;
					}
				}				
			}	
			if(!found){
				for(String[] y : open_branch){
					if((y[0].equals(l) && y[1].equals(r)) 
							|| (y[0].equals(r) && y[1].equals(l))){
						System.out.println("LOOP BRANCH");
						return false;
					}
				}
				identify_rule_rec(l, r, K);
			}							
		}else{
			//find recursive
			System.out.println("ERROR RECURSIVE");
		}
		return true;
	}
	
	public boolean identify_rule7(String key, String[] node, String left, String right, 
			String fi, String upsilon, ArrayList<String> K){
		System.out.println("RULE 7 "+ left + " "+ right);				
		String l = key.substring(1,key.indexOf(";"));
		String r = key.substring(key.indexOf(";")+1,key.length()-1);
		if(C.get(l).contains(r)){			
			//check which rule activate it D3
			Pair newpair = new Pair(l,r);			
			String alpha = newpair.getShorter();
			String alphabetagamma = newpair.getlonger();
			newpair = new Pair(fi,upsilon);
			String alphabeta = newpair.getlonger();
			if(TestSequence.isProperPrefixOf(alpha, alphabetagamma)){
				//String betagamma = TestSequence.getSuffixFrom(alphabetagamma, alpha);
				String gamma = TestSequence.getSuffixFrom(alphabetagamma, alphabeta);
				String alphagamma = TestSequence.concat(alpha, gamma);
				boolean found = false;
				if(D3.get(alpha) != null){
					for(String[] nd3 : D3.get(alpha)){
						if(nd3[0].equals(alphagamma)){
							found = true;
							String lgamma = TestSequence.concat(alpha, nd3[1]);
							String figamma = TestSequence.concat(alphagamma, nd3[1]);
							System.out.println("ADD T-set part 7 " 
									+ lgamma + " + "+ figamma);
							add_relative(figamma, lgamma);
							break;
						}
					}
				}								
				if(!found){
					for(String[] y : open_branch){
						if((y[0].equals(alpha) && y[1].equals(alphagamma)) 
								|| (y[0].equals(alphagamma) && y[1].equals(alpha))){
							System.out.println("LOOP BRANCH");
							return false;
						}
					}
					identify_rule_rec(alpha, alphagamma, K);
				}
			}																	
			//check which rule activated it C3
			boolean done = identify_rule2(K, l, r);
			if(!done) return false;
		}else{
			//find recursive
			System.out.println("ERROR RECURSIVE");
		}
		return true;
	}
	
	public boolean identify_rule8(String key, String[] node, String left, String right, 
			String fi, String upsilon, ArrayList<String> K){
		System.out.println("RULE 8 " + left + " "+ right);					
		String l = key.substring(1,key.indexOf(";"));
		String r = key.substring(key.indexOf(";")+1,key.length()-1);
		if(D.get(l).contains(r)){			
			//check which rule activate it C3
			Pair newpair = new Pair(l,r);			
			String alpha = newpair.getShorter();
			String alphagamma = newpair.getlonger();
			newpair = new Pair(fi,upsilon);
			String alphabeta = newpair.getlonger();
			if(TestSequence.isProperPrefixOf(alpha, alphagamma)){
				String gamma = TestSequence.getSuffixFrom(alphagamma, alpha);
				//String beta = TestSequence.getSuffixFrom(alphabeta, alpha);
				String alphabetagamma = TestSequence.concat(alphabeta, gamma);
				boolean done = identify_rule2(K, alpha, alphabetagamma);
				if(!done) return false;
			}																			
			//check which rule activated it D3			
			boolean found = false;
			if(D3.get(l) != null){
				for(String[] nd3 : D3.get(l)){
					if(nd3[0].equals(r)){
						found = true;
						String lgamma = TestSequence.concat(l, nd3[1]);
						String figamma = TestSequence.concat(r, nd3[1]);
						System.out.println("ADD T-set part 8 " 
								+ lgamma + " + "+ figamma);
						add_relative(figamma, lgamma);
						break;
					}
				}
			}			
			if(!found){
				for(String[] y : open_branch){
					if((y[0].equals(l) && y[1].equals(r)) 
							|| (y[0].equals(r) && y[1].equals(l))){
						System.out.println("LOOP BRANCH");
						return false;
					}
				}
				identify_rule_rec(l, r, K);
			}
		}else{
			//find recursive
			System.out.println("ERROR RECURSIVE");
		}
		return true;
	}
	
	public boolean identify_rule9(String key, String[] node, String left, String right, 
			String fi, String upsilon, ArrayList<String> K){
		System.out.println("RULE 9 " + left + " "+ right);			
		String l = key.substring(1,key.indexOf(";"));
		String r = key.substring(key.indexOf(";")+1,key.length()-1);		
		if(C.get(l).contains(r)){			
			//check which rule activate it D3
			Pair newpair = new Pair(l,r);			
			String alpha = newpair.getShorter();
			String alphagamma = newpair.getlonger();
			if(TestSequence.isProperPrefixOf(alpha, alphagamma)){
				String gamma = TestSequence.getSuffixFrom(alphagamma, alpha);
				String beta = "";
				if(fi.equals(alpha)){
					beta = upsilon;
				}else{
					beta = fi;
				}
				String betagamma = TestSequence.concat(beta, gamma);
				
				boolean found = false;
				if(D3.get(beta) != null){
					for(String[] nd3 : D3.get(beta)){
						if(nd3[0].equals(betagamma)){
							found = true;
							String lgamma = TestSequence.concat(beta, nd3[1]);
							String figamma = TestSequence.concat(betagamma, nd3[1]);
							System.out.println("ADD T-set part 9 " 
									+ lgamma + " + "+ figamma);
							add_relative(figamma, lgamma);
							break;
						}
					}
				}								
				if(!found){
					for(String[] y : open_branch){
						if((y[0].equals(beta) && y[1].equals(betagamma)) 
								|| (y[0].equals(betagamma) && y[1].equals(beta))){
							System.out.println("LOOP BRANCH");
							return false;
						}
					}
					identify_rule_rec(beta, betagamma, K);
				}
			}																			
			//check which rule activated it C3
			boolean done = identify_rule2(K, l, r);
			if(!done) return false;
		}else{
			//find recursive
			System.out.println("ERROR RECURSIVE");
		}
		return true;
	}
		
	public boolean identify_rule10(String key, String[] node, String left, String right, 
			String fi, String upsilon, ArrayList<String> K){
		System.out.println("RULE 10 " + left + " "+ right);					
		String l = key.substring(1,key.indexOf(";"));
		String r = key.substring(key.indexOf(";")+1,key.length()-1);
		if(D.get(l).contains(r)){			
			//check which rule activate it C3
			Pair newpair = new Pair(l,r);			
			String beta = newpair.getShorter();
			String betagamma = newpair.getlonger();
			
			if(TestSequence.isProperPrefixOf(beta, betagamma)){
				String gamma = TestSequence.getSuffixFrom(betagamma, beta);								
				String alpha = "";
				if(fi.equals(beta)){
					alpha = upsilon;
				}else{
					alpha = fi;
				}
				String alphagamma = TestSequence.concat(alpha, gamma);				
				boolean done = identify_rule2(K, alpha, alphagamma);
				if(!done) return false;
			}																			
			//check which rule activated it D3			
			boolean found = false;
			if(D3.get(l) != null){
				for(String[] nd3 : D3.get(l)){
					if(nd3[0].equals(r)){
						found = true;
						String lgamma = TestSequence.concat(l, nd3[1]);
						String figamma = TestSequence.concat(r, nd3[1]);
						System.out.println("ADD T-set part 10 " 
								+ lgamma + " + "+ figamma);
						add_relative(figamma, lgamma);
						break;
					}
				}
			}			
			if(!found){
				for(String[] y : open_branch){
					if((y[0].equals(l) && y[1].equals(r)) 
							|| (y[0].equals(r) && y[1].equals(l))){
						System.out.println("LOOP BRANCH");
						return false;
					}
				}
				identify_rule_rec(l, r, K);
			}
		}else{
			//find recursive
			System.out.println("ERROR RECURSIVE");
		}
		return true;
	}
	
	public void add_relative(String arg1, String arg2){
		if(!Relative.contains(arg1)){
			Relative.add(arg1);
		}
		if(!Relative.contains(arg2)){
			Relative.add(arg2);
		}
	}
	
	public boolean identify_rule4a(String key, String[] node, String left, String right, 
			String fi, String upsilon, ArrayList<String> K){
		System.out.println("RULE 4A "+ left + " "+ right);						
		String l = key.substring(1,key.indexOf(";"));
		String r = key.substring(key.indexOf(";")+1,key.length()-1);
		if(C.get(l).contains(r)){			
			//check which rule activate it D3
			if(node[0].equals(left)){				
				boolean found = false;
				if(D3.get(fi)!=null){
					for(String[] nd3 : D3.get(fi)){
						if(nd3[0].equals(l)){
							found = true;
							String lgamma = TestSequence.concat(fi, nd3[1]);
							String figamma = TestSequence.concat(l, nd3[1]);
							System.out.println("ADD T-set part 4a/1 " 
									+ lgamma + " + "+ figamma);
							add_relative(figamma, lgamma);
							break;
						}
					}
				}				
				if(!found){					
					for(String[] y : open_branch){
						if((y[0].equals(fi) && y[1].equals(l)) 
								|| (y[0].equals(l) && y[1].equals(fi))){
							System.out.println("LOOP BRANCH");
							return false;
						}
					}
					identify_rule_rec(fi, l, K);
				}
			}if(node[0].equals(right)){
				boolean found = false;
				if(D3.get(upsilon)!=null){
					for(String[] nd3 : D3.get(upsilon)){
						if(nd3[0].equals(l)){
							found = true;
							String rgamma = TestSequence.concat(upsilon, nd3[1]);
							String figamma = TestSequence.concat(l, nd3[1]);
							System.out.println("ADD T-set part 4a/2 " 
									+ rgamma + " + "+ figamma);						
							add_relative(figamma, rgamma);
							break;
						}
					}
				}				
				if(!found){
					for(String[] y : open_branch){
						if((y[0].equals(upsilon) && y[1].equals(l)) 
								|| (y[0].equals(l) && y[1].equals(upsilon))){
							System.out.println("LOOP BRANCH");
							return false;
						}
					}
					identify_rule_rec(upsilon, l, K);
				}
			}																				
			//check which rule activated it C3
			boolean done = identify_rule2(K, l, r);
			if(!done) return false;
		}else{
			//find recursive
			System.out.println("ERROR RECURSIVE");
		}
		return true;
	}
	
	public boolean identify_rule4b(String key, String[] node, String left, String right, 
			String fi, String upsilon, ArrayList<String> K){
		System.out.println("RULE 4B "+ left + " "+ right);					
		String l = key.substring(1,key.indexOf(";"));
		String r = key.substring(key.indexOf(";")+1,key.length()-1);
		if(C.get(l).contains(r)){			
			//check which rule activate it D3
			if(node[0].equals(left)){
				boolean found = false;
				if(D3.get(fi)!=null){
					for(String[] nd3 : D3.get(fi)){
						if(nd3[0].equals(r)){
							found = true;
							String lgamma = TestSequence.concat(fi, nd3[1]);
							String figamma = TestSequence.concat(r, nd3[1]);
							System.out.println("ADD T-set part 4b/1 " 
									+ lgamma + " + "+ figamma);
							add_relative(figamma, lgamma);
							break;
						}
					}
				}				
				if(!found){
					for(String[] y : open_branch){
						if((y[0].equals(fi) && y[1].equals(r)) 
								|| (y[0].equals(r) && y[1].equals(fi))){
							System.out.println("LOOP BRANCH");
							return false;
						}
					}
					identify_rule_rec(fi, r, K);
				}
			}if(node[0].equals(right)){
				boolean found = false;
				if(D3.get(upsilon)!=null){
					for(String[] nd3 : D3.get(upsilon)){
						if(nd3[0].equals(r)){
							found = true;
							String rgamma = TestSequence.concat(upsilon, nd3[1]);
							String figamma = TestSequence.concat(r, nd3[1]);
							System.out.println("ADD T-set part 4b/2 " 
									+ rgamma + " + "+ figamma);						
							add_relative(figamma, rgamma);
							break;
						}
					}
				}				
				if(!found){
					for(String[] y : open_branch){
						if((y[0].equals(upsilon) && y[1].equals(r)) 
								|| (y[0].equals(r) && y[1].equals(upsilon))){
							System.out.println("LOOP BRANCH");
							return false;
						}
					}
					identify_rule_rec(upsilon, r, K);
				}
			}																				
			//check which rule activated it C3
			boolean done = identify_rule2(K, l, r);
			if(!done) return false;
		}else{
			//find recursive
			System.out.println("ERROR RECURSIVE");
		}
		return true;
	}
	
	public boolean identify_rule2(ArrayList<String> K,	String l, String r){
		System.out.println("RULE 2 " + l + " " + r);
		String[] w = new String[2];
		w[0]=l;w[1]=r;
		String[] w1 = new String[2];
		w1[0]=r;w1[1]=l;		
		for(String[] y : ident_rel){
			if((y[0].equals(l) && y[1].equals(r)
					|| (y[0].equals(r) && y[1].equals(l)))){
				System.out.println("CLOSED LEAF");
				return true;
			}
		}
		for(String[] y : open_branch){
			if((y[0].equals(l) && y[1].equals(r)
					|| (y[0].equals(r) && y[1].equals(l)))){
				System.out.println("LOOP BRANCH");
				return false;
			}
		}		
		if(!open_branch.contains(w)){
			open_branch.add(w);
		}
		if(!open_branch.contains(w1)){
			open_branch.add(w1);
		}
		
		for(String k : C3.keySet()){
			for(String[] nd : C3.get(k)){
				String l1 = "("+l+";"+r+")";
				String r1 = "("+r+";"+l+")";				
				if(nd[0].equals(l1) || nd[0].equals(r1)){
					if(nd[1].equals("rule 2")){
						String l2 = k.substring(1,k.indexOf(";"));
						String r2 = k.substring(k.indexOf(";")+1,k.length()-1);
						add_relative(l, r);
						//se l2 esta em K entao definitivamente existe o par Tn(T)-convergente
						if(K.contains(l2)){
							ArrayList<String> K_UP = TestSet.minus(K, l2);
							open_branch.remove(w);
							open_branch.remove(w1);
							if(!ident_rel.contains(w)){
								ident_rel.add(w);
							}
							if(!ident_rel.contains(w1)){
								ident_rel.add(w1);
							}
							return identify_conv_preserv(K_UP, k, r2, K);
						}if(K.contains(r2)){
							ArrayList<String> K_UP = TestSet.minus(K, r2);
							open_branch.remove(w);
							open_branch.remove(w1);
							if(!ident_rel.contains(w)){
								ident_rel.add(w);
							}
							if(!ident_rel.contains(w1)){
								ident_rel.add(w1);
							}
							return identify_conv_preserv(K_UP, k, l2, K);
						}
						System.out.println("IDENT rule 2 "+ l + " "+ r);						
						boolean done = identify_rule2(K, l2, r2);
						open_branch.remove(w);
						open_branch.remove(w1);
						if(!done){
							return false;
						}else{
							return true;
						}																												
					}
				}
			}
		}		
		boolean done = identify_rule1(K, l, r);
		open_branch.remove(w);
		open_branch.remove(w1);
		if(!done){			
			return false;
		}		
		if(!ident_rel.contains(w)){
			ident_rel.add(w);
		}
		if(!ident_rel.contains(w1)){
			ident_rel.add(w1);
		}
		return true;
	}
	
	public boolean identify_rule1(ArrayList<String> K,	String l, String r){
		System.out.println("RULE 1 " + l + " " + r);
		for(String k : C3.keySet()){
			for(String[] nd : C3.get(k)){
				String l1 = "("+l+";"+r+")";
				String r1 = "("+r+";"+l+")";				
				if(nd[0].equals(l1) || nd[0].equals(r1)){
					if(nd[1].equals("rule 1")){
						String l2 = k.substring(1,k.indexOf(";"));
						String r2 = k.substring(k.indexOf(";")+1,k.length()-1);
						if(!nd[0].equals("("+r2+";"+l2+")")	&& !nd[0].equals("("+l2+";"+r2+")")){
							//identify key
							boolean found = false;
							if(K.contains(l2)){
								ArrayList<String> K_UP = TestSet.minus(K, l2);
								found = identify_conv_preserv(K_UP, k, r2, K);
							}if(K.contains(r2)){
								ArrayList<String> K_UP = TestSet.minus(K, r2);
								found = identify_conv_preserv(K_UP, k, l2, K);
							}
							if(!found){
								boolean done = identify_rule2(K, l2, r2);
								if(!done) return false;
							}
							found = false;							
							//identify combination rule	
							System.out.println("RULE 1 COMBINATION "+ l + " " + r );
							if(nd[0].equals(l1)){
								//System.out.println("RULE 1 COMBINATION 1 "+ l + " " + r );
								if(K.contains(l2)){
									ArrayList<String> K_UP = TestSet.minus(K, l2);
									String k1 = "("+r+";"+l2+")";
									found = identify_conv_preserv(K_UP, k1, r, K);
								}if(K.contains(r)){
									ArrayList<String> K_UP = TestSet.minus(K, r);
									String k1 = "("+l2+";"+r+")";
									found = identify_conv_preserv(K_UP, k1, l2, K);
								}
								if(!found){
									boolean done = identify_rule2(K, l2, r);
									if(!done) return false;
								}
							}
							if(nd[0].equals(r1)){
								//System.out.println("RULE 1 COMBINATION 2 "+ l + " " + r );
								if(K.contains(l2)){
									ArrayList<String> K_UP = TestSet.minus(K, l2);
									String k1 = "("+l+";"+l2+")";
									found = identify_conv_preserv(K_UP, k1, l, K);
								}if(K.contains(l)){
									ArrayList<String> K_UP = TestSet.minus(K, l);
									String k1 = "("+l2+";"+l+")";
									found = identify_conv_preserv(K_UP, k1, l2, K);
								}
								if(!found){
									boolean done = identify_rule2(K, l2, l);
									if(!done) return false;
								}
							}								
							System.out.println("END RULE 1 "+ l + " " + r );
							return true;
						}													
					}
				}
			}
		}
		System.out.println("RULE 1 FALSE");		
		if(K.contains(l)){
			ArrayList<String> K_UP = TestSet.minus(K, findChi(K,r));
			return identify_t_sep(K_UP, r, K);
		}
		if(K.contains(r)){
			ArrayList<String> K_UP = TestSet.minus(K, findChi(K,l));
			return identify_t_sep(K_UP, l, K);
		}
		return false;
	}
	
	public boolean identify_t_sep(ArrayList<String> K_UP, String fi, ArrayList<String> K){
		System.out.println("IDENTIFY T-SEPARATED");		
		for (String upsilon : K_UP) {
			boolean found = false;
			String upgamma = "";
			String figamma = "";
			//is T-sep?
			if(D3.get(fi) != null){
				for(String[] node : D3.get(fi)){
					if(node[0].equals(upsilon)){
						found = true;
						upgamma = TestSequence.concat(upsilon, node[1]);
						figamma = TestSequence.concat(fi, node[1]);
						break;
					}
				}
			}			
			//if exist as T-sep part
			if(found){
				System.out.println("ADD T-set part CON_PRE upsilon "+upsilon +" NOKEY " + upgamma + " + "+ figamma);									
				add_relative(figamma, upgamma);
			}else{
				for(String[] y : open_branch){
					if(y[0].equals(fi) && y[1].equals(upsilon)){
						System.out.println("LOOP BRANCH");
						return false;
					}
				}
				identify_rule_rec(fi, upsilon, K);
			}
		}
		return true;
	}
	
	public boolean identify_conv_preserv(ArrayList<String> K_UP,
			String k, String fi, ArrayList<String> K){
		System.out.println("RULE CON_PRE");		
		for (String upsilon : K_UP) {
			boolean found = false;
			String upgamma = "";
			String figamma = "";
			//is T-sep?
			if(D3.get(fi) != null){
				for(String[] node : D3.get(fi)){
					if(node[0].equals(upsilon)){
						found = true;
						upgamma = TestSequence.concat(upsilon, node[1]);
						figamma = TestSequence.concat(fi, node[1]);
						break;
					}
				}
			}			
			//if exist as T-sep part
			if(found){
				System.out.println("ADD T-set part CON_PRE upsilon "+upsilon +" KEY " + 
						k + " " + upgamma + " + "+ figamma);									
				add_relative(figamma, upgamma);
			}else{
				for(String[] y : open_branch){
					if(y[0].equals(fi) && y[1].equals(upsilon)){
						System.out.println("LOOP BRANCH");
						return false;
					}
				}
				identify_rule_rec(fi, upsilon, K);
			}
		}
		return true;
	}
	
	public void get_C_D_alt0(ArrayList<String> T){
		
		Map<String, ArrayList<String>> C = getIdentityRelation2(T);			
		Map<String, ArrayList<String>> D = getTSeparatedTestPairs3(T);
		Map<String, ArrayList<String[]>> D3 = getTSeparatedTestPairs4(T);
		Map<String, ArrayList<String[]>> C3 = new HashMap<String, ArrayList<String[]>>();
		Map<String, ArrayList<String>> temp_D = new HashMap<String, ArrayList<String>>();
				
		//print_map(D,"D t-sep");
		for (String a : D.keySet()) {
			ArrayList<String> aux = new ArrayList<String>();
			aux.addAll(D.get(a));
			String b = a;
			temp_D.put(b, aux); 
		}
		
		ruler = new Ruler(C, D, T, fsm, C3, D3);		
		for (String a : temp_D.keySet()) {
			for (String b : temp_D.get(a)) {				
				ruler.applyRules5(new Pair(a,b), AddedTo.D);			
			}			
		}
		print_map3(D3,"D3 before T-sep alpha->beta|gamma");
		print_map3(C3,"C3 before T-sep alpha->beta|gamma");
		//print_map(C,"C");
		//print_map(D,"D");
		ArrayList<String> K = new ArrayList<String>();			
		int n = fsm.getStates().size();
		while (K.size() < Math.min(p + 1, n)) // CONDITION 1
		{
			step02b(T, C, D, K);						
		}
		System.out.println("K "+ K);
		
		//-------STEP  3 -------			
		CunionK = findCunionK2(C, K);							
		Pair p_fichi = findFiChi3(T, CunionK, K, D);
		while(p_fichi != null) {			
			if (HashList.add_pair_hash(C, p_fichi.getLeft(), p_fichi.getRight())) {
				ruler.applyRules5(p_fichi, AddedTo.C);
				System.out.println("ADD " + p_fichi);
			}
			CunionK = findCunionK2(C, K);						
			p_fichi = findFiChi3(T, CunionK, K, D);
		}
		
		//analyze data 
		System.out.println("CunionK "+ CunionK);
		//print_set(CunionK,"CunionK");
		//print_map(C,"C");
		//print_map(D,"D");
		
		ArrayList<Transition> trans = fsm.getTransitions();
		Map<Transition, ArrayList<String[]>> requirement = new HashMap<Transition, ArrayList<String[]>>();		
		for(String test : CunionK)
		{
			ArrayList<Transition> current = fsm.reachedTransitionsWithSequence(fsm.getInitialState(), test);
			
			if(current.size() != 0)
			{
				Transition t = current.get(current.size() - 1); //get the last
				String x = t.getInput();
				String alpha = TestSequence.getPrefixFrom(test, x);
				String[] node = new String[3];
				node[0] = t.toString();
				node[1] = alpha;
				node[2] = test;				
				if(requirement.keySet().contains(t)){
					requirement.get(t).add(node);
				}else{
					ArrayList<String[]> list = new ArrayList<String[]>();
					list.add(node);
					requirement.put(t, list);
				}		
			}
		}
		print_map2(requirement,"requirement");
		//print_map3(C3,"C3");
		print_map3(D3,"D3");
		
				
		FsmCoverage coverage = new FsmCoverage(fsm);
		System.out.println("coverage get-C_D: "
				+ coverage.transitionCoverage(CunionK));
	}
	
	public void get_C_D_alt1(ArrayList<String> T){
			
		Map<String, ArrayList<String>> C = getIdentityRelation2(T);			
		Map<String, ArrayList<String>> D = getTSeparatedTestPairs3(T);
		Map<String, ArrayList<String>> temp_D = new HashMap<String, ArrayList<String>>();
				
		for (String a : D.keySet()) {
			ArrayList<String> aux = new ArrayList<String>();
			aux.addAll(D.get(a));
			String b = a;
			temp_D.put(b, aux); 
		}
		
		ruler = new Ruler(C, D, T, fsm);		
		for (String a : temp_D.keySet()) {
			for (String b : temp_D.get(a)) {				
				ruler.applyRules3(new Pair(a,b), AddedTo.D);			
			}			
		}
		
		//if(HashList.pair_hash_in(D, "SM,DM,F", "SM,F")){
		//	System.out.println(" GOT OTHER D !");
		//}
			
		ArrayList<String> K = new ArrayList<String>();			
		int n = fsm.getStates().size();
		while (K.size() < Math.min(p + 1, n)) // CONDITION 1
		{
			step02b(T, C, D, K);						
		}
		
		//-------STEP  3 -------			
		CunionK = findCunionK2(C, K);							
		Pair p_fichi = findFiChi3(T, CunionK, K, D);
		while(p_fichi != null) {					
			if (HashList.add_pair_hash(C, p_fichi.getLeft(), p_fichi.getRight())) {
				ruler.applyRules3(p_fichi, AddedTo.C); 
			}
			if(HashList.pair_hash_in(D, "SM,DM,F", "SM,F")){
				System.out.println(" TRIGGER fi_chi !" + p_fichi);
			}
			CunionK = findCunionK2(C, K);						
			p_fichi = findFiChi3(T, CunionK, K, D);
		}
		//System.out.println("CunionK "+ CunionK);
		C_data.clear();
		D_data.clear();
		for (String a : C.keySet()) {
			ArrayList<String> aux = new ArrayList<String>();
			aux.addAll(C.get(a));			
			C_data.put(a, aux); 
		}
		for (String a : D.keySet()) {
			ArrayList<String> aux = new ArrayList<String>();
			aux.addAll(D.get(a));			
			D_data.put(a, aux); 
		}
		//if(HashList.pair_hash_in(D, "SM,DM,F", "SM,F")){
		//	System.out.println(" GOT OTHER D 2 !");
		//}
		FsmCoverage coverage = new FsmCoverage(fsm);
		System.out.println("coverage get-C_D: "
				+ coverage.transitionCoverage(CunionK));
	}
	
	public ArrayList<String> findK3(ArrayList<String> T, Map<String, ArrayList<String>> D) {
		DivergenceGraph dg = new DivergenceGraph(T, D, fsm.getNumberOfStates());
		ArrayList<String> K = dg.getK();
		return K;
	}
	
	public void step02c(ArrayList<String> T, ArrayList<String> T4, Map<String, ArrayList<String>> C,
			Map<String, ArrayList<String>> D, ArrayList<String> K) {
		
		String alpha = selectAlpha(K);
	
		for (String beta : K) {	
			if(!HashList.pair_hash_in(D,alpha,beta)){
				
				ArrayList<String> alpha_ext = getExtensionsFrom(T4, alpha);
				ArrayList<String> beta_ext = getExtensionsFrom(T4, beta);
			
				for (String gamma : getCommonSufix(alpha, beta, alpha_ext,
						beta_ext)) {						
					State sa = fsm.nextStateWithSequence(
							fsm.getInitialState(), alpha);
					State sb = fsm.nextStateWithSequence(
							fsm.getInitialState(), beta);
					if (fsm.separe(gamma, sa, sb) && !HashList.pair_hash_in(D,alpha, beta)) {
						String seq1 = TestSequence.concat(alpha, gamma);
						String seq2 = TestSequence.concat(beta, gamma);
						if(T4.contains(seq1) && T4.contains(seq2)){	
							TestSet.addAllPrefsOf(T, seq1);
							TestSet.addAllPrefsOf(T, seq2);
							
							TestSet.addAllPrefsOf(Relative, seq1);
							TestSet.addAllPrefsOf(Relative, seq2);
							
							updateC2(T, C);
						
							Pair p_alphabeta = new Pair(alpha, beta);
							if (HashList.add_pair_hash(D, alpha, beta)) {
								ruler.applyRules3(p_alphabeta, AddedTo.D); 
							}
							break;
						}
					}
				}
			}
		}
		K.add(alpha);
	}
	
	public Pair step04c(String fi, ArrayList<String> K, 
			Map<String, ArrayList<String>> D, Map<String, ArrayList<String>> D4,
			Map<String, ArrayList<String>> C, Map<String, ArrayList<String>> C4,
			ArrayList<String> T, ArrayList<String> T4) {
	
		String chi = findChi(K, fi);

		for (String upsilon : TestSet.minus(K, chi)) {			
			if(!HashList.pair_hash_in(D,upsilon, fi))
			{
				System.out.println("up " + upsilon +" chi " + chi + " fi " + fi);
				
				ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C);
				ArrayList<String> Cfi = HashList.getPartition(fi, C); 
				System.out.println(" Cupsilon" + Cupsilon);
				System.out.println(" Cfi" + Cfi);
				boolean found = false;
				for(String alpha : Cupsilon){
					//for(String beta : Cfi){
					String beta = Cfi.get(0);
						ArrayList<String> alpha_ext = getExtensionsFrom(T4, alpha);
						ArrayList<String> beta_ext = getExtensionsFrom(T4, beta);
					
						for (String gamma : getCommonSufix(alpha, beta, alpha_ext,
								beta_ext)) {						
							State sa = fsm.nextStateWithSequence(
									fsm.getInitialState(), alpha);
							State sb = fsm.nextStateWithSequence(
									fsm.getInitialState(), beta);
							if (fsm.separe(gamma, sa, sb) && !HashList.pair_hash_in(D,alpha, beta)
									&& HashList.pair_hash_in(D4,alpha, beta)) {
								String seq1 = TestSequence.concat(alpha, gamma);
								String seq2 = TestSequence.concat(beta, gamma);
								if(T4.contains(seq1) && T4.contains(seq2)){	
									found = true;
									TestSet.addAllPrefsOf(T, seq1);
									TestSet.addAllPrefsOf(T, seq2);
									System.out.println(" add test seq " + seq1 + " + " +seq2);
									
									TestSet.addAllPrefsOf(Relative, seq1);
									TestSet.addAllPrefsOf(Relative, seq2);
				
									updateC2(T, C);	
								/*	if(!HashList.pair_hash_in(C,alpha, upsilon)){
										System.out.println(" alpha, upsilon " + alpha + " + " +upsilon);
										Pair p_alpha_up = new Pair(alpha, upsilon);									
										if(HashList.add_pair_hash(C, alpha, upsilon)){
											ruler.applyRules3(p_alpha_up, AddedTo.C); 
										}
										step04d(alpha, upsilon, K, D, C, T);
									}	
									if(!HashList.pair_hash_in(C,beta, fi)){
										System.out.println(" beta, fi " + beta + " + " +fi);
										Pair p_beta_fi = new Pair(beta, fi);									
										if(HashList.add_pair_hash(C, beta, fi)){
											ruler.applyRules3(p_beta_fi, AddedTo.C); 
										}
										step04d(alpha, upsilon, K, D, C, T);
									}
									Pair p_alphabeta = new Pair(alpha, beta);									
									if(HashList.add_pair_hash(D, alpha, beta)){
										ruler.applyRules3(p_alphabeta, AddedTo.D); 
									}*/
									break;
								}
							}
						}if(found) break;
					//}if(found) break;				
				}
				if(!found){
					Cupsilon = HashList.getPartition(upsilon, C4);
					Cfi = HashList.getPartition(fi, C);				
					if(Cfi.size() > 0 && Cupsilon.size() > 0){				
						for(String alpha : Cupsilon){						
							//for(String beta : Cfi){
							String beta = Cfi.get(0);
								ArrayList<String> alpha_ext = getExtensionsFrom(T4, alpha);
								ArrayList<String> beta_ext = getExtensionsFrom(T4, beta);
							
								for (String gamma : getCommonSufix(alpha, beta, alpha_ext,
										beta_ext)) {						
									State sa = fsm.nextStateWithSequence(
											fsm.getInitialState(), alpha);
									State sb = fsm.nextStateWithSequence(
											fsm.getInitialState(), beta);
									if (fsm.separe(gamma, sa, sb) && !HashList.pair_hash_in(D,alpha, beta)
											&& HashList.pair_hash_in(D4,alpha, beta)) {
										String seq1 = TestSequence.concat(alpha, gamma);
										String seq2 = TestSequence.concat(beta, gamma);
										if(T4.contains(seq1) && T4.contains(seq2)){	
											found = true;
											TestSet.addAllPrefsOf(T, seq1);
											TestSet.addAllPrefsOf(T, seq2);
											System.out.println(" add test full 0 " + seq1 + " + " +seq2);
											
											TestSet.addAllPrefsOf(Relative, seq1);
											TestSet.addAllPrefsOf(Relative, seq2);
											
											updateC2(T, C);
										/*	if(!HashList.pair_hash_in(C,alpha, upsilon)){
												System.out.println(" alpha, upsilon " + alpha + " + " +upsilon);
												Pair p_alpha_up = new Pair(alpha, upsilon);									
												if(HashList.add_pair_hash(C, alpha, upsilon)){
													ruler.applyRules3(p_alpha_up, AddedTo.C); 
												}
												step04d(alpha, upsilon, K, D, C, T);
											}	
											if(!HashList.pair_hash_in(C,beta, fi)){
												System.out.println(" beta, fi " + beta + " + " +fi);
												Pair p_beta_fi = new Pair(beta, fi);									
												if(HashList.add_pair_hash(C, beta, fi)){
													ruler.applyRules3(p_beta_fi, AddedTo.C); 
												}
												step04d(alpha, upsilon, K, D, C, T);
											}
											Pair p_alphabeta = new Pair(alpha, beta);									
											if(HashList.add_pair_hash(D, alpha, beta)){
												ruler.applyRules3(p_alphabeta, AddedTo.D); 
											}*/
											break;
										}
									}
								}if(found) break;
							//}if(found) break;
						}
					}
				}
				if(!found){
					Cupsilon = HashList.getPartition(upsilon, C4);
					Cfi = HashList.getPartition(fi, C4);				
					if(Cfi.size() > 0 && Cupsilon.size() > 0){				
						for(String alpha : Cupsilon){						
							for(String beta : Cfi){	
								ArrayList<String> alpha_ext = getExtensionsFrom(T4, alpha);
								ArrayList<String> beta_ext = getExtensionsFrom(T4, beta);
							
								for (String gamma : getCommonSufix(alpha, beta, alpha_ext,
										beta_ext)) {						
									State sa = fsm.nextStateWithSequence(
											fsm.getInitialState(), alpha);
									State sb = fsm.nextStateWithSequence(
											fsm.getInitialState(), beta);
									if (fsm.separe(gamma, sa, sb) && !HashList.pair_hash_in(D,alpha, beta)
											&& HashList.pair_hash_in(D4,alpha, beta)) {
										String seq1 = TestSequence.concat(alpha, gamma);
										String seq2 = TestSequence.concat(beta, gamma);
										if(T4.contains(seq1) && T4.contains(seq2)){	
											found = true;
											TestSet.addAllPrefsOf(T, seq1);
											TestSet.addAllPrefsOf(T, seq2);
											System.out.println(" add test full 1 " + seq1 + " + " +seq2);
											
											TestSet.addAllPrefsOf(Relative, seq1);
											TestSet.addAllPrefsOf(Relative, seq2);
											
											updateC2(T, C);
										/*	if(!HashList.pair_hash_in(C,alpha, upsilon)){
												System.out.println(" alpha, upsilon " + alpha + " + " +upsilon);
												Pair p_alpha_up = new Pair(alpha, upsilon);									
												if(HashList.add_pair_hash(C, alpha, upsilon)){
													ruler.applyRules3(p_alpha_up, AddedTo.C); 
												}
												step04d(alpha, upsilon, K, D, C, T);
											}	
											if(!HashList.pair_hash_in(C,beta, fi)){
												System.out.println(" beta, fi " + beta + " + " +fi);
												Pair p_beta_fi = new Pair(beta, fi);									
												if(HashList.add_pair_hash(C, beta, fi)){
													ruler.applyRules3(p_beta_fi, AddedTo.C); 
												}
												step04d(alpha, upsilon, K, D, C, T);
											}
											Pair p_alphabeta = new Pair(alpha, beta);									
											if(HashList.add_pair_hash(D, alpha, beta)){
												ruler.applyRules3(p_alphabeta, AddedTo.D); 
											}*/
											break;
										}
									}
								}if(found) break;
							}if(found) break;
						}
					}
				}			
				if(!found){
					System.out.println("ERROR!!!!");
				}
			}
		}
		return new Pair(fi, chi);
	}
	
	public Pair step04d(String fi, String chi, ArrayList<String> K, Map<String, ArrayList<String>> D,
			Map<String, ArrayList<String>> C, ArrayList<String> T) {
	
		for (String upsilon : TestSet.minus(K, chi)) {			
			if(!HashList.pair_hash_in(D,upsilon, fi))
			{
				ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C);
				ArrayList<String> Cfi = HashList.getPartition(fi, C); 
			
				String alpha = Cupsilon.get(0);
				String beta = Cfi.get(0);

				CostTuple tuple = selectGamma2(alpha, beta, T, C);
				String gamma = tuple.getGamma();
				alpha = tuple.getAlpha();
				beta = tuple.getBeta();

				if (gamma != null) {
					String seq1 = TestSequence.concat(alpha, gamma);
					String seq2 = TestSequence.concat(beta, gamma);

					TestSet.addAllPrefsOf(T, seq1);
					TestSet.addAllPrefsOf(T, seq2);
					
					TestSet.addAllPrefsOf(Relative, seq1);
					TestSet.addAllPrefsOf(Relative, seq2);

					updateC2(T, C);

					Pair p_alphabeta = new Pair(alpha, beta);
					System.out.println("extra D "+alpha + " -> " +beta);
					System.out.println("extra D "+seq1 + " -> " +seq2);					
					if(HashList.add_pair_hash(D, alpha, beta)){
						ruler.applyRules3(p_alphabeta, AddedTo.D); 
					}
				}
			}
		}
		return new Pair(fi, chi);
	}
	
	public Pair step04c_old2(String fi, ArrayList<String> K, Map<String, ArrayList<String>> D,
			Map<String, ArrayList<String>> C, Map<String, ArrayList<String>> C4,
			ArrayList<String> T, ArrayList<String> T4) {
	
		String chi = findChi(K, fi);

		for (String upsilon : TestSet.minus(K, chi)) {			
			if(!HashList.pair_hash_in(D,upsilon, fi))
			{
				System.out.println("up " + upsilon +" chi " + chi + " fi " + fi);
				
				ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C);
				ArrayList<String> Cfi = HashList.getPartition(fi, C); 				
				boolean found = false;
				for(String alpha : Cupsilon){
					for(String beta : Cfi){
						CostTuple tuple = selectGamma2(alpha, beta, T, C);
						String gamma = tuple.getGamma();
						alpha = tuple.getAlpha();
						beta = tuple.getBeta();
		
						if (gamma != null) {
							String seq1 = TestSequence.concat(alpha, gamma);
							String seq2 = TestSequence.concat(beta, gamma);
							
							if(T4.contains(seq1) && T4.contains(seq2)){
								found = true;
								TestSet.addAllPrefsOf(T, seq1);
								TestSet.addAllPrefsOf(T, seq2);
								System.out.println(" add test ini " + seq1 + " + " +seq2);
								
								TestSet.addAllPrefsOf(Relative, seq1);
								TestSet.addAllPrefsOf(Relative, seq2);
			
								updateC2(T, C);
			
								Pair p_alphabeta = new Pair(alpha, beta);									
								if(HashList.add_pair_hash(D, alpha, beta)){
									ruler.applyRules3(p_alphabeta, AddedTo.D); 
								}
								break;
							}
						}if(found) break;
					}if(found) break;				
				}
				if(!found){
					Cupsilon = HashList.getPartition(upsilon, C4);
					Cfi = HashList.getPartition(fi, C4);				
					if(Cfi.size() > 0 && Cupsilon.size() > 0){				
						for(String alpha : Cupsilon){						
							for(String beta : Cfi){	
								ArrayList<String> alpha_ext = getExtensionsFrom(T4, alpha);
								ArrayList<String> beta_ext = getExtensionsFrom(T4, beta);
							
								for (String gamma : getCommonSufix(alpha, beta, alpha_ext,
										beta_ext)) {						
									State sa = fsm.nextStateWithSequence(
											fsm.getInitialState(), alpha);
									State sb = fsm.nextStateWithSequence(
											fsm.getInitialState(), beta);
									if (fsm.separe(gamma, sa, sb)) {
										String seq1 = TestSequence.concat(alpha, gamma);
										String seq2 = TestSequence.concat(beta, gamma);
										if(T4.contains(seq1) && T4.contains(seq2)){	
											found = true;
											TestSet.addAllPrefsOf(T, seq1);
											TestSet.addAllPrefsOf(T, seq2);
											System.out.println(" add test full" + seq1 + " + " +seq2);
											
											TestSet.addAllPrefsOf(Relative, seq1);
											TestSet.addAllPrefsOf(Relative, seq2);
						
											updateC2(T, C);
						
											Pair p_alphabeta = new Pair(alpha, beta);									
											if(HashList.add_pair_hash(D, alpha, beta)){
												ruler.applyRules3(p_alphabeta, AddedTo.D); 
											}
											break;
										}
									}
								}if(found) break;
							}if(found) break;
						}
					}
				}				
				if(!found){
					Cupsilon = HashList.getPartition(upsilon, C);
					Cfi = HashList.getPartition(fi, C); 
					String alpha = Cupsilon.get(0);
					String beta = Cfi.get(0);
					
					CostTuple tuple = selectGamma2(alpha, beta, T, C);
					String gamma = tuple.getGamma();
					alpha = tuple.getAlpha();
					beta = tuple.getBeta();
	
					if (gamma != null) {
						String seq1 = TestSequence.concat(alpha, gamma);
						String seq2 = TestSequence.concat(beta, gamma);
						System.out.println(" not found test " + seq1 + " + " +seq2);
						TestSet.addAllPrefsOf(T, seq1);
						TestSet.addAllPrefsOf(T, seq2);
	
						updateC2(T, C);
	
						Pair p_alphabeta = new Pair(alpha, beta);									
						if(HashList.add_pair_hash(D, alpha, beta)){
							ruler.applyRules3(p_alphabeta, AddedTo.D); 
						}
					}
				}
			}
		}
		return new Pair(fi, chi);
	}
	
	public Pair step04c_old(String fi, ArrayList<String> K, Map<String, ArrayList<String>> D,
			Map<String, ArrayList<String>> C, ArrayList<String> T, ArrayList<String> T4) {
	
		String chi = findChi(K, fi);

		for (String upsilon : TestSet.minus(K, chi)) {			
			if(!HashList.pair_hash_in(D,upsilon, fi))
			{
				System.out.println("up " + upsilon +" chi " + chi + " fi " + fi);
				ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C);
				ArrayList<String> Cfi = HashList.getPartition(fi, C); 				
				boolean found = false;
				for(String alpha : Cupsilon){
					String beta = Cfi.get(0);
	
					CostTuple tuple = selectGamma2(alpha, beta, T, C);
					String gamma = tuple.getGamma();
					alpha = tuple.getAlpha();
					beta = tuple.getBeta();
	
					if (gamma != null) {
						String seq1 = TestSequence.concat(alpha, gamma);
						String seq2 = TestSequence.concat(beta, gamma);
						
						if(T4.contains(seq1) && T4.contains(seq2)){
							found = true;
							TestSet.addAllPrefsOf(T, seq1);
							TestSet.addAllPrefsOf(T, seq2);
							System.out.println(" add test " + seq1 + " + " +seq2);
							
							TestSet.addAllPrefsOf(Relative, seq1);
							TestSet.addAllPrefsOf(Relative, seq2);
		
							updateC2(T, C);
		
							Pair p_alphabeta = new Pair(alpha, beta);									
							if(HashList.add_pair_hash(D, alpha, beta)){
								ruler.applyRules3(p_alphabeta, AddedTo.D); 
							}
							break;
						}
					}
				}
				if(!found){
					String alpha = Cupsilon.get(0);
					String beta = Cfi.get(0);
					
					CostTuple tuple = selectGamma2(alpha, beta, T, C);
					String gamma = tuple.getGamma();
					alpha = tuple.getAlpha();
					beta = tuple.getBeta();
	
					if (gamma != null) {
						String seq1 = TestSequence.concat(alpha, gamma);
						String seq2 = TestSequence.concat(beta, gamma);
						System.out.println(" not found test " + seq1 + " + " +seq2);
						TestSet.addAllPrefsOf(T, seq1);
						TestSet.addAllPrefsOf(T, seq2);
	
						updateC2(T, C);
	
						Pair p_alphabeta = new Pair(alpha, beta);									
						if(HashList.add_pair_hash(D, alpha, beta)){
							ruler.applyRules3(p_alphabeta, AddedTo.D); 
						}
					}
				}
			}
		}
		return new Pair(fi, chi);
	}
	
	private String step05c(Transition transition, ArrayList<String> K,
			ArrayList<String> T, ArrayList<String> T4,
			Map<String, ArrayList<String>> C, Map<String, ArrayList<String>> C4,
			Map<String, ArrayList<String>> D, Map<String, ArrayList<String>> D4) {
		
		//FsmCoverage coverage = new FsmCoverage(fsm);
				
		// select the transition
		//Transition transition = selectTransition(CunionK, coverage, T);
		State s = transition.getIn();
		//System.out.println("T4 " + T4);
		for (String alpha1 : T4) {			
			if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha1) == s) {
				String alphax = TestSequence.concat(alpha1,
						transition.getInput());
				System.out.println("alpha1 " + alpha1);
				// sometimes T4 does not contain alphax but one in C4				
				if(T4.contains(alphax)){					
					System.out.println("point 1");		
					String fi = alphax;
					String chi = findChi(K, fi);
					if(!HashList.pair_hash_in(C, fi, chi)){	
					//if(!HashList.pair_hash_in(C, alpha1, findChi(K, alpha1))){		
						System.out.println("Add fi step 5 *******");
						TestSet.addAllPrefsOf(T, fi);
						TestSet.addAllPrefsOf(Relative, fi);
						updateC2(T, C);
						updateD2(D, T, fi);
												
						for (String upsilon : TestSet.minus(K, chi)) {							
							ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C4);
							ArrayList<String> Cfi = HashList.getPartition(fi, C4); 
							
							System.out.println("Cupsilon " + Cupsilon);
							System.out.println("Cfi " + Cfi);
							boolean found = false;
									
							for(String alpha : Cupsilon){
								for(String beta : Cfi){
									ArrayList<String> alpha_ext = getExtensionsFrom(T4, alpha);
									ArrayList<String> beta_ext = getExtensionsFrom(T4, beta);									
									for (String gamma : getCommonSufix(alpha, beta, alpha_ext,
											beta_ext)) {						
										State sa = fsm.nextStateWithSequence(
												fsm.getInitialState(), alpha);
										State sb = fsm.nextStateWithSequence(
												fsm.getInitialState(), beta);
										String seq1 = TestSequence.concat(alpha, gamma);
										String seq2 = TestSequence.concat(beta, gamma);
										String[] y = beta.split(",");																				
										if (fsm.separe(gamma, sa, sb) && !CunionK.contains(beta)
												&& !HashList.pair_hash_in(C, beta, chi)
												&& y[y.length-1].equals(transition.getInput())
												//&& t_beta.containsAll(t_alphax)
												&& T4.contains(seq1) && T4.contains(seq2)) {											
											
											if(!HashList.pair_hash_in(D, alpha, beta)){												
												TestSet.addAllPrefsOf(T, seq1);
												TestSet.addAllPrefsOf(T, seq2);
												System.out.println(" add test seq " + seq1 + " + " +seq2);
												
												TestSet.addAllPrefsOf(Relative, seq1);
												TestSet.addAllPrefsOf(Relative, seq2);
							
												updateC2(T, C);	
												System.out.println("MODE 1");
											
												Pair p_alphabeta = new Pair(alpha, beta);									
												if(HashList.add_pair_hash(D, alpha, beta)){
													ruler.applyRules3(p_alphabeta, AddedTo.D); 
												}
											}
											
											System.out.println("upsilon "+ upsilon + " alpha " + alpha + " beta " +beta + " gamma "+ gamma);
											found = true;
											break;
										}
									}if(found) break;
								}if(found) break;
							}							
						}						
						System.out.println("TRY BETA");
						Pair p_fi_chi = new Pair(fi, chi);
						if(HashList.add_pair_hash(C, fi, chi)){
							ruler.applyRules3(p_fi_chi, AddedTo.C);
						}
						System.out.println("ADDED");
						return alphax;
					}
				}
			}
		}		
		return null;
	}
	
	private String[] find_sep3(ArrayList<String> Cupsilon, ArrayList<String> Cfi,
			String upsilon, String fi, String chi, Transition transition, FsmCoverage coverage, 
			ArrayList<String> T4, Map<String, ArrayList<String>> D, Map<String, ArrayList<String>> D4,
			ArrayList<String> K, Map<String, ArrayList<String>> C, Map<String, ArrayList<String>> C4){
		
		for(String beta : Cfi){
			for(String alpha : Cupsilon){
			//String alpha = upsilon;
				State s1 = fsm.nextStateWithSequence(fsm.getInitialState(), upsilon);
				State s2 = fsm.nextStateWithSequence(fsm.getInitialState(), alpha);				
				if(s1.equals(s2)){
					ArrayList<String> alpha_ext = getExtensionsFrom(T4, alpha);
					ArrayList<String> beta_ext = getExtensionsFrom(T4, beta);									
					for (String gamma : getCommonSufix(alpha, beta, alpha_ext,
							beta_ext)) {						
																		
						ArrayList<Transition> current = fsm.reachedTransitionsWithSequence(fsm.getInitialState(), fi);
						ArrayList<Transition> current2 = fsm.reachedTransitionsWithSequence(fsm.getInitialState(), beta);
						ArrayList<String> set_beta = new ArrayList<String>();										
						set_beta.add(beta);									
						ArrayList<Transition> t_beta = coverage.getCoveredtransitions(set_beta);
						
						if (HashList.pair_hash_in(D4, alpha, beta)								
								&& t_beta.contains(transition)
								//&& current.get(current.size() - 1).equals(current2.get(current2.size() - 1))								
								//&& !HashList.pair_hash_in(C, beta, findChi(K, beta))
								&& !HashList.pair_hash_in(D, fi, upsilon)
								) {
							String[] a = new String[4];
							a[0] = upsilon;
							a[1] = alpha;
							a[2] = beta;
							a[3] = gamma;											
							System.out.println("upsilon 2 "+ upsilon + " alpha " + alpha + " beta " +beta + " gamma "+ gamma);
							return a;
						}
					}
				}				
			}
		}
		
		return null;
	}
	
	private String[] find_sep2(ArrayList<String> Cupsilon, ArrayList<String> Cfi,
			String upsilon, String fi, String chi, Transition transition, FsmCoverage coverage, 
			ArrayList<String> T4, Map<String, ArrayList<String>> D, Map<String, ArrayList<String>> D4,
			ArrayList<String> K, Map<String, ArrayList<String>> C, Map<String, ArrayList<String>> C4){
		
		for(String beta : Cfi){
			for(String alpha : Cupsilon){
			//String alpha = upsilon;
				
				ArrayList<String> set_beta = new ArrayList<String>();										
				set_beta.add(beta);									
				ArrayList<Transition> t_beta = coverage.getCoveredtransitions(set_beta);
				
				ArrayList<Transition> current = fsm.reachedTransitionsWithSequence(fsm.getInitialState(), fi);
				ArrayList<Transition> current2 = fsm.reachedTransitionsWithSequence(fsm.getInitialState(), beta);
				//ArrayList<String> alpha_ext = getExtensionsFrom(T4, alpha);
				//ArrayList<String> beta_ext = getExtensionsFrom(T4, beta);
				
				// se a estensao de beta 
								
				if (HashList.pair_hash_in(D4, alpha, beta)								
						&& t_beta.contains(transition)
						&& current.get(current.size() - 1).equals(current2.get(current2.size() - 1))
						&& !HashList.pair_hash_in(C, beta, findChi(K, beta))
						//&& HashList.pair_hash_in(C4, fi, beta)
						&& TestSequence.isProperPrefixOf(fi, beta)
						&& TestSequence.isProperPrefixOf(upsilon, alpha)
						) {
					String[] a = new String[4];
					a[0] = upsilon;
					a[1] = alpha;
					a[2] = beta;
					a[3] = "";											
					System.out.println("upsilon0 "+ upsilon + " alpha " + alpha + " beta " +beta);
					return a;
				}		
			}
		}
		return null;
	}
	
	private String[] find_sep(ArrayList<String> Cupsilon, ArrayList<String> Cfi,
			String upsilon, String fi, String chi, Transition transition, FsmCoverage coverage, 
			ArrayList<String> T4, Map<String, ArrayList<String>> D, Map<String, ArrayList<String>> D4,
			ArrayList<String> K, Map<String, ArrayList<String>> C, Map<String, ArrayList<String>> C4){
		
		for(String beta : Cfi){
			//for(String alpha : Cupsilon){
			String alpha = upsilon;
				State s1 = fsm.nextStateWithSequence(fsm.getInitialState(), upsilon);
				State s2 = fsm.nextStateWithSequence(fsm.getInitialState(), alpha);				
				if(s1.equals(s2)){
					ArrayList<String> alpha_ext = getExtensionsFrom(T4, alpha);
					ArrayList<String> beta_ext = getExtensionsFrom(T4, beta);									
					for (String gamma : getCommonSufix(alpha, beta, alpha_ext,
							beta_ext)) {						
						State sa = fsm.nextStateWithSequence(
								fsm.getInitialState(), alpha);
						State sb = fsm.nextStateWithSequence(
								fsm.getInitialState(), beta);
						//String seq1 = TestSequence.concat(alpha, gamma);
						//String seq2 = TestSequence.concat(beta, gamma);
						
						ArrayList<Transition> current = fsm.reachedTransitionsWithSequence(fsm.getInitialState(), fi);
						ArrayList<Transition> current2 = fsm.reachedTransitionsWithSequence(fsm.getInitialState(), beta);
						ArrayList<String> set_beta = new ArrayList<String>();										
						set_beta.add(beta);									
						ArrayList<Transition> t_beta = coverage.getCoveredtransitions(set_beta);
						
						if (fsm.separe(gamma, sa, sb)
								&& HashList.pair_hash_in(D4, alpha, beta)								
								&& t_beta.contains(transition)
								&& current.get(current.size() - 1).equals(current2.get(current2.size() - 1))
								//&& T4.contains(seq1) && T4.contains(seq2)
								&& !HashList.pair_hash_in(C, beta, findChi(K, beta))
								) {
							String[] a = new String[4];
							a[0] = upsilon;
							a[1] = alpha;
							a[2] = beta;
							a[3] = gamma;											
							System.out.println("upsilon "+ upsilon + " alpha " + alpha + " beta " +beta + " gamma "+ gamma);
							return a;
						}
						//for(String ext : beta_ext){
						//	if(HashList.pair_hash_in(C4, beta, ext)){
								
						//	}
						//}
						
					}
				}				
			//}
		}
		/*ArrayList<String> alpha_ext = getExtensionsFrom(T4, upsilon);
		ArrayList<String> beta_ext = getExtensionsFrom(T4, fi);									
		for (String gamma : getCommonSufix(upsilon, fi, alpha_ext,
				beta_ext)) {						
		
			String seq1 = TestSequence.concat(upsilon, gamma);
			String seq2 = TestSequence.concat(fi, gamma);
			
			ArrayList<String> set_beta = new ArrayList<String>();										
			set_beta.add(fi);									
			ArrayList<Transition> t_beta = coverage.getCoveredtransitions(set_beta);
			if(t_beta.contains(transition) && 
					(HashList.pair_hash_in(D4, upsilon, seq1)
					&& HashList.pair_hash_in(C4, fi, seq2))
					|| (HashList.pair_hash_in(C4, upsilon, seq1)
					&& HashList.pair_hash_in(D4, fi, seq2))
					){
				String[] a = new String[4];
				a[0] = upsilon;
				a[1] = upsilon;
				a[2] = fi;
				a[3] = gamma;
				System.out.println("upsilon3 "+ upsilon + " alpha " + upsilon + " beta " +fi + " gamma "+ gamma);
				return a;
			}
		}
		String[] a = new String[4];
		a[0] = upsilon;
		a[1] = upsilon;
		a[2] = fi;
		a[3] = "";*/
		return null;
	}
	
	private void add_extra(String chi, String fi, Transition transition, FsmCoverage coverage, 
			ArrayList<String> T, ArrayList<String> T4,
			Map<String, ArrayList<String>> C, Map<String, ArrayList<String>> C4,
			Map<String, ArrayList<String>> D, Map<String, ArrayList<String>> D4,
			ArrayList<String> K){
				
		
		System.out.println("Add fi step 5 ####### "+ fi);
								
		//int count =0;
		ArrayList<String[]> div_set = new ArrayList<String[]>();
								
		for (String upsilon : TestSet.minus(K, chi)) {							
			ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C4);
			ArrayList<String> Cfi = HashList.getPartition(fi, C4);
										
			System.out.println("NEW 2");
			//boolean found = false;
			
			String[] sep = find_sep(Cupsilon, Cfi, upsilon, fi, chi, transition, coverage, T4, D, D4, K, C,C4);
			if(sep!=null){
				div_set.add(sep);
			}
		}
		for(String upsilon : TestSet.minus(K, chi)) {
			for(String[] d : div_set){
				if(d[0].equals(upsilon)){
					String alpha = d[1];
					String beta = d[2];
					String gamma = d[3];
					
					String seq1 = TestSequence.concat(alpha, gamma);
					String seq2 = TestSequence.concat(beta, gamma);
					
					TestSet.addAllPrefsOf(T, seq1);
					TestSet.addAllPrefsOf(T, seq2);
					System.out.println(" add test seq " + seq1 + " + " +seq2);
					
					TestSet.addAllPrefsOf(Relative, seq1);
					TestSet.addAllPrefsOf(Relative, seq2);

					updateC2(T, C);	
					System.out.println("MODE 2");
				
					Pair p_alphabeta = new Pair(alpha, beta);									
					if(HashList.add_pair_hash(D, alpha, beta)){
						ruler.applyRules3(p_alphabeta, AddedTo.D); 
					}
				}
			}								 
		}
		
		
	}
	
	private String step05b_old6(ArrayList<String> K, ArrayList<String> CunionK,
			ArrayList<String> T, ArrayList<String> T4,
			Map<String, ArrayList<String>> C, Map<String, ArrayList<String>> C4,
			Map<String, ArrayList<String>> D, Map<String, ArrayList<String>> D4) {
		
		FsmCoverage coverage = new FsmCoverage(fsm);				
		// select the transition
		Transition transition = selectTransition(CunionK, coverage, T);
		State s = transition.getIn();
		
		for (String alpha1 : T4) {			
			if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha1) == s) {
				String alphax = TestSequence.concat(alpha1,
						transition.getInput());
				System.out.println("alpha1 " + alpha1);
				// sometimes T4 does not contain alphax but one in C4				
				if(T4.contains(alphax)){					
					System.out.println("point 1");		
					String fi = alphax;
					String chi = findChi(K, fi);
					if(!HashList.pair_hash_in(C, fi, chi)){	
						System.out.println("Add fi step 5 ******* "+ fi);
						//apenas um beta da partição de fi deve ser escolhido para distinguir os 3 upsilons
						
						ArrayList<String> Cfi = HashList.getPartition(fi, C4);
						for(String beta : Cfi){
							int ups = 0;
							ArrayList<String[]> div_set = new ArrayList<String[]>();
							for (String upsilon : TestSet.minus(K, chi)) {							
								ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C4);
								boolean found = false;
								for(String alpha : Cupsilon){
									State s1 = fsm.nextStateWithSequence(fsm.getInitialState(), upsilon);
									State s2 = fsm.nextStateWithSequence(fsm.getInitialState(), alpha);
									if(s1.equals(s2)){
										ArrayList<String> alpha_ext = getExtensionsFrom(T4, alpha);
										ArrayList<String> beta_ext = getExtensionsFrom(T4, beta);									
										for (String gamma : getCommonSufix(alpha, beta, alpha_ext,
												beta_ext)) {						
											State sa = fsm.nextStateWithSequence(fsm.getInitialState(), alpha);
											State sb = fsm.nextStateWithSequence(fsm.getInitialState(), beta);
											String seq1 = TestSequence.concat(alpha, gamma);
											String seq2 = TestSequence.concat(beta, gamma);
											
											ArrayList<String> set_beta = new ArrayList<String>();										
											set_beta.add(beta);									
											ArrayList<Transition> t_beta = coverage.getCoveredtransitions(set_beta);
																																					
											if (fsm.separe(gamma, sa, sb)
													&& HashList.pair_hash_in(D4, alpha, beta)													
													&& t_beta.contains(transition)
													&& T4.contains(seq1) && T4.contains(seq2)
													) {											
												
												String[] a = new String[4];
												a[0] = upsilon;
												a[1] = alpha;
												a[2] = beta;
												a[3] = gamma;
												div_set.add(a);																													
												System.out.println("upsilon "+ upsilon + " alpha " + alpha + " beta " +beta + " gamma "+ gamma);
												ups++;
												found = true;
												break;
											}
										}if(found)break;
									}		
								}								
							}
							int not_in_D = 0;
							for(String[] d : div_set){
								if(HashList.pair_hash_in(D, d[1], beta)){
									System.out.println("IN D " + beta);
									not_in_D++;
								}
							}
							if(ups >= TestSet.minus(K, chi).size() && not_in_D < TestSet.minus(K, chi).size()){
								//STEP 4
								TestSet.addAllPrefsOf(T, beta);
								TestSet.addAllPrefsOf(Relative, beta);
								updateC2(T, C);
								updateD2(D, T, beta);
								
								for(String upsilon : TestSet.minus(K, chi)) {
									for(String[] d : div_set){
										if(d[0].equals(upsilon)){
											String alpha = d[1];
											//String beta = d[2];
											String gamma = d[3];
											
											String seq1 = TestSequence.concat(alpha, gamma);
											String seq2 = TestSequence.concat(beta, gamma);
											
											TestSet.addAllPrefsOf(T, seq1);
											TestSet.addAllPrefsOf(T, seq2);
											System.out.println(" add test seq " + seq1 + " + " +seq2);
											
											TestSet.addAllPrefsOf(Relative, seq1);
											TestSet.addAllPrefsOf(Relative, seq2);
						
											updateC2(T, C);	
											System.out.println("MODE 1");
										
											Pair p_alphabeta = new Pair(alpha, beta);									
											if(HashList.add_pair_hash(D, alpha, beta)){
												ruler.applyRules3(p_alphabeta, AddedTo.D); 
											}
										}
									}								 
								}
								//STEP 3
								Pair p_fi_chi = new Pair(beta, chi);
								if(HashList.add_pair_hash(C, beta, chi)){
									ruler.applyRules3(p_fi_chi, AddedTo.C);
								}
								System.out.println("ADDED");
								return alphax;
							}
						}						
						
						/*
						int count =0;
						ArrayList<String[]> div_set = new ArrayList<String[]>();
						String last_beta = "";
												
						for (String upsilon : TestSet.minus(K, chi)) {							
							ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C4);
							ArrayList<String> Cfi = HashList.getPartition(fi, C4);
							//ArrayList<String> Cfi = new ArrayList<String>();
							//Cfi.add(fi);
														
							System.out.println("NEW");
							//boolean found = false;
														
							String[] sep = find_sep(Cupsilon, Cfi, upsilon, fi, chi, transition, coverage, T4, D, D4, K, C);
							if(sep!=null){
								div_set.add(sep);
								if(!last_beta.equals("") && !last_beta.equals(sep[2])){
									
								}
								last_beta = sep[2];
								count++;
							}else{
								System.out.println("TRY NEW");
								ArrayList<String> a1 = new ArrayList<String>();
								ArrayList<String> b1 = new ArrayList<String>();
								for(String alpha : Cupsilon){
									for(String beta : Cfi){
										ArrayList<String> alpha_ext = getExtensionsFrom(T4, alpha);
										ArrayList<String> beta_ext = getExtensionsFrom(T4, beta);
										for (String gamma : getCommonSufix(alpha, beta, alpha_ext,
												beta_ext)) {	
											
																					
											String aux_a = alpha.concat(","+gamma);
											String aux_b = beta.concat(","+gamma);
											if(alpha.equals("EPSILON")){
												aux_a = gamma;
											}
											if(beta.equals("EPSILON")){
												aux_b = gamma;
											}
											a1.add(aux_a);
											b1.add(aux_b);
										}
									}
								}								
								for(String a : a1){
									if(!Cupsilon.contains(a)){
										Cupsilon.add(a);										
									}
								}
								for(String b : b1){
									if(!Cfi.contains(b)){
										Cfi.add(b);										
									}
								}
								String[] sep1 = find_sep(Cupsilon, Cfi, upsilon, fi, chi, transition, coverage, T4, D, D4, K, C);
								if(sep1!=null){
									div_set.add(sep1);
									count++;
								}else{
									System.out.println("ERROR");
								}
							}
						}						
						System.out.println("TRY BETA");
						if(count >= TestSet.minus(K, chi).size()){
							//STEP 4
							TestSet.addAllPrefsOf(T, fi);
							TestSet.addAllPrefsOf(Relative, fi);
							updateC2(T, C);
							updateD2(D, T, fi);
							
							for(String upsilon : TestSet.minus(K, chi)) {
								for(String[] d : div_set){
									if(d[0].equals(upsilon)){
										String alpha = d[1];
										String beta = d[2];
										String gamma = d[3];
										
										String seq1 = TestSequence.concat(alpha, gamma);
										String seq2 = TestSequence.concat(beta, gamma);
										
										TestSet.addAllPrefsOf(T, seq1);
										TestSet.addAllPrefsOf(T, seq2);
										System.out.println(" add test seq " + seq1 + " + " +seq2);
										
										TestSet.addAllPrefsOf(Relative, seq1);
										TestSet.addAllPrefsOf(Relative, seq2);
					
										updateC2(T, C);	
										System.out.println("MODE 1");
									
										Pair p_alphabeta = new Pair(alpha, beta);									
										if(HashList.add_pair_hash(D, alpha, beta)){
											ruler.applyRules3(p_alphabeta, AddedTo.D); 
										}
									}
								}								 
							}
							//STEP 3
							Pair p_fi_chi = new Pair(fi, chi);
							if(HashList.add_pair_hash(C, fi, chi)){
								ruler.applyRules3(p_fi_chi, AddedTo.C);
							}
							System.out.println("ADDED");
							return alphax;
						}*/
						
						
						
					}
					//return alphax;
				}
			}
		}		
		return null;
	}
	private ArrayList<String[]> get_div_set(Transition transition,ArrayList<String> K,
			ArrayList<String> T4, FsmCoverage coverage, String fi, String chi,
			Map<String, ArrayList<String>> C, Map<String, ArrayList<String>> C4,
			Map<String, ArrayList<String>> D, Map<String, ArrayList<String>> D4){
		
		ArrayList<String[]> div_set = new ArrayList<String[]>();
		System.out.println("FIND DIV 0");
		ArrayList<String> Cfi = HashList.getPartition(fi, C4);
		for (String upsilon : TestSet.minus(K, chi)) {		
			ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C4);
			String[] sep = find_sep(Cupsilon, Cfi, upsilon, fi, chi, transition, coverage, T4, D, D4, K, C,C4);
			if(sep!=null){
				div_set.add(sep);
			}
		}
		if(div_set.size() >= TestSet.minus(K, chi).size()){
			return div_set;
		}
		System.out.println("TRY FIND OTHER DIV SET");
		div_set.clear();
		for (String upsilon : TestSet.minus(K, chi)) {		
			ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C4);
			String[] sep = find_sep3(Cupsilon, Cfi, upsilon, fi, chi, transition, coverage, T4, D, D4, K, C,C4);
			if(sep!=null){
				div_set.add(sep);
			}
		}
		if(div_set.size() >= TestSet.minus(K, chi).size()){
			return div_set;
		}
		return null;
	}
	
	private ArrayList<String[]> get_div_set_old2(Transition transition,ArrayList<String> K,
			ArrayList<String> T4, FsmCoverage coverage, String fi, String chi,
			Map<String, ArrayList<String>> C, Map<String, ArrayList<String>> C4,
			Map<String, ArrayList<String>> D, Map<String, ArrayList<String>> D4){
		
		ArrayList<String[]> div_set = new ArrayList<String[]>();
		
		ArrayList<String> Cfi = HashList.getPartition(fi, C4);
		System.out.println("FIND DIV ");
		for(String beta : Cfi){
			if(!HashList.pair_hash_in(C, beta, chi)){	
				div_set.clear();
				for (String upsilon : TestSet.minus(K, chi)) {							
					ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C4);
					ArrayList<String> Cfi2 = new ArrayList<String>();
					Cfi2.add(beta);
					String[] sep = find_sep(Cupsilon, Cfi2, upsilon, fi, chi, transition, coverage, T4, D, D4, K, C,C4);
					if(sep!=null){
						div_set.add(sep);
					}else{
						//System.out.println("ERROR GET_DIV_SET");
					}
				}
				if(div_set.size() >= TestSet.minus(K, chi).size()){
					return div_set;
				}				
			}
		}
		System.out.println("FIND DIV 2");
		for(String beta : Cfi){			
			div_set.clear();
			for (String upsilon : TestSet.minus(K, chi)) {							
				ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C4);
				ArrayList<String> Cfi2 = new ArrayList<String>();
				Cfi2.add(beta);
				String[] sep = find_sep(Cupsilon, Cfi2, upsilon, fi, chi, transition, coverage, T4, D, D4, K, C,C4);
				if(sep!=null){
					div_set.add(sep);
				}else{
					//System.out.println("ERROR GET_DIV_SET");
				}
			}
			if(div_set.size() >= TestSet.minus(K, chi).size()){
				return div_set;
			}
		}
			/*System.out.println("NEW");																					
			String[] sep = find_sep(Cupsilon, Cfi, upsilon, fi, chi, transition, coverage, T4, D, D4, K, C,C4);
			if(sep!=null){
				div_set.add(sep);
			}else{
				System.out.println("ERROR GET_DIV_SET");
				//ADD NEW RULE
				/*ArrayList<String> fi_ext = getExtensionsFrom(T4, fi);
				for(String ext : fi_ext){
					if(HashList.pair_hash_in(C4, fi, ext)){
						State sa = fsm.nextStateWithSequence(
								fsm.getInitialState(), upsilon);
						State sb = fsm.nextStateWithSequence(
								fsm.getInitialState(), fi);
						String gamma = TestSequence.getSuffixFrom(ext,fi);
						if(fsm.separe(gamma, sa, sb)
								&& HashList.pair_hash_in(D4, upsilon, fi)								
								){
							String[] a = new String[4];
							a[0] = upsilon;
							a[1] = upsilon;
							a[2] = fi+","+gamma;
							a[3] = "";
							div_set.add(a);
							System.out.println("upsilon011 "+ upsilon + " alpha " + upsilon + " beta " +fi + " gamma "+ gamma);
							
						}
					}
				}*/
				/*if(fi.equals("3,4")){
					String[] a = new String[4];
					a[0] = upsilon;
					a[1] = "EPSILON";
					a[2] = "3,4,0";
					a[3] = "4";
					div_set.add(a);
				}
			}*/
		//}
		return null;
	}
	
	private void set_div_set(ArrayList<String> K,
			ArrayList<String> T, String chi, ArrayList<String[]> div_set,
			Map<String, ArrayList<String>> C,
			Map<String, ArrayList<String>> D){
				
		for(String upsilon : TestSet.minus(K, chi)) {
			for(String[] d : div_set){
				if(d[0].equals(upsilon)){
					String alpha = d[1];
					String beta = d[2];
					String gamma = d[3];
					
					String seq1 = TestSequence.concat(alpha, gamma);
					String seq2 = TestSequence.concat(beta, gamma);
					
					TestSet.addAllPrefsOf(T, seq1);
					TestSet.addAllPrefsOf(T, seq2);
					System.out.println(" add test seq " + seq1 + " + " +seq2);
					
					TestSet.addAllPrefsOf(Relative, seq1);
					TestSet.addAllPrefsOf(Relative, seq2);

					updateC2(T, C);					
					updateD2(D, T, seq1);
					updateD2(D, T, seq2);
					System.out.println("MODE 1");
				
					Pair p_alphabeta = new Pair(alpha, beta);									
					if(HashList.add_pair_hash(D, alpha, beta)){
						ruler.applyRules3(p_alphabeta, AddedTo.D); 
					}
				}
			}								 
		}
	}
	
	private String step05b(Transition transition, ArrayList<String> K, ArrayList<String> CunionK,
			ArrayList<String> T, ArrayList<String> T4,
			Map<String, ArrayList<String>> C, Map<String, ArrayList<String>> C4,
			Map<String, ArrayList<String>> D, Map<String, ArrayList<String>> D4) {
		
		FsmCoverage coverage = new FsmCoverage(fsm);
		State s = transition.getIn();
		System.out.println("Transition "+ transition);
		for (String alpha1 : T4) {			
			if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha1) == s) {
				String alphax = TestSequence.concat(alpha1,
						transition.getInput());
				System.out.println("alpha1 " + alpha1);								
				if(T4.contains(alphax)){
					ArrayList<String> alphax_ext = new ArrayList<String>();
					alphax_ext.add(alphax);
					alphax_ext.addAll(getExtensionsFrom(T4, alphax));
					for(String fi: alphax_ext){						
						System.out.println("point 1");							
						String chi = findChi(K, fi);						
						//print_set(CunionK,"CunionK");
						if(!HashList.pair_hash_in(C, fi, chi)){							
							System.out.println("Add fi step 5 ******* "+ fi);																				
							//STEP 5b
							ArrayList<String[]> div_set = get_div_set(transition, K, T4, coverage, fi, chi, C, C4, D, D4);
							//int count = div_set.size();
							System.out.println("TRY FOUND");
							//if(count >= TestSet.minus(K, chi).size()){	
							if(div_set != null){
								//String old_fi = fi;
								//fi = div_set.get(0)[2];
								TestSet.addAllPrefsOf(T, fi);
								TestSet.addAllPrefsOf(Relative, fi);
								
								//STEP 4b
								set_div_set(K, T, chi, div_set, C, D);
								updateC2(T, C);
								updateD2(D, T, fi);
								//updateD2(D, T, fi);
								//STEP 3
								//Pair p_fi_chi = new Pair(fi, chi);
								//if(HashList.add_pair_hash(C, fi, chi)){
								//	ruler.applyRules3(p_fi_chi, AddedTo.C);
								//}
								System.out.println("ADDED");
								//add recursividade prefixos de fi
							/*	ArrayList<String> fi_pre = TestSequence.getAllPrefixesFrom(fi);
								ArrayList<Pair> lp = new ArrayList<Pair>(); 
								
									for(String pre : fi_pre){
										if(!CunionK.contains(pre)){
											String p_fi = pre;
											String p_chi = findChi(K, p_fi);
											boolean in = true;				
											for (String upsilon : TestSet.minus(K, p_chi)) {					
												if (!HashList.pair_hash_in(D4,p_fi, upsilon)){
													in = false;
													break;
												}					
											}
											if (in && isConvergent(p_fi, p_chi)){
												//lp.add(new Pair(fi, chi));
											}						
										}
									}
								
								//if(){
									
								//}
								Pair pre_fi_chi = findFiChi4(CunionK, K, D);
								while(pre_fi_chi != null){
									fi = pre_fi_chi.getLeft();
									chi = pre_fi_chi.getRight();
									//STEP 5b
									ArrayList<Transition> current = fsm.reachedTransitionsWithSequence(fsm.getInitialState(), fi);
									Transition t = current.get(current.size() - 1);
									div_set = get_div_set(t, K, T4, coverage, fi, chi, C, C4, D, D4);
									count = div_set.size();													
									//STEP 4b					
									System.out.println("TRY FOUND PREFIX");
									if(count >= TestSet.minus(K, chi).size()){								
										TestSet.addAllPrefsOf(T, fi);
										TestSet.addAllPrefsOf(Relative, fi);
										updateC2(T, C);
										updateD2(D, T, fi);
										
										set_div_set(K, T, chi, div_set, C, D);
										//STEP 3
										p_fi_chi = new Pair(fi, chi);
										if(HashList.add_pair_hash(C, fi, chi)){
											ruler.applyRules3(p_fi_chi, AddedTo.C);
										}
										System.out.println("ADDED PREFIX");
									}
									CunionK = findCunionK2(C, K);
									pre_fi_chi = findFiChi4(CunionK, K, D);
								}
								//ArrayList<String> pre_fi = TestSequence.getAllPrefixesFrom(fi);
								//for(String pre : pre_fi){
								String pre = TestSequence.getPrefixFrom(fi, transition.getInput());
									if(!CunionK.contains(pre)){
										fi = pre;
										chi = findChi(K, fi);
										//STEP 5b
										ArrayList<Transition> current = fsm.reachedTransitionsWithSequence(fsm.getInitialState(), fi);
										Transition t = current.get(current.size() - 1);
										div_set = get_div_set(t, K, T4, coverage, fi, chi, C, C4, D, D4);
										//count = div_set.size();													
										//STEP 4b					
										System.out.println("TRY FOUND PREFIX");
										if(div_set != null){								
											TestSet.addAllPrefsOf(T, fi);
											TestSet.addAllPrefsOf(Relative, fi);
											updateC2(T, C);
											updateD2(D, T, fi);
											
											set_div_set(K, T, chi, div_set, C, D);
											//STEP 3
											p_fi_chi = new Pair(fi, chi);
											if(HashList.add_pair_hash(C, fi, chi)){
												ruler.applyRules3(p_fi_chi, AddedTo.C);
											}
											System.out.println("ADDED PREFIX");
										}
									}*/
								//}
								return fi;
							}
						}
						//return alphax;
					}
				}
			}
		}		
		return null;
	}
	
	private String step05b_olld6(Transition transition, ArrayList<String> K, ArrayList<String> CunionK,
			ArrayList<String> T, ArrayList<String> T4,
			Map<String, ArrayList<String>> C, Map<String, ArrayList<String>> C4,
			Map<String, ArrayList<String>> D, Map<String, ArrayList<String>> D4) {
		
		FsmCoverage coverage = new FsmCoverage(fsm);
		State s = transition.getIn();
		System.out.println("Transition "+ transition);
		for (String alpha1 : T4) {			
			if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha1) == s) {
				String alphax = TestSequence.concat(alpha1,
						transition.getInput());
				System.out.println("alpha1 " + alpha1);
								
				if(T4.contains(alphax)){
					ArrayList<String> alphax_ext = new ArrayList<String>();
					alphax_ext.add(alphax);
					alphax_ext.addAll(getExtensionsFrom(T4, alphax));
					for(String fi: alphax_ext){
						
					System.out.println("point 1");		
					//String fi = alphax;
					String chi = findChi(K, fi);
					//print_map(C,"C");
					//System.out.println("K "+ K);
					//System.out.println("CunionK "+ CunionK);
					print_set(CunionK,"CunionK");
					if(!HashList.pair_hash_in(C, fi, chi)){	
					//if(!HashList.pair_hash_in(C, alphax, findChi(K, alphax))){
					//if(!HashList.pair_hash_in(C, alpha1, findChi(K, alpha1))){	
						System.out.println("Add fi step 5 ******* "+ fi);
						//print_map(C4,"C4");
						//print_map(D4,"D4");
						//print_set(CunionK,"CunionK");
												
						int count =0;
						ArrayList<String[]> div_set = new ArrayList<String[]>();
						String last_beta = "";
												
						for (String upsilon : TestSet.minus(K, chi)) {							
							ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C4);
							ArrayList<String> Cfi = HashList.getPartition(fi, C4);
							//ArrayList<String> Cfi = new ArrayList<String>();
							//Cfi.add(fi);
														
							System.out.println("NEW");
							//boolean found = false;
														
							String[] sep = find_sep(Cupsilon, Cfi, upsilon, fi, chi, transition, coverage, T4, D, D4, K, C,C4);
							if(sep!=null){
								div_set.add(sep);
								if(!last_beta.equals("") && !last_beta.equals(sep[2])){
									
								}
								last_beta = sep[2];
								count++;
							}else{
								System.out.println("TRY NEW");
								/*ArrayList<String> a1 = new ArrayList<String>();
								ArrayList<String> b1 = new ArrayList<String>();
								for(String alpha : Cupsilon){
									for(String beta : Cfi){
										ArrayList<String> alpha_ext = getExtensionsFrom(T4, alpha);
										ArrayList<String> beta_ext = getExtensionsFrom(T4, beta);
										for (String gamma : getCommonSufix(alpha, beta, alpha_ext,
												beta_ext)) {	
											
																					
											String aux_a = alpha.concat(","+gamma);
											String aux_b = beta.concat(","+gamma);
											if(alpha.equals("EPSILON")){
												aux_a = gamma;
											}
											if(beta.equals("EPSILON")){
												aux_b = gamma;
											}
											a1.add(aux_a);
											b1.add(aux_b);
										}
									}
								}
								//ArrayList<String> Cupsilon2 = new ArrayList<String>();
								//ArrayList<String> Cfi2 = new ArrayList<String>();
								for(String a : a1){
									if(!Cupsilon.contains(a)){
										Cupsilon.add(a);
										//System.out.println(" more Cupsilon " + a);
									}
								}
								for(String b : b1){
									if(!Cfi.contains(b)){
										Cfi.add(b);
										//System.out.println(" more Cfi " + b);
									}
								}*/
								String[] sep1 = find_sep(Cupsilon, Cfi, upsilon, fi, chi, transition, coverage, T4, D, D4, K, C,C4);
								if(sep1!=null){
									div_set.add(sep1);
									count++;
								}else{
									System.out.println("ERROR");
									//return null;
								}
							}
						}						
						System.out.println("TRY BETA");
						if(count >= TestSet.minus(K, chi).size()){
							//STEP 4
							TestSet.addAllPrefsOf(T, fi);
							TestSet.addAllPrefsOf(Relative, fi);
							updateC2(T, C);
							updateD2(D, T, fi);
							
							for(String upsilon : TestSet.minus(K, chi)) {
								for(String[] d : div_set){
									if(d[0].equals(upsilon)){
										String alpha = d[1];
										String beta = d[2];
										String gamma = d[3];
										
										String seq1 = TestSequence.concat(alpha, gamma);
										String seq2 = TestSequence.concat(beta, gamma);
										
										TestSet.addAllPrefsOf(T, seq1);
										TestSet.addAllPrefsOf(T, seq2);
										System.out.println(" add test seq " + seq1 + " + " +seq2);
										
										TestSet.addAllPrefsOf(Relative, seq1);
										TestSet.addAllPrefsOf(Relative, seq2);
					
										updateC2(T, C);	
										System.out.println("MODE 1");
									
										Pair p_alphabeta = new Pair(alpha, beta);									
										if(HashList.add_pair_hash(D, alpha, beta)){
											ruler.applyRules3(p_alphabeta, AddedTo.D); 
										}
									}
								}								 
							}
							//STEP 3
							Pair p_fi_chi = new Pair(fi, chi);
							if(HashList.add_pair_hash(C, fi, chi)){
								ruler.applyRules3(p_fi_chi, AddedTo.C);
							}
							System.out.println("ADDED");
							return alphax;
						}
					}
					//return alphax;
				}
				}
			}
		}		
		return null;
	}
		
	private String step05b_old5(ArrayList<String> K, ArrayList<String> CunionK,
			ArrayList<String> T, ArrayList<String> T4,
			Map<String, ArrayList<String>> C, Map<String, ArrayList<String>> C4,
			Map<String, ArrayList<String>> D, Map<String, ArrayList<String>> D4) {
		
		FsmCoverage coverage = new FsmCoverage(fsm);
				
		// select the transition
		Transition transition = selectTransition(CunionK, coverage, T);
		State s = transition.getIn();
		//System.out.println("CunionK ");
		//for (String alpha1 : CunionK) {			
		//	if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha1) == s) {
		//		System.out.println(alpha1);
		//	}
			
		//}
		//System.out.println("T4 " + T4);
		for (String alpha1 : T4) {			
			if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha1) == s) {
				String alphax = TestSequence.concat(alpha1,
						transition.getInput());
				System.out.println("alpha1 " + alpha1);
				// sometimes T4 does not contain alphax but one in C4				
				if(T4.contains(alphax)){					
					System.out.println("point 1");		
					String fi = alphax;
					String chi = findChi(K, fi);
					if(!HashList.pair_hash_in(C, fi, chi)){	
						System.out.println("Add fi step 5 ******* "+ fi);
												
						int count =0;
						ArrayList<String[]> div_set = new ArrayList<String[]>();
												
						for (String upsilon : TestSet.minus(K, chi)) {							
							ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C4);
							ArrayList<String> Cfi = HashList.getPartition(fi, C4);
														
							System.out.println("NEW");
							//boolean found = false;
							
							String[] sep = null;//find_sep(Cupsilon, Cfi, upsilon, fi, transition, coverage, T4, D, D4, K);
							if(sep!=null){
								div_set.add(sep);
								count++;
							}else{
								System.out.println("TRY NEW");
								ArrayList<String> a1 = new ArrayList<String>();
								ArrayList<String> b1 = new ArrayList<String>();
								for(String alpha : Cupsilon){
									for(String beta : Cfi){
										ArrayList<String> alpha_ext = getExtensionsFrom(T4, alpha);
										ArrayList<String> beta_ext = getExtensionsFrom(T4, beta);
										for (String gamma : getCommonSufix(alpha, beta, alpha_ext,
												beta_ext)) {	
											
										/*	State sa = fsm.nextStateWithSequence(
													fsm.getInitialState(), alpha);
											State sb = fsm.nextStateWithSequence(
													fsm.getInitialState(), beta);
											String seq1 = TestSequence.concat(alpha, gamma);
											String seq2 = TestSequence.concat(beta, gamma);
											
											ArrayList<String> set_beta = new ArrayList<String>();										
											set_beta.add(beta);									
											ArrayList<Transition> t_beta = coverage.getCoveredtransitions(set_beta);
																															
											if (fsm.separe(gamma, sa, sb)
													&& HashList.pair_hash_in(D4, alpha, beta)
													&& t_beta.contains(transition)
													&& T4.contains(seq1) && T4.contains(seq2)
													) {			
												
											}*/
											
											String aux_a = alpha.concat(","+gamma);
											String aux_b = beta.concat(","+gamma);
											if(alpha.equals("EPSILON")){
												aux_a = gamma;
											}
											if(beta.equals("EPSILON")){
												aux_b = gamma;
											}
											a1.add(aux_a);
											b1.add(aux_b);
										}
									}
								}
								//ArrayList<String> Cupsilon2 = new ArrayList<String>();
								//ArrayList<String> Cfi2 = new ArrayList<String>();
								for(String a : a1){
									if(!Cupsilon.contains(a)){
										Cupsilon.add(a);
										//System.out.println(" more Cupsilon " + a);
									}
								}
								for(String b : b1){
									if(!Cfi.contains(b)){
										Cfi.add(b);
										//System.out.println(" more Cfi " + b);
									}
								}
								String[] sep1 = null;//find_sep(Cupsilon, Cfi, upsilon, fi, transition, coverage, T4, D, D4, K);
								if(sep1!=null){
									div_set.add(sep1);
									count++;
								}else{
									System.out.println("ERROR");
								}
							}
						}						
						System.out.println("TRY BETA");
						if(count >= TestSet.minus(K, chi).size()){
							//STEP 4
							TestSet.addAllPrefsOf(T, fi);
							TestSet.addAllPrefsOf(Relative, fi);
							updateC2(T, C);
							updateD2(D, T, fi);
							
							for(String upsilon : TestSet.minus(K, chi)) {
								for(String[] d : div_set){
									if(d[0].equals(upsilon)){
										String alpha = d[1];
										String beta = d[2];
										String gamma = d[3];
										
										String seq1 = TestSequence.concat(alpha, gamma);
										String seq2 = TestSequence.concat(beta, gamma);
										
										TestSet.addAllPrefsOf(T, seq1);
										TestSet.addAllPrefsOf(T, seq2);
										System.out.println(" add test seq " + seq1 + " + " +seq2);
										
										TestSet.addAllPrefsOf(Relative, seq1);
										TestSet.addAllPrefsOf(Relative, seq2);
					
										updateC2(T, C);	
										System.out.println("MODE 1");
									
										Pair p_alphabeta = new Pair(alpha, beta);									
										if(HashList.add_pair_hash(D, alpha, beta)){
											ruler.applyRules3(p_alphabeta, AddedTo.D); 
										}
									}
								}								 
							}
							//STEP 3
							Pair p_fi_chi = new Pair(fi, chi);
							if(HashList.add_pair_hash(C, fi, chi)){
								ruler.applyRules3(p_fi_chi, AddedTo.C);
							}
							System.out.println("ADDED");
							return alphax;
						}
					}
					//return alphax;
				}
			}
		}		
		return null;
	}
	
	private String step05b_old4(ArrayList<String> K, ArrayList<String> CunionK,
			ArrayList<String> T, ArrayList<String> T4,
			Map<String, ArrayList<String>> C, Map<String, ArrayList<String>> C4,
			Map<String, ArrayList<String>> D, Map<String, ArrayList<String>> D4) {
		
		FsmCoverage coverage = new FsmCoverage(fsm);
				
		// select the transition
		Transition transition = selectTransition(CunionK, coverage, T);
		State s = transition.getIn();
		System.out.println("CunionK ");
		for (String alpha1 : CunionK) {			
			if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha1) == s) {
				System.out.println(alpha1);
			}
			
		}
		//System.out.println("T4 " + T4);
		for (String alpha1 : CunionK) {			
			if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha1) == s) {
				String alphax = TestSequence.concat(alpha1,
						transition.getInput());
				System.out.println("alpha1 " + alpha1);
				// sometimes T4 does not contain alphax but one in C4				
				if(T4.contains(alphax)){					
					System.out.println("point 1");		
					String fi = alphax;
					String chi = findChi(K, fi);
					if(!HashList.pair_hash_in(C, fi, chi)){	
						System.out.println("Add fi step 5 *******");
						ArrayList<String> fi_ext = getExtensionsFrom(T4, fi);
						for(String fi_e : fi_ext){
							
						}
						
						int count =0;
						ArrayList<String[]> div_set = new ArrayList<String[]>();
												
						for (String upsilon : TestSet.minus(K, chi)) {							
							ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C4);
							ArrayList<String> Cfi = HashList.getPartition(fi, C4);
								
							
							ArrayList<String> a1 = new ArrayList<String>();
							ArrayList<String> b1 = new ArrayList<String>();
							for(String alpha : Cupsilon){
								for(String beta : Cfi){
									ArrayList<String> alpha_ext = getExtensionsFrom(T4, alpha);
									ArrayList<String> beta_ext = getExtensionsFrom(T4, beta);
									for (String gamma : getCommonSufix(alpha, beta, alpha_ext,
											beta_ext)) {										
										String aux_a = alpha.concat(","+gamma);
										String aux_b = beta.concat(","+gamma);
										if(alpha.equals("EPSILON")){
											aux_a = gamma;
										}
										if(beta.equals("EPSILON")){
											aux_b = gamma;
										}
										a1.add(aux_a);
										b1.add(aux_b);
									}
								}
							}
							for(String a : a1){
								if(!Cupsilon.contains(a)){
									Cupsilon.add(a);
									System.out.println(" more Cupsilon " + a);
								}
							}
							for(String b : b1){
								if(!Cfi.contains(b)){
									Cfi.add(b);
									System.out.println(" more Cfi " + b);
								}
							}
							
							//System.out.println("Cupsilon " + Cupsilon);
							//System.out.println("Cfi " + Cfi);
							System.out.println("NEW");
							boolean found = false;
									
							for(String alpha : Cupsilon){
								for(String beta : Cfi){
									ArrayList<String> alpha_ext = getExtensionsFrom(T4, alpha);
									ArrayList<String> beta_ext = getExtensionsFrom(T4, beta);									
									for (String gamma : getCommonSufix(alpha, beta, alpha_ext,
											beta_ext)) {						
										State sa = fsm.nextStateWithSequence(
												fsm.getInitialState(), alpha);
										State sb = fsm.nextStateWithSequence(
												fsm.getInitialState(), beta);
										String seq1 = TestSequence.concat(alpha, gamma);
										String seq2 = TestSequence.concat(beta, gamma);
										//String[] y = beta.split(",");
										ArrayList<String> set_beta = new ArrayList<String>();
										//ArrayList<String> set_alphax = new ArrayList<String>();
										set_beta.add(beta);
										//set_alphax.add(alphax);
										ArrayList<Transition> t_beta = coverage.getCoveredtransitions(set_beta);
										//ArrayList<Transition> t_alphax = coverage.getCoveredtransitions(set_alphax);
										if(t_beta.contains(transition) && HashList.pair_hash_in(D4, alpha, beta)){
											System.out.println(" check " + transition + " alpha " + alpha + " beta " +beta + " + " +t_beta + " + " + gamma);
										}
										//SM,F,SM, SM,CM alpha
										//SM,DM,F, SM,CM beta
										if (fsm.separe(gamma, sa, sb) 
												//&& !CunionK.contains(beta)
												//&& !HashList.pair_hash_in(C, beta, chi)
												//&& y[y.length-1].equals(transition.getInput())
												//&& t_beta.containsAll(t_alphax)
												//HashList.pair_hash_in(D4, alpha, beta)
												//&& !HashList.pair_hash_in(D, alpha, beta)
												&& t_beta.contains(transition)
												&& T4.contains(seq1) && T4.contains(seq2)
												) {											
											
										/*	//if(!HashList.pair_hash_in(D, alpha, beta)){												
												TestSet.addAllPrefsOf(T, seq1);
												TestSet.addAllPrefsOf(T, seq2);
												System.out.println(" add test seq " + seq1 + " + " +seq2);
												
												TestSet.addAllPrefsOf(Relative, seq1);
												TestSet.addAllPrefsOf(Relative, seq2);
							
												updateC2(T, C);	
												System.out.println("MODE 1");
											
												Pair p_alphabeta = new Pair(alpha, beta);									
												if(HashList.add_pair_hash(D, alpha, beta)){
													ruler.applyRules3(p_alphabeta, AddedTo.D); 
												}
											//}*/
											
											String[] a = new String[4];
											a[0] = upsilon;
											a[1] = alpha;
											a[2] = beta;
											a[3] = gamma;
											div_set.add(a);
											
											System.out.println("upsilon "+ upsilon + " alpha " + alpha + " beta " +beta + " gamma "+ gamma);
											found = true;
											count++;
											break;
										}
									}if(found) break;
								}if(found) break;
							}							
						}						
						System.out.println("TRY BETA");
						//if(count >= TestSet.minus(K, chi).size()){
							//STEP 4
							TestSet.addAllPrefsOf(T, fi);
							TestSet.addAllPrefsOf(Relative, fi);
							updateC2(T, C);
							updateD2(D, T, fi);
							
							for(String upsilon : TestSet.minus(K, chi)) {
								for(String[] d : div_set){
									if(d[0].equals(upsilon)){
										String alpha = d[1];
										String beta = d[2];
										String gamma = d[3];
										
										String seq1 = TestSequence.concat(alpha, gamma);
										String seq2 = TestSequence.concat(beta, gamma);
										
										TestSet.addAllPrefsOf(T, seq1);
										TestSet.addAllPrefsOf(T, seq2);
										System.out.println(" add test seq " + seq1 + " + " +seq2);
										
										TestSet.addAllPrefsOf(Relative, seq1);
										TestSet.addAllPrefsOf(Relative, seq2);
					
										updateC2(T, C);	
										System.out.println("MODE 1");
									
										Pair p_alphabeta = new Pair(alpha, beta);									
										if(HashList.add_pair_hash(D, alpha, beta)){
											ruler.applyRules3(p_alphabeta, AddedTo.D); 
										}
									}
								}								 
							}
							//STEP 3
							Pair p_fi_chi = new Pair(fi, chi);
							if(HashList.add_pair_hash(C, fi, chi)){
								ruler.applyRules3(p_fi_chi, AddedTo.C);
							}
							System.out.println("ADDED");
							return alphax;
						//}
					}
					//return alphax;
				}
			}
		}		
		return null;
	}
	
	private String step05b_old3(ArrayList<String> K, ArrayList<String> CunionK,
			ArrayList<String> T, ArrayList<String> T4,
			Map<String, ArrayList<String>> C, Map<String, ArrayList<String>> C4,
			Map<String, ArrayList<String>> D, Map<String, ArrayList<String>> D4) {
		
		FsmCoverage coverage = new FsmCoverage(fsm);
				
		// select the transition
		Transition transition = selectTransition(CunionK, coverage, T);
		State s = transition.getIn();
		System.out.println("T4 " + T4);
		for (String alpha1 : T4) {			
			if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha1) == s) {
				String alphax = TestSequence.concat(alpha1,
						transition.getInput());
				System.out.println("alpha1 " + alpha1);
				// sometimes T4 does not contain alphax but one in C4				
				if(!CunionK.contains(alphax) && T4.contains(alphax)){					
					System.out.println("point 1");		
					String fi = alphax;
					String chi = findChi(K, fi);
					if(!HashList.pair_hash_in(C, fi, chi)){	
						System.out.println("Add fi step 5 *******");
						
						ArrayList<String[]> div_set = new ArrayList<String[]>();										
						for (String upsilon : TestSet.minus(K, chi)) {							
							ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C4);
							ArrayList<String> Cfi = HashList.getPartition(fi, C4); 
							
							System.out.println("Cupsilon " + Cupsilon);
							System.out.println("Cfi " + Cfi);
									
							for(String alpha : Cupsilon){
								for(String beta : Cfi){
									ArrayList<String> alpha_ext = getExtensionsFrom(T4, alpha);
									ArrayList<String> beta_ext = getExtensionsFrom(T4, beta);									
									for (String gamma : getCommonSufix(alpha, beta, alpha_ext,
											beta_ext)) {						
										State sa = fsm.nextStateWithSequence(
												fsm.getInitialState(), alpha);
										State sb = fsm.nextStateWithSequence(
												fsm.getInitialState(), beta);
										String seq1 = TestSequence.concat(alpha, gamma);
										String seq2 = TestSequence.concat(beta, gamma);
										String[] y = beta.split(",");										
										if (fsm.separe(gamma, sa, sb) && !CunionK.contains(beta)
												&& !HashList.pair_hash_in(C, beta, chi)
												&& y[y.length-1].equals(transition.getInput())
												&& T4.contains(seq1) && T4.contains(seq2)) {											
											String[] a = new String[4];
											a[0] = upsilon;
											a[1] = alpha;
											a[2] = beta;
											a[3] = gamma;
											div_set.add(a);
											System.out.println("upsilon "+ upsilon + " alpha " + alpha + " beta " +beta + " gamma "+ gamma);
										}
									}
								}
							}							
						}
						System.out.println("TRY BETA");
						//System.out.println(div_set);
						//for(String[] a : div_set){							
							int count = 0;							
							Map<String, String[]> index = new HashMap<String, String[]>();
							for (String upsilon : TestSet.minus(K, chi)) {								
								for(String[] d : div_set){									
									if(d[0].equals(upsilon)){
										String seq1 = TestSequence.concat(d[1], d[3]);
										String seq2 = TestSequence.concat(d[2], d[3]);
										if(T4.contains(seq1) && T4.contains(seq2)){
										//if (d[2].equals(a[2]) && !CunionK.contains(a[2])){
											count++;
											index.put(upsilon,d);
											break;
										}
									}
								}							
							}
							if(count >= TestSet.minus(K, chi).size()){
								System.out.println("FOUND BETA");
								TestSet.addAllPrefsOf(T, fi);
								TestSet.addAllPrefsOf(Relative, fi);
								updateC2(T, C);
								updateD2(D, T, fi);
																
								for(String upsilon : TestSet.minus(K, chi)){
									String alpha = index.get(upsilon)[1];
									String beta = index.get(upsilon)[2];									
									String gamma = index.get(upsilon)[3];
																		
									//if(!HashList.pair_hash_in(D, alpha, beta)){
										String seq1 = TestSequence.concat(alpha, gamma);
										String seq2 = TestSequence.concat(beta, gamma);
										TestSet.addAllPrefsOf(T, seq1);
										TestSet.addAllPrefsOf(T, seq2);
										System.out.println(" add test seq " + seq1 + " + " +seq2);
										
										TestSet.addAllPrefsOf(Relative, seq1);
										TestSet.addAllPrefsOf(Relative, seq2);
					
										updateC2(T, C);	
										System.out.println("MODE 1");
									
										Pair p_alphabeta = new Pair(alpha, beta);									
										if(HashList.add_pair_hash(D, alpha, beta)){
											ruler.applyRules3(p_alphabeta, AddedTo.D); 
										}
									//}
								}
								//STEP 3
								//step04d(beta, chi, K, D, C, T);
								Pair p_fi_chi = new Pair(fi, chi);
								if(HashList.add_pair_hash(C, fi, chi)){
									ruler.applyRules3(p_fi_chi, AddedTo.C);
								}
								System.out.println("ADDED");
								return alphax;
							}
						//}
					}
				}
			}
		}		
		return null;
	}
	
	private String step05b_old2(ArrayList<String> K, ArrayList<String> CunionK,
			ArrayList<String> T, ArrayList<String> T4,
			Map<String, ArrayList<String>> C, Map<String, ArrayList<String>> C4,
			Map<String, ArrayList<String>> D, Map<String, ArrayList<String>> D4) {
		
		FsmCoverage coverage = new FsmCoverage(fsm);
				
		// select the transition
		Transition transition = selectTransition(CunionK, coverage, T);
		State s = transition.getIn();		
		for (String alpha1 : CunionK) {			
			if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha1) == s) {
				String alphax = TestSequence.concat(alpha1,
						transition.getInput());
				System.out.println("point 0");
				if(CunionK.contains(alphax)){
					System.out.println("point 01");	
				}
				if(!T4.contains(alphax)){
					System.out.println("point 02");	
				}
				if(!has_common_gamma(alphax,K,D4,C4,T4)){
					System.out.println("point 03");	
				}
				if(!CunionK.contains(alphax)){					
					System.out.println("point 1");		
					String fi = alphax;
					String chi = findChi(K, fi);
					if(!HashList.pair_hash_in(C, fi, chi)){	
						System.out.println("Add fi step 5");
						TestSet.addAllPrefsOf(T, alphax);
						TestSet.addAllPrefsOf(Relative, alphax);
						updateC2(T, C);
						updateD2(D, T, alphax);
						for (String upsilon : TestSet.minus(K, chi)) {			
							if(!HashList.pair_hash_in(D,upsilon, fi))
							{
								System.out.println("up " + upsilon +" chi " + chi + " fi " + fi);
								
								ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C);
								ArrayList<String> Cfi = HashList.getPartition(fi, C); 
								System.out.println(" Cupsilon" + Cupsilon);
								System.out.println(" Cfi" + Cfi);
								boolean found = false;
								for(String alpha : Cupsilon){
									for(String beta : Cfi){	
										if(!HashList.pair_hash_in(D,alpha, beta)
												&& HashList.pair_hash_in(D4,alpha, beta)){
											CostTuple tuple = selectGamma2(alpha, beta, T, C);
											String gamma = tuple.getGamma();
											alpha = tuple.getAlpha();
											beta = tuple.getBeta();
											
											if(gamma != null){
												String seq1 = TestSequence.concat(alpha, gamma);
												String seq2 = TestSequence.concat(beta, gamma);
												if(T4.contains(seq1) && T4.contains(seq2)){	
													found = true;
													
													TestSet.addAllPrefsOf(T, seq1);
													TestSet.addAllPrefsOf(T, seq2);
													System.out.println(" add test seq " + seq1 + " + " +seq2);
													
													TestSet.addAllPrefsOf(Relative, seq1);
													TestSet.addAllPrefsOf(Relative, seq2);
								
													updateC2(T, C);	
													System.out.println("MODE 1");
												
													Pair p_alphabeta = new Pair(alpha, beta);									
													if(HashList.add_pair_hash(D, alpha, beta)){
														ruler.applyRules3(p_alphabeta, AddedTo.D); 
													}													
												}
											}if(!found){
												tuple = selectGamma2(alpha, beta, T4, C4);
												gamma = tuple.getGamma();
												alpha = tuple.getAlpha();
												beta = tuple.getBeta();
												String seq1 = TestSequence.concat(alpha, gamma);
												String seq2 = TestSequence.concat(beta, gamma);
												if(T4.contains(seq1) && T4.contains(seq2)){	
													found = true;
													
													TestSet.addAllPrefsOf(T, seq1);
													TestSet.addAllPrefsOf(T, seq2);
													System.out.println(" add test seq " + seq1 + " + " +seq2);
													
													TestSet.addAllPrefsOf(Relative, seq1);
													TestSet.addAllPrefsOf(Relative, seq2);
								
													updateC2(T, C);
													System.out.println("MODE 3");
												
													Pair p_alphabeta = new Pair(alpha, beta);									
													if(HashList.add_pair_hash(D, alpha, beta)){
														ruler.applyRules3(p_alphabeta, AddedTo.D); 
													}													
												}
											}if(found) break;
										}if(found) break;										
									}			
								}
							}
						}
						
						//STEP 3
						Pair p_fi_chi = new Pair(fi, chi);
						if(HashList.add_pair_hash(C, fi, chi)){
							ruler.applyRules3(p_fi_chi, AddedTo.C);
						}				
						return alphax;
					}
				}
			}
		}
		//step05b(K, T4, T, T4, C, C4, D, D4);
		return null;
	}
	
	private String step05b_old(ArrayList<String> K, ArrayList<String> CunionK,
			ArrayList<String> T, ArrayList<String> T4,
			Map<String, ArrayList<String>> C, Map<String, ArrayList<String>> C4,
			Map<String, ArrayList<String>> D, Map<String, ArrayList<String>> D4) {
		
		FsmCoverage coverage = new FsmCoverage(fsm);
				
		// select the transition
		Transition transition = selectTransition(CunionK, coverage, T);
		State s = transition.getIn();		
		for (String alpha : T4) {			
			if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha) == s) {
				String alphax = TestSequence.concat(alpha,
						transition.getInput());
				if(T4.contains(alphax) && has_common_gamma(alphax,K,D4,C4,T4)){					
					TestSet.addAllPrefsOf(T, alphax);
					TestSet.addAllPrefsOf(Relative, alphax);

					System.out.println("Add fi step 5");
					
					updateC2(T, C);
					updateD2(D, T, alphax);				
					return alphax;
				}
			}
		}
		for (String alpha1 : CunionK) {			
			if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha1) == s) {
				String alphax = TestSequence.concat(alpha1,
						transition.getInput());
				
				TestSet.addAllPrefsOf(T, alphax);
				System.out.println("Add fi step 5 --------");

				updateC2(T, C);
				updateD2(D, T, alphax);				
				//return alphax;
				//STEP 4
				String fi = alphax;
				String chi = findChi(K, fi);
				for (String upsilon : TestSet.minus(K, chi)) {			
					if(!HashList.pair_hash_in(D,upsilon, fi))
					{
						ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C);
						ArrayList<String> Cfi = HashList.getPartition(fi, C); 
						String alpha = Cupsilon.get(0);
						String beta = Cfi.get(0);
						
						CostTuple tuple = selectGamma2(alpha, beta, T, C);
						String gamma = tuple.getGamma();
						alpha = tuple.getAlpha();
						beta = tuple.getBeta();

						if (gamma != null) {
							String seq1 = TestSequence.concat(alpha, gamma);
							String seq2 = TestSequence.concat(beta, gamma);
							System.out.println(" not found test0 " + seq1 + " + " +seq2);
							TestSet.addAllPrefsOf(T, seq1);
							TestSet.addAllPrefsOf(T, seq2);

							updateC2(T, C);

							Pair p_alphabeta = new Pair(alpha, beta);									
							if(HashList.add_pair_hash(D, alpha, beta)){
								ruler.applyRules3(p_alphabeta, AddedTo.D); 
							}  
						}
					}
				}
				
				//STEP 3
				Pair p_fi_chi = new Pair(fi, chi);
				if(HashList.add_pair_hash(C, fi, chi)){
					ruler.applyRules3(p_fi_chi, AddedTo.C);
				}
				return null;
			}
		}		
		return null;
	}
	
	public boolean has_common_gamma(String fi, ArrayList<String> K, 
			Map<String, ArrayList<String>> D4, Map<String, ArrayList<String>> C4,
			ArrayList<String> T4){
		
		String chi = findChi(K, fi);
		int up = 0;
		for (String upsilon : TestSet.minus(K, chi)) {
			if (HashList.pair_hash_in(D4,upsilon, fi)) {				
				
				ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C4);
				ArrayList<String> Cfi = HashList.getPartition(fi, C4);
				if(Cfi.size() > 0 && Cupsilon.size() > 0){				
					for(String alpha : Cupsilon){
						boolean found = false;
						for(String beta : Cfi){	
							ArrayList<String> alpha_ext = getExtensionsFrom(T4, alpha);
							ArrayList<String> beta_ext = getExtensionsFrom(T4, beta);
							
							for (String gamma : getCommonSufix(alpha, beta, alpha_ext,
									beta_ext)) {						
								State sa = fsm.nextStateWithSequence(
										fsm.getInitialState(), alpha);
								State sb = fsm.nextStateWithSequence(
										fsm.getInitialState(), beta);
								if (fsm.separe(gamma, sa, sb)) {
									String seq1 = TestSequence.concat(alpha, gamma);
									String seq2 = TestSequence.concat(beta, gamma);
									if(T4.contains(seq1) && T4.contains(seq2)){										
										up++;
										System.out.println(" exists " + seq1 + " + " +seq2);
										found = true;
										break;
									}
								}
							}if(found) break;
						}if(found) break;
					}
				}
			}			
		}
		if(up >= TestSet.minus(K, chi).size()){						
			return true;
		}		
		return false;
	}
	
	
	private String step05a(ArrayList<String> CunionK, ArrayList<String> T,
			Map<String, ArrayList<String>> C, Map<String, ArrayList<String>> D) {
		
		FsmCoverage coverage = new FsmCoverage(fsm);
		
		// select the transition
		Transition transition = selectTransition(CunionK, coverage, T);
		State s = transition.getIn();		
		for (String alpha : CunionK) {
			if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha) == s) {
				String alphax = TestSequence.concat(alpha,
						transition.getInput());
				TestSet.addAllPrefsOf(T, alphax);

				updateC2(T, C);
				updateD2(D, T, alphax);				
				return alphax;				
			}
		}
		return null;
	}
	
	
	private String step05aaa(ArrayList<String> CunionK, ArrayList<String> T,
			Map<String, ArrayList<String>> C, Map<String, ArrayList<String>> D) {
		
		FsmCoverage coverage = new FsmCoverage(fsm);
		
		// select the transition
		Transition transition = selectTransition(CunionK, coverage, T);
		State s = transition.getIn();		
		for (String alpha : CunionK) {
			if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha) == s) {
				String alphax = TestSequence.concat(alpha,
						transition.getInput());
				
				//teste
				/* ArrayList<String> gamma_list = new ArrayList<String>();
				//String c_alpha = c_tuple.get(0).getAlpha();
				//String c_beta = c_tuple.get(0).getBeta();
				Pair p_alphabeta = new Pair(alpha, alpha);				
				
				System.out.println("************ BEGIN ");
				String gamma = transition.getInput();
				gamma_list.add(gamma); 
				System.out.println("segm 1 " + alpha + " + "+ gamma);
				System.out.println("************ END ");
				decision.put(p_alphabeta, gamma_list);*/
							
				
				//normal				
				TestSet.addAllPrefsOf(T, alphax);

				updateC2(T, C);
				updateD2(D, T, alphax);				
				return alphax;				
			}
		}
		return null;
	}
	
	private String step05_random(ArrayList<String> CunionK, ArrayList<String> K, ArrayList<String> T,
			Map<String, ArrayList<String>> C, Map<String, ArrayList<String>> D) {
		
		FsmCoverage coverage = new FsmCoverage(fsm);
						
		// select the transition
		//Transition transition = selectTransition(CunionK, coverage, T);
		//ArrayList<Transition> uncoverTransitions = coverage.getNonCoveredtransitions(CunionK);
		//Random randomGenerator = new Random();
		//int rint = 0;
		//if(uncoverTransitions.size()>1) rint = randomGenerator.nextInt(uncoverTransitions.size());
		//Transition transition = coverage.getNonCoveredtransitions(CunionK).get(rint);
		Transition transition = coverage.getNonCoveredtransitions(CunionK).get(0);
			
		int min_alphax_cost = -1;
		ArrayList<String> alphax_list = new ArrayList<String>();
		//for(Transition transition : uncoverTransitions){
			State s = transition.getIn();			
			for (String alpha : CunionK) {
				if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha) == s) {
					String alphax = TestSequence.concat(alpha,
							transition.getInput());				
									
					String fi = alphax;						
					String a_cost[] = fi.split(",");
					int this_cost = step5_cost_random(fi, K, D, C, T);
					this_cost += a_cost.length;
					
					System.out.println("T "+TestSequence.getNoPrefixes(T));
					System.out.println("alphax "+alphax + " cost "+this_cost);
					
					if(min_alphax_cost < 0){
						min_alphax_cost = this_cost;
						alphax_list.add(alphax);
					}else if(this_cost < min_alphax_cost){
						alphax_list.clear();
						alphax_list.add(alphax);
						min_alphax_cost = this_cost;
					}//else if(this_cost == min_alphax_cost){
					//	alphax_list.add(alphax);
					//}
				}
			}
		//}
		if(alphax_list.size()<=0){
			return null;
		}else{
			//randomGenerator = new Random();
			//rint = 0;
			//if(alphax_list.size()>1) rint = randomGenerator.nextInt(alphax_list.size());
			
			//String alphax = alphax_list.get(rint);
			String alphax = alphax_list.get(0);
			TestSet.addAllPrefsOf(T, alphax);

			updateC2(T, C);
			updateD2(D, T, alphax);				
			return alphax;	
		}		
	}
	
	private int step5_cost_random(String fi, ArrayList<String> K, Map<String, ArrayList<String>> D,
			Map<String, ArrayList<String>> C, ArrayList<String> T){
		String chi = findChi(K, fi);
		int total_cost = 0;
		for (String upsilon : TestSet.minus(K, chi)) {
			int min_cost = -1;
			if(!HashList.pair_hash_in(D,upsilon, fi))
			{				
				String alpha = upsilon;
				String beta = fi;
								
				ArrayList<CostTuple> tuple = selectGamma4(alpha, beta, T, C);				
				for(CostTuple tu : tuple){
					int cost = tu.getAlphacost() + tu.getBetacost();					
					if(min_cost < 0){
						min_cost = cost;					
					}else if(cost < min_cost){
						min_cost = cost;						
					}
				}
			}
			if(min_cost > 0) total_cost += min_cost;
		}
		return total_cost;
	}
	
	public void updateD2(Map<String, ArrayList<String>> D, ArrayList<String> T, String alphax) {
		for (String alpha : TestSequence.getAllPrefixesFrom(alphax)) {
			for (String test : T) {
				if (!alpha.equals(test)) {
					// common extensions
					ArrayList<String> alpha_ext = getExtensionsFrom(T, alpha);
					ArrayList<String> beta_ext = getExtensionsFrom(T, test);					
					for (String gamma : getCommonSufix(alpha, test, alpha_ext,
							beta_ext)) {						
						State sa = fsm.nextStateWithSequence(
								fsm.getInitialState(), alpha);
						State sb = fsm.nextStateWithSequence(
								fsm.getInitialState(), test);
						if (fsm.separe(gamma, sa, sb)) {
							Pair p = new Pair(alpha, test);
							// System.out.println(p);
							//if (Pair.add(D, p)) {
							if(HashList.add_pair_hash(D, alpha, test)){
								ruler.applyRules3(p, AddedTo.D);
							}
							break;
						}
					}
				}
			}
		}
	}
	
	public Pair step04b(ArrayList<String> K, Map<String, ArrayList<String>> D, Map<String,ArrayList<String>> D4,
			Map<String, ArrayList<String>> C, ArrayList<String> T, ArrayList<String> T4,
			ArrayList<String> CUK) {
	
		FsmCoverage coverage = new FsmCoverage(fsm);
		String fi = "EPSILON";
		
		// select the transition
		Transition transition = selectTransition(CUK, coverage, T);
		State s = transition.getIn();		
		for (String alpha1 : CUK) {			
			if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha1) == s) {
				
				String alphax = TestSequence.concat(alpha1,
						transition.getInput());
				TestSet.addAllPrefsOf(T, alphax);
				updateC2(T, C);
				updateD2(D, T, alphax);
				
				fi = alphax;						
				String chi = findChi(K, fi);


				for (String upsilon : TestSet.minus(K, chi)) {
					//if (!Pair.in(new Pair(upsilon, fi), D))
					if(!HashList.pair_hash_in(D,upsilon, fi))
					{
						ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C);
						ArrayList<String> Cfi = HashList.getPartition(fi, C); 
						if(Cupsilon.size()>0 && Cfi.size()>0){

							String alpha = Cupsilon.get(0);
							String beta = Cfi.get(0);
	
							CostTuple tuple = selectGamma2(alpha, beta, T, C);
							String gamma = tuple.getGamma();
							alpha = tuple.getAlpha();
							beta = tuple.getBeta();
	
							if (gamma != null) {
								String seq1 = TestSequence.concat(alpha, gamma);
								String seq2 = TestSequence.concat(beta, gamma);
	
								TestSet.addAllPrefsOf(T, seq1);
								TestSet.addAllPrefsOf(T, seq2);
	
								updateC2(T, C);
	
								Pair p_alphabeta = new Pair(alpha, beta);
								System.out.println(alpha + " -> " +beta);
								System.out.println(seq1 + " -> " +seq2);
								//if (Pair.add(D, p_alphabeta)) {
								if(HashList.add_pair_hash(D, alpha, beta)){
									ruler.applyRules3(p_alphabeta, AddedTo.D); 
								}
							}
						}
					}
				}
				return new Pair(fi, chi);
				
				
				/*ArrayList<String> temp_T = new ArrayList<String>();
				Map<String, ArrayList<String>> temp_C = new HashMap<String, ArrayList<String>>();
				Map<String, ArrayList<String>> temp_D = new HashMap<String, ArrayList<String>>();
				
				temp_T.addAll(T);
				for (String a : C.keySet()) {
					ArrayList<String> aux = new ArrayList<String>();
					aux.addAll(C.get(a));
					String b = a;
					temp_C.put(b, aux); 
				}
				for (String a : D.keySet()) {
					ArrayList<String> aux = new ArrayList<String>();
					aux.addAll(D.get(a));
					String b = a;
					temp_D.put(b, aux); 
				}
				
				String alphax = TestSequence.concat(alpha1,
						transition.getInput());
				TestSet.addAllPrefsOf(T, alphax);

				updateC2(T, C);
				updateD2(D, T, alphax);			
				fi = alphax;
				
				int count = 0;
				String chi = findChi(K, fi);
				for (String upsilon : TestSet.minus(K, chi)) {	
					//nao existe em CUK (up, fi)
					if(!HashList.pair_hash_in(D,upsilon, fi)){
						ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C);
						ArrayList<String> Cfi = HashList.getPartition(fi, C); 
						if(Cfi.size() > 0 && Cupsilon.size() > 0){				
							for(String alpha : Cupsilon){
								boolean found = false;
								for(String beta : Cfi){	
									ArrayList<String> alpha_ext = getExtensionsFrom(T4, alpha);
									ArrayList<String> beta_ext = getExtensionsFrom(T4, beta);
									
									for (String gamma : getCommonSufix(alpha, beta, alpha_ext,
											beta_ext)) {						
										State sa = fsm.nextStateWithSequence(
												fsm.getInitialState(), alpha);
										State sb = fsm.nextStateWithSequence(
												fsm.getInitialState(), beta);
										if (fsm.separe(gamma, sa, sb)) {
											if (HashList.pair_hash_in(D4,upsilon, fi)) {							
												String seq1 = TestSequence.concat(alpha, gamma);
												String seq2 = TestSequence.concat(beta, gamma);
											
												if(T4.contains(seq1) && T4.contains(seq2)){								
													TestSet.addAllPrefsOf(T, seq1);
													TestSet.addAllPrefsOf(T, seq2);

													updateC2(T, C);

													Pair p_alphabeta = new Pair(alpha, beta);										
													if(HashList.add_pair_hash(D, alpha, beta)){
														ruler.applyRules3(p_alphabeta, AddedTo.D); 
													}
													count++;						
													System.out.println("New relat " + fi + " : " + seq1 + " -> " 
															+ seq2 + " -gamma: " + gamma + " up: "+ upsilon);
													
													found = true;
													break;
												}
											}
										}
									}if(found) break;
								}if(found) break;
							}
						}
					}else{
						System.out.println("New exist " + fi + " : " + chi +  " up: "+ upsilon);
						//ja existe em CUK (up, fi)						
						count++;
					}
				}
				if(count >= TestSet.minus(K, chi).size()){
					//T = temp_T;
					//C = temp_C;
					//D = temp_D;
					T.clear();
					C.clear();
					D.clear();
					T.addAll(temp_T);
					for (String a : temp_C.keySet()) {
						ArrayList<String> aux = new ArrayList<String>();
						aux.addAll(temp_C.get(a));
						String b = a;
						C.put(b, aux); 
					}
					for (String a : temp_D.keySet()) {
						ArrayList<String> aux = new ArrayList<String>();
						aux.addAll(temp_D.get(a));
						String b = a;
						D.put(b, aux); 
					}
					updateC2(T, C);
					updateD2(D, T, alphax);
					return new Pair(fi, chi);
				}*/
			}
		}
		return new Pair("EPSILON","EPSILON");
	}
	
	public Pair step04a(String fi, ArrayList<String> K, Map<String, ArrayList<String>> D,
			Map<String, ArrayList<String>> C, ArrayList<String> T) {
	
		String chi = findChi(K, fi);
		for (String upsilon : TestSet.minus(K, chi)) {			
			if(!HashList.pair_hash_in(D,upsilon, fi))
			{
				ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C);
				ArrayList<String> Cfi = HashList.getPartition(fi, C); 
			
				String alpha = Cupsilon.get(0);
				String beta = Cfi.get(0);

				CostTuple tuple = selectGamma2(alpha, beta, T, C);
				String gamma = tuple.getGamma();
				alpha = tuple.getAlpha();
				beta = tuple.getBeta();

				if (gamma != null) {
					String seq1 = TestSequence.concat(alpha, gamma);
					String seq2 = TestSequence.concat(beta, gamma);

					TestSet.addAllPrefsOf(T, seq1);
					TestSet.addAllPrefsOf(T, seq2);

					updateC2(T, C);

					Pair p_alphabeta = new Pair(alpha, beta);
					System.out.println(alpha + " -> " +beta);
					System.out.println(seq1 + " -> " +seq2);
					
					if(HashList.add_pair_hash(D, alpha, beta)){
						ruler.applyRules3(p_alphabeta, AddedTo.D); 
					}
				}
			}
		}
		return new Pair(fi, chi);
	}
	
	
	public Pair step04aaa(String fi, ArrayList<String> K, Map<String, ArrayList<String>> D,
			Map<String, ArrayList<String>> C, ArrayList<String> T) {
	
		String chi = findChi(K, fi);
		for (String upsilon : TestSet.minus(K, chi)) {			
			if(!HashList.pair_hash_in(D,upsilon, fi))
			{
				ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C);
				ArrayList<String> Cfi = HashList.getPartition(fi, C);

				String alpha = Cupsilon.get(0);
				String beta = Cfi.get(0);
				
				/*//teste
				ArrayList<CostTuple> c_tuple = selectGamma4(alpha, beta, new ArrayList<String>(), C);				
				
				ArrayList<String> gamma_list = new ArrayList<String>();
				//String c_alpha = c_tuple.get(0).getAlpha();
				//String c_beta = c_tuple.get(0).getBeta();
				Pair p_alphabeta = new Pair(alpha, beta);				
				
				System.out.println("************ BEGIN ");
				for(CostTuple tu : c_tuple){					
					String gamma = tu.getGamma();
					gamma_list.add(gamma); 
					System.out.println("segm 1 " + tu.getAlpha() + " + "+ tu.getGamma());
					System.out.println("segm 2 " + tu.getBeta() + " + "+ tu.getGamma());
				}
				System.out.println("************ END ");
				decision.put(p_alphabeta, gamma_list);
				*/
				
				//teste 2				
				ArrayList<CostTuple> tuple = selectGamma4(alpha, beta, T, C);			
				for(CostTuple tu : tuple){
					alpha = tu.getAlpha();
					beta = tu.getBeta();
					String gamma = tu.getGamma();
					
					String seq1 = TestSequence.concat(alpha, gamma);
					String seq2 = TestSequence.concat(beta, gamma);
					TestSet.addAllPrefsOf(T2, seq1);
					TestSet.addAllPrefsOf(T2, seq2);
					//System.out.println("seq 1 " + alpha + " + "+ gamma);
					//System.out.println("seq 2 " + beta + " + "+ gamma);
				}
				String gamma = "";
				int ini = tuple.get(0).getAlphacost() + tuple.get(0).getBetacost();				
				if(tuple.size() >= (iterator+1)){
					int ite = tuple.get(iterator).getAlphacost() + tuple.get(iterator).getBetacost();
					if(ite <= ini){
						alpha = tuple.get(iterator).getAlpha();
						beta = tuple.get(iterator).getBeta();
						gamma = tuple.get(iterator).getGamma();
					}else{
						alpha = tuple.get(0).getAlpha();
						beta = tuple.get(0).getBeta();
						gamma = tuple.get(0).getGamma();
					}
				}else{
					alpha = tuple.get(0).getAlpha();
					beta = tuple.get(0).getBeta();
					gamma = tuple.get(0).getGamma();
				}		
				//alpha = tuple.get(0).getAlpha();
				//beta = tuple.get(0).getBeta();
				//String gamma = tuple.get(0).getGamma();				
				String seq1 = TestSequence.concat(alpha, gamma);
				String seq2 = TestSequence.concat(beta, gamma);

				System.out.println("seq 1 " + alpha + " + "+ gamma);
				System.out.println("seq 2 " + beta + " + "+ gamma);
				TestSet.addAllPrefsOf(T, seq1);
				TestSet.addAllPrefsOf(T, seq2);
				
				updateC2(T, C);
				Pair p_alphabeta = new Pair(alpha, beta);
				if (HashList.add_pair_hash(D, alpha, beta)) {
					ruler.applyRules3(p_alphabeta, AddedTo.D); 
				}
			
				
				
				//modo normal	
				/*
				CostTuple tuple = selectGamma2(alpha, beta, T, C);
				String gamma = tuple.getGamma();
				alpha = tuple.getAlpha();
				beta = tuple.getBeta();

				if (gamma != null) {
					String seq1 = TestSequence.concat(alpha, gamma);
					String seq2 = TestSequence.concat(beta, gamma);

					TestSet.addAllPrefsOf(T, seq1);
					TestSet.addAllPrefsOf(T, seq2);

					updateC2(T, C);

					//Pair p_alphabeta = new Pair(alpha, beta);
					System.out.println(alpha + " -> " +beta);
					System.out.println(seq1 + " -> " +seq2);
					
					if(HashList.add_pair_hash(D, alpha, beta)){
						ruler.applyRules3(p_alphabeta, AddedTo.D); 
					}
				}	*/			
			}
		}
		return new Pair(fi, chi);
	}
	
	public Pair step04_random(String fi, ArrayList<String> K, Map<String, ArrayList<String>> D,
			Map<String, ArrayList<String>> C, ArrayList<String> T) {
	
		String chi = findChi(K, fi);
		for (String upsilon : TestSet.minus(K, chi)) {			
			if(!HashList.pair_hash_in(D,upsilon, fi))
			{
				ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C);
				ArrayList<String> Cfi = HashList.getPartition(fi, C);

				String alpha = Cupsilon.get(0);
				String beta = Cfi.get(0);
				
				//teste
				ArrayList<CostTuple> tuple = selectGamma4(alpha, beta, T, C);
				System.out.println("************ BEGIN ");
				int min_cost = -1;
				CostTuple min_tuple = new CostTuple(); 
				for(CostTuple tu : tuple){
					int cost = tu.getAlphacost() + tu.getBetacost();
					System.out.println("segm 1 " + tu.getAlpha() + " + "+ tu.getGamma()+" "+cost);
					System.out.println("segm 2 " + tu.getBeta() + " + "+ tu.getGamma()+" "+cost);
					if(min_cost < 0){
						min_cost = cost;
						min_tuple.setAlpha(tu.getAlpha());
						min_tuple.setBeta(tu.getBeta());
						min_tuple.setGamma(tu.getGamma());
					}else if(cost < min_cost){
						min_cost = cost;
						min_tuple.setAlpha(tu.getAlpha());
						min_tuple.setBeta(tu.getBeta());
						min_tuple.setGamma(tu.getGamma());
					}
				}
				System.out.println("************ END ");
				//test random
				//Random randomGenerator = new Random();
				//int rint = 0;
				//if(tuple.size()>1) rint = randomGenerator.nextInt(tuple.size());	
				//alpha = tuple.get(rint).getAlpha();
				//beta = tuple.get(rint).getBeta();
				//String gamma = tuple.get(rint).getGamma();
				alpha = min_tuple.getAlpha();
				beta = min_tuple.getBeta();
				String gamma = min_tuple.getGamma();			
				String seq1 = TestSequence.concat(alpha, gamma);
				String seq2 = TestSequence.concat(beta, gamma);

				System.out.println("seq 1 " + alpha + " + "+ gamma);
				System.out.println("seq 2 " + beta + " + "+ gamma);
				TestSet.addAllPrefsOf(T, seq1);
				TestSet.addAllPrefsOf(T, seq2);
				
				updateC2(T, C);
				Pair p_alphabeta = new Pair(alpha, beta);
				if (HashList.add_pair_hash(D, alpha, beta)) {
					ruler.applyRules3(p_alphabeta, AddedTo.D); 
				}
					
			}
		}
		return new Pair(fi, chi);
	}
	
	public void step03a(Map<String, ArrayList<String>> C, Pair p) {
	
		//if (Pair.add(C, pair)) {
		if(HashList.add_pair_hash(C, p.getLeft(), p.getRight())){
			ruler.applyRules3(p, AddedTo.C);
		}
	}
	
	public Pair findFiChi3b(ArrayList<String> T, ArrayList<String> CunionK,
			ArrayList<String> K, Map<String, ArrayList<String>> D) {
		
		for (String fi : TestSet.minus(T, CunionK)) {
			//System.out.println("FINDfi "+fi);			
			for (String chi : K) {
				//System.out.println("chi "+chi);
				boolean in = true;				
				for (String upsilon : TestSet.minus(K, chi)) {
					//System.out.println("upsilon "+upsilon);
					//if (!Pair.in(new Pair(fi, upsilon), D)) {
					if (!HashList.pair_hash_in(D,fi, upsilon)){
						in = false;
						break;
					}//else{
					//	String gamma = HashList.get_gamma_hash(ret2,fi, upsilon);
						//System.out.println("findFiChi3: up " + upsilon +" : " + fi +" / "+ chi +" -> "+ gamma);
					//}
					//if(fi.equals("SM,DM,F")){
					//	String gamma = HashList.get_gamma_hash(ret2,fi, upsilon);
					//	System.out.println("findFiChi3: up " + upsilon +" : " + fi +" / "+ chi +" -> "+ gamma);
					//}
					
				}

				if (in && isConvergent(fi, chi))
					return new Pair(fi, chi);
			}
		}

		return null;
	}	
	
	public ArrayList<Pair> findFiChi4(ArrayList<String> CunionK,
			ArrayList<String> K, Map<String, ArrayList<String>> D) {
		
		ArrayList<Pair> lp = new ArrayList<Pair>(); 
		for(String cuk : CunionK){
			ArrayList<String> pre_fi = TestSequence.getAllPrefixesFrom(cuk);
			for(String pre : pre_fi){
				if(!CunionK.contains(pre)){
					String fi = pre;
					String chi = findChi(K, fi);
					boolean in = true;				
					for (String upsilon : TestSet.minus(K, chi)) {					
						if (!HashList.pair_hash_in(D,fi, upsilon)){
							in = false;
							break;
						}					
					}
					if (in && isConvergent(fi, chi)){
						lp.add(new Pair(fi, chi));
					}						
				}
			}
		}
		return lp;
	}
	
	public Pair findFiChi3(ArrayList<String> T, ArrayList<String> CunionK,
			ArrayList<String> K, Map<String, ArrayList<String>> D) {
		
		for (String fi : TestSet.minus(T, CunionK)) {
			//System.out.println("FINDfi "+fi);			
			for (String chi : K) {
				//System.out.println("chi "+chi);
				boolean in = true;				
				for (String upsilon : TestSet.minus(K, chi)) {
					//System.out.println("upsilon "+upsilon);
					//if (!Pair.in(new Pair(fi, upsilon), D)) {
					if (!HashList.pair_hash_in(D,fi, upsilon)){
						in = false;
						break;
					}//else{
					//	String gamma = HashList.get_gamma_hash(ret2,fi, upsilon);
						//System.out.println("findFiChi3: up " + upsilon +" : " + fi +" / "+ chi +" -> "+ gamma);
					//}
					//if(fi.equals("SM,DM,F")){
					//	String gamma = HashList.get_gamma_hash(ret2,fi, upsilon);
					//	System.out.println("findFiChi3: up " + upsilon +" : " + fi +" / "+ chi +" -> "+ gamma);
					//}
					
				}

				if (in && isConvergent(fi, chi))
					return new Pair(fi, chi);
			}
		}

		return null;
	}
	
	public ArrayList<String> findCunionK2(Map<String, ArrayList<String>> C, ArrayList<String> K) {
		ArrayList<String> ret = new ArrayList<String>();
		
		for(String k : K){
			if(C.get(k)!=null){
				for(String a : C.get(k)){
					if(!ret.contains(a)){
						ret.add(a);
					}
				}				
			}
		}
		return ret;
	}
	
	public void step02d(ArrayList<String> T, Map<String, ArrayList<String>> C,
			Map<String, ArrayList<String>> D, ArrayList<String> K, ArrayList<String> K2) {
		
		String alpha = selectAlpha(K);	
		for (String beta : K) {
			if(HashList.pair_hash_in(D,alpha,beta)){	
				CostTuple tuple = selectGamma2(alpha, beta, T, C);
				if(tuple!=null){
					String gamma = tuple.getGamma();
					alpha = tuple.getAlpha();
					beta = tuple.getBeta();
					String alphagamma = TestSequence.concat(alpha, gamma);
					String betagamma = TestSequence.concat(beta, gamma);
					if(!T.contains(alphagamma) || !T.contains(betagamma)){
						identify_rule_rec(alpha, beta, K2);
					}					
				}
			}else{
				System.out.println("ERROR STEP 2");
			}			
		}
		K.add(alpha);		
	}
	
	public void step02c(ArrayList<String> T, Map<String, ArrayList<String>> C,
			Map<String, ArrayList<String>> D, ArrayList<String> K) {
		
		String alpha = selectAlpha(K);	
		/*for (String beta : K) {
			if(!HashList.pair_hash_in(D,alpha,beta)){	
				CostTuple tuple = selectGamma2(alpha, beta, T, C);
				if(tuple!=null){
					String gamma = tuple.getGamma();
					alpha = tuple.getAlpha();
					beta = tuple.getBeta();
					String alphagamma = TestSequence.concat(alpha, gamma);
					String betagamma = TestSequence.concat(beta, gamma);
					HashList.add_pair_hash(D, alpha, beta);
					add_relative(alphagamma, betagamma);					
					//HashList.add_triple_hash(D3, alpha, beta, gamma);
				}
			}
		}*/
		K.add(alpha);		
	}
	
	public void step02b(ArrayList<String> T, Map<String, ArrayList<String>> C,
			Map<String, ArrayList<String>> D, ArrayList<String> K) {
		
		String alpha = selectAlpha(K);
	
		for (String beta : K) {			
			//if (!Pair.in(new Pair(alpha, beta), D)) {
			if(!HashList.pair_hash_in(D,alpha,beta)){	
				CostTuple tuple = selectGamma2(alpha, beta, T, C);
				//String gamma = tuple.getGamma();
				alpha = tuple.getAlpha();
				beta = tuple.getBeta();
											
				Pair p_alphabeta = new Pair(alpha, beta);
				if (HashList.add_pair_hash(D, alpha, beta)) {
					ruler.applyRules5(p_alphabeta, AddedTo.D); 
				}
			}
		}
		K.add(alpha);		
	}
	
	public void step02a(ArrayList<String> T, Map<String, ArrayList<String>> C,
			Map<String, ArrayList<String>> D, ArrayList<String> K) {
		
		String alpha = selectAlpha(K);
	
		for (String beta : K) {			
			//if (!Pair.in(new Pair(alpha, beta), D)) {
			if(!HashList.pair_hash_in(D,alpha,beta)){	
				
				System.out.println("alpha " + alpha);
				System.out.println("beta " + beta);
				
				CostTuple tuple = selectGamma2(alpha, beta, T, C);
				String gamma = tuple.getGamma();
				alpha = tuple.getAlpha();
				beta = tuple.getBeta();				
				
				System.out.println("seq 1 " + alpha + " + "+ gamma);
				System.out.println("seq 2 " + beta + " + "+ gamma);
				if(alpha  == null ){
					System.out.println("Não tem como distinguir estados!");
				}
				
				String seq1 = TestSequence.concat(alpha, gamma);
				String seq2 = TestSequence.concat(beta, gamma);
				
				TestSet.addAllPrefsOf(T, seq1);
				TestSet.addAllPrefsOf(T, seq2);
				
				updateC2(T, C);
			
				Pair p_alphabeta = new Pair(alpha, beta);
				if (HashList.add_pair_hash(D, alpha, beta)) {
					ruler.applyRules3(p_alphabeta, AddedTo.D); 
				}
			}
		}
		K.add(alpha);
	}
	
	public void step02aaa00(ArrayList<String> T, Map<String, ArrayList<String>> C,
			Map<String, ArrayList<String>> D, ArrayList<String> K) {
		
		String alpha = selectAlpha(K);
	
		for (String beta : K) {
			if(!HashList.pair_hash_in(D,alpha,beta)){	
				//System.out.println("************ SELECT ");							
				/*
				ArrayList<CostTuple> tuple = selectGamma4(alpha, beta, new ArrayList<String>(), C);		
				ArrayList<String> gamma_list = new ArrayList<String>();
				//alpha = tuple.get(0).getAlpha();
				//beta = tuple.get(0).getBeta();						
				
				System.out.println("************ BEGIN ");
				for(CostTuple tu : tuple){					
					String gamma = tu.getGamma();
					gamma_list.add(gamma); 
					System.out.println("segm 1 " + tu.getAlpha() + " + "+ tu.getGamma());
					System.out.println("segm 2 " + tu.getBeta() + " + "+ tu.getGamma());
				}
				System.out.println("************ END ");
				decision.put(p_alphabeta, gamma_list);
						
				for(Pair p : decision.keySet()){
					String a = p.getLeft();
					String b = p.getRight();
					if(a.equals(alpha) && b.equals(beta)){
						System.out.println("CORRETO!!! ");
						break;
					}
				}	*/		
				ArrayList<CostTuple> tuple = selectGamma4(alpha, beta, T, C);	
				//test
				for(CostTuple tu : tuple){
					alpha = tu.getAlpha();
					beta = tu.getBeta();
					String gamma = tu.getGamma();
					
					String seq1 = TestSequence.concat(alpha, gamma);
					String seq2 = TestSequence.concat(beta, gamma);
					TestSet.addAllPrefsOf(T2, seq1);
					TestSet.addAllPrefsOf(T2, seq2);	
					System.out.println("T2-> " + alpha + " + "+ gamma);
					System.out.println("T2-> " + beta + " + "+ gamma);
				}	
				
				String gamma = "";
				int ini = tuple.get(0).getAlphacost() + tuple.get(0).getBetacost();				
				if(tuple.size() >= (iterator+1)){
					int ite = tuple.get(iterator).getAlphacost() + tuple.get(iterator).getBetacost();
					if(ite <= ini){
						alpha = tuple.get(iterator).getAlpha();
						beta = tuple.get(iterator).getBeta();
						gamma = tuple.get(iterator).getGamma();
					}else{
						alpha = tuple.get(0).getAlpha();
						beta = tuple.get(0).getBeta();
						gamma = tuple.get(0).getGamma();
					}
				}else{
					alpha = tuple.get(0).getAlpha();
					beta = tuple.get(0).getBeta();
					gamma = tuple.get(0).getGamma();
				}			
				//alpha = tuple.get(0).getAlpha();
				//beta = tuple.get(0).getBeta();
				//String gamma = tuple.get(0).getGamma();				
				String seq1 = TestSequence.concat(alpha, gamma);
				String seq2 = TestSequence.concat(beta, gamma);

				System.out.println("seq 1 " + alpha + " + "+ gamma);
				System.out.println("seq 2 " + beta + " + "+ gamma);
				TestSet.addAllPrefsOf(T, seq1);
				TestSet.addAllPrefsOf(T, seq2);
				
				updateC2(T, C);			
				Pair p_alphabeta = new Pair(alpha, beta);
				if (HashList.add_pair_hash(D, alpha, beta)) {
					ruler.applyRules3(p_alphabeta, AddedTo.D); 
				}
				
				/*
				//normal
				String gamma = tuple.get(0).getGamma();				
				String seq1 = TestSequence.concat(alpha, gamma);
				String seq2 = TestSequence.concat(beta, gamma);

				System.out.println("seq 1 " + alpha + " + "+ gamma);
				System.out.println("seq 2 " + beta + " + "+ gamma);
				TestSet.addAllPrefsOf(T, seq1);
				TestSet.addAllPrefsOf(T, seq2);
				
				updateC2(T, C);			
				
				Pair p_alphabeta = new Pair(alpha, beta);
				if (HashList.add_pair_hash(D, alpha, beta)) {
					ruler.applyRules3(p_alphabeta, AddedTo.D); 
				}*/
			}
		}
		K.add(alpha);
	}
	
	public void step02aaa(ArrayList<String> T, Map<String, ArrayList<String>> C,
			Map<String, ArrayList<String>> D, ArrayList<String> K) {
		
		String alpha = selectAlpha(K);
	
		for (String beta : K) {
			if(!HashList.pair_hash_in(D,alpha,beta)){	
				//System.out.println("************ SELECT ");							
				/*
				ArrayList<CostTuple> tuple = selectGamma4(alpha, beta, new ArrayList<String>(), C);		
				ArrayList<String> gamma_list = new ArrayList<String>();
				//alpha = tuple.get(0).getAlpha();
				//beta = tuple.get(0).getBeta();						
				
				System.out.println("************ BEGIN ");
				for(CostTuple tu : tuple){					
					String gamma = tu.getGamma();
					gamma_list.add(gamma); 
					System.out.println("segm 1 " + tu.getAlpha() + " + "+ tu.getGamma());
					System.out.println("segm 2 " + tu.getBeta() + " + "+ tu.getGamma());
				}
				System.out.println("************ END ");
				decision.put(p_alphabeta, gamma_list);
						
				for(Pair p : decision.keySet()){
					String a = p.getLeft();
					String b = p.getRight();
					if(a.equals(alpha) && b.equals(beta)){
						System.out.println("CORRETO!!! ");
						break;
					}
				}	*/		
				ArrayList<CostTuple> tuple = selectGamma4(alpha, beta, T, C);	
				//test
				for(CostTuple tu : tuple){
					alpha = tu.getAlpha();
					beta = tu.getBeta();
					String gamma = tu.getGamma();
					
					String seq1 = TestSequence.concat(alpha, gamma);
					String seq2 = TestSequence.concat(beta, gamma);
					TestSet.addAllPrefsOf(T2, seq1);
					TestSet.addAllPrefsOf(T2, seq2);	
					System.out.println("T2-> " + alpha + " + "+ gamma);
					System.out.println("T2-> " + beta + " + "+ gamma);
				}	
				/*
				String gamma = "";
				int ini = tuple.get(0).getAlphacost() + tuple.get(0).getBetacost();				
				if(tuple.size() >= (iterator+1)){
					int ite = tuple.get(iterator).getAlphacost() + tuple.get(iterator).getBetacost();
					if(ite <= ini){
						alpha = tuple.get(iterator).getAlpha();
						beta = tuple.get(iterator).getBeta();
						gamma = tuple.get(iterator).getGamma();
					}else{
						alpha = tuple.get(0).getAlpha();
						beta = tuple.get(0).getBeta();
						gamma = tuple.get(0).getGamma();
					}
				}else{
					alpha = tuple.get(0).getAlpha();
					beta = tuple.get(0).getBeta();
					gamma = tuple.get(0).getGamma();
				}*/			
				alpha = tuple.get(0).getAlpha();
				beta = tuple.get(0).getBeta();
				String gamma = tuple.get(0).getGamma();				
				String seq1 = TestSequence.concat(alpha, gamma);
				String seq2 = TestSequence.concat(beta, gamma);

				System.out.println("seq 1 " + alpha + " + "+ gamma);
				System.out.println("seq 2 " + beta + " + "+ gamma);
				TestSet.addAllPrefsOf(T, seq1);
				TestSet.addAllPrefsOf(T, seq2);
				
				updateC2(T, C);			
				Pair p_alphabeta = new Pair(alpha, beta);
				if (HashList.add_pair_hash(D, alpha, beta)) {
					ruler.applyRules3(p_alphabeta, AddedTo.D); 
				}
				
				/*
				//normal
				String gamma = tuple.get(0).getGamma();				
				String seq1 = TestSequence.concat(alpha, gamma);
				String seq2 = TestSequence.concat(beta, gamma);

				System.out.println("seq 1 " + alpha + " + "+ gamma);
				System.out.println("seq 2 " + beta + " + "+ gamma);
				TestSet.addAllPrefsOf(T, seq1);
				TestSet.addAllPrefsOf(T, seq2);
				
				updateC2(T, C);			
				
				Pair p_alphabeta = new Pair(alpha, beta);
				if (HashList.add_pair_hash(D, alpha, beta)) {
					ruler.applyRules3(p_alphabeta, AddedTo.D); 
				}*/
			}
		}
		K.add(alpha);
	}
	
	public void step02_random(ArrayList<String> T, Map<String, ArrayList<String>> C,
			Map<String, ArrayList<String>> D, ArrayList<String> K) {
		
		String alpha = selectAlpha(K);
	
		for (String beta : K) {
			if(!HashList.pair_hash_in(D,alpha,beta)){	
					
				System.out.println("************ SELECT ");	
				ArrayList<CostTuple> tuple = selectGamma4(alpha, beta, T, C);
				System.out.println("************ BEGIN ");
				int min_cost = -1;
				CostTuple min_tuple = new CostTuple(); 
				for(CostTuple tu : tuple){
					int cost = tu.getAlphacost() + tu.getBetacost();
					System.out.println("segm 1 " + tu.getAlpha() + " + "+ tu.getGamma()+" "+cost);
					System.out.println("segm 2 " + tu.getBeta() + " + "+ tu.getGamma()+" "+cost);
					if(min_cost < 0){
						min_cost = cost;
						min_tuple.setAlpha(tu.getAlpha());
						min_tuple.setBeta(tu.getBeta());
						min_tuple.setGamma(tu.getGamma());
					}else if(cost < min_cost){
						min_cost = cost;
						min_tuple.setAlpha(tu.getAlpha());
						min_tuple.setBeta(tu.getBeta());
						min_tuple.setGamma(tu.getGamma());
					}
				}
				System.out.println("************ END ");
				//test random
				//Random randomGenerator = new Random();
				//int rint = 0;
				//if(tuple.size()>1) rint = randomGenerator.nextInt(tuple.size());	
				//alpha = tuple.get(rint).getAlpha();
				//beta = tuple.get(rint).getBeta();
				//String gamma = tuple.get(rint).getGamma();
				alpha = min_tuple.getAlpha();
				beta = min_tuple.getBeta();
				String gamma = min_tuple.getGamma();
				String seq1 = TestSequence.concat(alpha, gamma);
				String seq2 = TestSequence.concat(beta, gamma);

				System.out.println("seq 1 " + alpha + " + "+ gamma);
				System.out.println("seq 2 " + beta + " + "+ gamma);
				TestSet.addAllPrefsOf(T, seq1);
				TestSet.addAllPrefsOf(T, seq2);
				
				updateC2(T, C);			
				Pair p_alphabeta = new Pair(alpha, beta);
				if (HashList.add_pair_hash(D, alpha, beta)) {
					ruler.applyRules3(p_alphabeta, AddedTo.D); 
				}				
			}
		}
		K.add(alpha);
	}
	
	private void updateC2(ArrayList<String> T, Map<String, ArrayList<String>> C) {
		for (String test : T) {			
			if(C.get(test)==null){
				ArrayList<String> arr = new ArrayList<String>();
				arr.add(test);
				C.put(test, arr);
			}
		}
	}
	
	public CostTuple selectGamma3(String alpha, String beta,
			ArrayList<String> T, ArrayList<String> T4, Map<String, ArrayList<String>> C) {
		CharacterizationSetConstructor csc = new CharacterizationSetConstructor();
		csc.setFsm(fsm);

		return csc.getDistinguishSequence3(alpha, beta, T, T4, C);
	}
	
	public CostTuple selectGamma2(String alpha, String beta,
			ArrayList<String> T, Map<String, ArrayList<String>> C) {
		CharacterizationSetConstructor csc = new CharacterizationSetConstructor();
		csc.setFsm(fsm);
		//CostTuple ct = csc.getDistinguishSequence3(alpha, beta, T, C);
		//if(ct != null) return ct;
		return csc.getDistinguishSequence2(alpha, beta, T, C);
	}
	
	public ArrayList<CostTuple> selectGamma4(String alpha, String beta,
			ArrayList<String> T, Map<String, ArrayList<String>> C) {
		CharacterizationSetConstructor csc = new CharacterizationSetConstructor();
		csc.setFsm(fsm);
		//CostTuple ct = csc.getDistinguishSequence3(alpha, beta, T, C);
		//if(ct != null) return ct;
		ArrayList<CostTuple> tuples = csc.getDistinguishSequence4(alpha, beta, TestSequence.getNoPrefixes(T), C);
		return tuples;
	}
	
	private HashMap<String, ArrayList<String>> getIdentityRelation2(ArrayList<String> T) {
		HashMap<String, ArrayList<String>> ret = new HashMap<String, ArrayList<String>>();
		ArrayList<String> arr = null;
		for (String test : T){
			arr = new ArrayList<String>();
			arr.add(test);			
			if(ret.get(test)==null){
				ret.put(test, arr);
			}	
		}
		return ret;
	}
	
	public HashMap<String, ArrayList<String>> getTSeparatedTestPairs5_old(ArrayList<String> T) {
		HashMap<String, ArrayList<String>> ret = new HashMap<String, ArrayList<String>>();
		
		ArrayList<String> Tb = new ArrayList<String>();
		Tb.addAll(T);
		for (String alpha : T) {
			for (String beta : T) {
				if (!alpha.equals(beta)) {
					if(D.get(alpha) != null){
						if(D.get(alpha).contains(beta)){
							continue;
						}
					}
					// common extensions
					ArrayList<String> alpha_ext = getExtensionsFrom(T, alpha);
					ArrayList<String> beta_ext = getExtensionsFrom(T, beta);

					for (String gamma : getCommonSufix(alpha, beta, alpha_ext,
							beta_ext)) {
						State sa = fsm.nextStateWithSequence(
								fsm.getInitialState(), alpha);
						State sb = fsm.nextStateWithSequence(
								fsm.getInitialState(), beta);
						if (fsm.separe(gamma, sa, sb)) {							
							HashList.add_pair_hash(ret, alpha, beta);
							HashList.add_triple_hash(D3, alpha, beta, gamma);
							HashList.add_pair_hash(ret, beta, alpha);
							HashList.add_triple_hash(D3, beta, alpha, gamma);
							break;
						}
					}
				}
			}
		}
		return ret;
	}
	
	public HashMap<String, ArrayList<String>> getTSeparatedTestPairs5(ArrayList<String> T) {
		HashMap<String, ArrayList<String>> ret = new HashMap<String, ArrayList<String>>();		
		for (String alpha : T) {
			for (String beta : T) {
				if (!alpha.equals(beta)) {
					// common extensions
					ArrayList<String> alpha_ext = getExtensionsFrom(T, alpha);
					ArrayList<String> beta_ext = getExtensionsFrom(T, beta);

					for (String gamma : getCommonSufix(alpha, beta, alpha_ext,
							beta_ext)) {
						State sa = fsm.nextStateWithSequence(
								fsm.getInitialState(), alpha);
						State sb = fsm.nextStateWithSequence(
								fsm.getInitialState(), beta);
						if (fsm.separe(gamma, sa, sb)) {							
							HashList.add_pair_hash(ret, alpha, beta);
							HashList.add_triple_hash(D3, alpha, beta, gamma);
							break;
						}
					}
				}
			}
		}

		return ret;
	}
	
	public HashMap<String, ArrayList<String[]>> getTSeparatedTestPairs4(ArrayList<String> T) {
		HashMap<String, ArrayList<String[]>> ret = new HashMap<String, ArrayList<String[]>>();
		//ret2.clear();
		for (String alpha : T) {
			for (String beta : T) {
				if (!alpha.equals(beta)) {
					// common extensions
					ArrayList<String> alpha_ext = getExtensionsFrom(T, alpha);
					ArrayList<String> beta_ext = getExtensionsFrom(T, beta);

					for (String gamma : getCommonSufix(alpha, beta, alpha_ext,
							beta_ext)) {
						State sa = fsm.nextStateWithSequence(
								fsm.getInitialState(), alpha);
						State sb = fsm.nextStateWithSequence(
								fsm.getInitialState(), beta);
						if (fsm.separe(gamma, sa, sb)) {							
							//HashList.add_pair_hash(ret, alpha, beta);
							HashList.add_triple_hash(ret, alpha, beta, gamma);
							break;
						}
					}
				}
			}
		}

		return ret;
	}
	
	public HashMap<String, ArrayList<String>> getTSeparatedTestPairs3(ArrayList<String> T) {
		HashMap<String, ArrayList<String>> ret = new HashMap<String, ArrayList<String>>();
		//ret2.clear();
		for (String alpha : T) {
			for (String beta : T) {
				if (!alpha.equals(beta)) {
					// common extensions
					ArrayList<String> alpha_ext = getExtensionsFrom(T, alpha);
					ArrayList<String> beta_ext = getExtensionsFrom(T, beta);

					for (String gamma : getCommonSufix(alpha, beta, alpha_ext,
							beta_ext)) {
						State sa = fsm.nextStateWithSequence(
								fsm.getInitialState(), alpha);
						State sb = fsm.nextStateWithSequence(
								fsm.getInitialState(), beta);
						if (fsm.separe(gamma, sa, sb)) {							
							HashList.add_pair_hash(ret, alpha, beta);
							//HashList.add_triple_hash(ret2, alpha, beta, gamma);
							break;
						}
					}
				}
			}
		}

		return ret;
	}
		
	public void print_file(String out, String path) throws IOException{
		File file3 = new File(path);
		if(!file3.exists()){
			file3.createNewFile();
		}
		FileWriter w = new FileWriter(file3);
		w.write(out);
		w.close();
	}
	
	public String compare(String f1, String f2) {	
		File file1 = new File(f1);
		File file2 = new File(f2);
		
		String out = "";			
		boolean found = false;
		try {
			ArrayList<String> equal = new ArrayList<String>();
			ArrayList<String> diff = new ArrayList<String>();
			ArrayList<Pair> prefix = new ArrayList<Pair>();
			ArrayList<Pair> sufix = new ArrayList<Pair>();
			
			BufferedReader reader2 = new BufferedReader(new FileReader(file2));
			String line2 = "";
			while((line2 = reader2.readLine()) != null)
			{
				BufferedReader reader1 = new BufferedReader(new FileReader(file1));
				String line1 = "";
				while((line1 = reader1.readLine()) != null){
					if(line1.equals(line2)){
						found = true;
						equal.add(line2);
						break;
					}
					if(TestSequence.isPrefixOf(line2, line1)){
						found = true;
						Pair o = new Pair(line2, line1);
						prefix.add(o);
					}
					if(TestSequence.isPrefixOf(line1, line2)){
						found = true;
						Pair o = new Pair(line2, line1);
						sufix.add(o);
					}
				}
				if(!found){
					//System.out.println(line2);
					diff.add(line2);
				}
				found = false;
				reader1.close();
			}			
			reader2.close();
			//System.out.println("Diff-----file2 - file1");
			out = out.concat("Diff-----file2 - file1\n");
			for(int i=0;i<diff.size();i++){
				//System.out.println(diff.get(i));
				out = out.concat(diff.get(i) + "\n");
			}
			//System.out.println("Equal-----");
			out = out.concat("Equal-----\n");
			for(int i=0;i<equal.size();i++){
				//System.out.println(equal.get(i));
				out = out.concat(equal.get(i) + "\n");
			}
			//System.out.println("Prefix-----file2 -> file1");
			out = out.concat("Prefix-----file2 -> file1\n");
			for(int i=0;i<prefix.size();i++){
				//System.out.println(prefix.get(i).getLeft() + " -> " + prefix.get(i).getRight());
				out = out.concat(prefix.get(i).getLeft() + " -> " + prefix.get(i).getRight()+ "\n");
			}
			//System.out.println("Sufix-----file2 -> file1");
			out = out.concat("Sufix-----file2 -> file1\n");
			for(int i=0;i<sufix.size();i++){
				//System.out.println(sufix.get(i).getLeft() + " -> " + sufix.get(i).getRight());
				out = out.concat(sufix.get(i).getLeft() + " -> " + sufix.get(i).getRight() + "\n");
			}
		} 		
		catch (Exception e) 
		{
			e.printStackTrace();
		}	
		return out;
	}
	
	public ArrayList<String> get_relevant4_old2(){
		
		ArrayList<String> T = new ArrayList<String>();
		for (String s : initialTestSet){			
			TestSet.addAllPrefsOf(T, s);
		}		
		//-------STEP  1 -------	
		Map<String, ArrayList<String>> C = getIdentityRelation2(T);			
		Map<String, ArrayList<String>> D = getTSeparatedTestPairs3(T);
		Map<String, ArrayList<String>> temp_D = new HashMap<String, ArrayList<String>>();
				
		for (String a : D.keySet()) {
			ArrayList<String> aux = new ArrayList<String>();
			aux.addAll(D.get(a));
			String b = a;
			temp_D.put(b, aux); 
		}
		
		ruler = new Ruler(C, D, T);		
		for (String a : temp_D.keySet()) {
			for (String b : temp_D.get(a)) {				
				ruler.applyRules3(new Pair(a,b), AddedTo.D);			
			}			
		}			
		
		if(T.size()<=0) return new ArrayList<String>();		
		ArrayList<String> K = new ArrayList<String>();
			
		int n = fsm.getStates().size();
		while (K.size() < Math.min(p + 1, n)) // CONDITION 1
		{
			// -------STEP 2
			step02b(T, C, D, K);
			System.out.println("step2");			
		}
		
		//-------STEP  3 -------			
		CunionK = findCunionK2(C, K);	
		print_set(CunionK,"CunionK\n");
		FsmCoverage coverage = new FsmCoverage(fsm);
		
		ArrayList<String> R = new ArrayList<String>();
		R.add("EPSILON");
					
		Pair p_fichi = findFiChi3(T, CunionK, K, D);
		while(p_fichi != null) {
			System.out.println(" fi - " + p_fichi);			
			if (HashList.add_pair_hash(C, p_fichi.getLeft(), p_fichi.getRight())) {
				ruler.applyRules3(p_fichi, AddedTo.C); 
			}
			CunionK = findCunionK2(C, K);
			//print_set(CunionK,"CunionK\n");			
			p_fichi = findFiChi3(T, CunionK, K, D);
		}
		
		ArrayList<String> T0 = new ArrayList<String>();//final relevant set
		Map<String, ArrayList<String>> C0 = new HashMap<String, ArrayList<String>>();		//convergence set
		Map<String, ArrayList<String>> D0 = new HashMap<String, ArrayList<String>>();	//divergence set	
					
		ArrayList<String> CUK = new ArrayList<String>();
		CUK = findCunionK2(C0, K);
		
		T0.add("EPSILON");		
		ruler = new Ruler(C0, D0, T0);
		K = new ArrayList<String>();
		
		while (K.size() < Math.min(p + 1, n)) // CONDITION 1
		{
			// -------STEP 2
			step02b(T0, C0, D0, K);
			System.out.println("step2");			
		}
	/*			
		ArrayList<Transition> uncov_list = coverage.getNonCoveredtransitions(CunionK);
		ArrayList<Transition> all_list = fsm.getTransitions();		
		ArrayList<Transition> cov_list = new ArrayList<Transition>();
		
		for(Transition t : all_list){
			if(!uncov_list.contains(t)){
				cov_list.add(t);
			}
		}
		System.out.println("Non_cov " + coverage.getNonCoveredtransitions(CunionK));
		System.out.println("Coverage "+ cov_list);
		for(Transition t : cov_list){
			State s = t.getIn();
			boolean cond = false;
			for (String alpha : CunionK) {				
				if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha) == s) {				
					String alphax = TestSequence.concat(alpha, t.getInput());						
					if(CunionK.contains(alphax)){	
						System.out.println("\nTESTY " + alphax);
						//findFiChi3b(T0,C0,K,D0);
						p_fichi = findFiChi3(T0, CUK, K, D0);
						while(p_fichi != null) {									
							if (HashList.add_pair_hash(C0, p_fichi.getLeft(), p_fichi.getRight())) {
								ruler.applyRules3(p_fichi, AddedTo.C); 
							}
							CUK = findCunionK2(C0, K);									
							p_fichi = findFiChi3(T0, CUK, K, D0);
						}
						cond = step4_6(alphax,K,D0,C0,C,T0,T);	
						//cond = step4_7(alphax,K,D,C,T0,T);	
					}
				}
				if(cond){	
					System.out.println("Covered " + alpha + " / " + t.getInput());
					break;
				}
			}
			System.out.println("Transition " + t); 
		}
		
		*/
				
		while (!coverage.isInitializedTransitionCoverage(CUK)) {	
			
			// CONDITION 4
			p_fichi = findFiChi3(T0, CUK, K, D0);
			
			if (p_fichi != null) // C4 YES
			{
				step03a(C0, p_fichi);						
				System.out.println("step3 fi: "+ p_fichi);
			} else // C4 NO
			{	
				// CONDITION 5
				if (!CUK.contains("EPSILON")) // C5 NO
				{
					// step 4 fi = epsilon
					Pair p_fichi2 = step04a("EPSILON", K, D0, C0, T0);
					step03a(C0, p_fichi2);
					System.out.println("step4");
				} else // C5 YES
				{
					System.out.println("uncov " + coverage.getNonCoveredtransitions(CUK));
					//print_set(CunionK,"CunionK");
					String fi = step05a(CUK, T0, C0, D0);						
					Pair p_fichi2 = step04a(fi, K, D0, C0, T0);
					step03a(C0, p_fichi2);
					System.out.println("step5 fi: "+ fi);						
				}
			/*	{
					//String fi = step05a(CUK, T0, C0, D0);						
					//Pair p_fichi2 = step04b(K, D0, D, C0, T0, T, CUK);
					//if(p_fichi2.equals(new Pair("EPSILON","EPSILON"))){
						System.out.println("uncov " + coverage.getNonCoveredtransitions(CUK));						
						String fi = step05a(CUK, T0, C0, D0);						
						Pair p_fichi2 = step04a(fi, K, D0, C0, T0);
						step03a(C, p_fichi2);
						System.out.println("step5 add fi: "+ fi);
					//}else{
					//	step03a(C0, p_fichi2);
					//	System.out.println("step5 fi: "+ p_fichi2);
					//}											
				}*/
			}
			CUK = findCunionK2(C0, K);			
			System.out.println("coverage rel: "
					+ coverage.transitionCoverage(CUK));
			
		}
		
		
		
		
		Relative = new ArrayList<String>();		
		Relative.addAll(T0);
				
		return T0;
	}
	
	public Pair findFiChi3b(ArrayList<String> T, Map<String, ArrayList<String>> C,
			ArrayList<String> K, Map<String, ArrayList<String>> D) {
		
		for (String fi : T) {				
			for (String chi : K) {				
				boolean in = true;				
				for (String upsilon : TestSet.minus(K, chi)) {					
					if (!HashList.pair_hash_in(D,fi, upsilon)){
						in = false;
						break;
					}
				}
				if (in && isConvergent(fi, chi)){
					//Pair p_fi_chi = 
					return new Pair(fi, chi);
					//if (HashList.add_pair_hash(C, fi, chi)) {
					//	ruler.applyRules3(p_fi_chi, AddedTo.C); 
					//}
				}					
			}
		}
		return null;
	}
	
	public ArrayList<String> get_relevant4_old(){
			
		ArrayList<String> T2 = new ArrayList<String>(); //test cases from T input without prefixes
		for (String s : initialTestSet){
			T2.add(s);
		}			
			
		ArrayList<String> T4 = new ArrayList<String>();//all test cases from T input with all prefixes
		for (String typ : T2) {
			TestSet.addAllPrefsOf(T4, typ);
		}			
		
		//-------STEP  1 -------	
			
		ArrayList<Pair> C = getIdentityRelation(T4);		//convergence set
		ArrayList<Pair> D = getTSeparatedTestPairs(T4);	//divergence set		
		ArrayList<Pair> temp_D = new ArrayList<Pair>();
		temp_D.addAll(D);
		
		ruler = new Ruler(C, D, T4);	
		for (Pair p : temp_D) {
			ruler.applyRules(p, AddedTo.D);
		}
		if(T4.size()<=0) return new ArrayList<String>();
		//System.out.println(D);
		//ArrayList<String> K = findK(T4, D);
		ArrayList<String> K = new ArrayList<String>();
			
		int n = fsm.getStates().size();
		while (K.size() < Math.min(p + 1, n)) // CONDITION 1
		{
			// -------STEP 2
			step02_v02(T4, T2, C, D, K);
			System.out.println("step2");			
		}
		
		//-------STEP  3 -------			
		CunionK = findCunionK(C, K);	
		print_set(CunionK,"CunionK\n");
		FsmCoverage coverage = new FsmCoverage(fsm);
		
		ArrayList<String> R = new ArrayList<String>();
		R.add("EPSILON");
					
		Pair p_fichi = findFiChi(T4, CunionK, K, D);
		while(p_fichi != null) {
			System.out.println(" fi - " + p_fichi);
			if (Pair.add(C, p_fichi)) {
				ruler.applyRules(p_fichi, AddedTo.C);
			}			
			CunionK = findCunionK(C, K);
			//print_set(CunionK,"CunionK\n");			
			p_fichi = findFiChi(T4, CunionK, K, D);
		}
		
		ArrayList<String> T0 = new ArrayList<String>();//final relevant set
		ArrayList<Pair> C0 = new ArrayList<Pair>();		//convergence set
		ArrayList<Pair> D0 = new ArrayList<Pair>();	//divergence set	
					
		T0.add("EPSILON");		
		ruler = new Ruler(C0, D0, T0);
		K = new ArrayList<String>();		
		
		while (K.size() < Math.min(p + 1, n)) // CONDITION 1
		{
			// -------STEP 2
			step02_v03(T0, T4, C0, D0, K);
			System.out.println("step2 new");			
		}
		
		ArrayList<Transition> uncov_list = coverage.getNonCoveredtransitions(CunionK);
		ArrayList<Transition> all_list = fsm.getTransitions();		
		ArrayList<Transition> cov_list = new ArrayList<Transition>();
		
		for(Transition t : all_list){
			if(!uncov_list.contains(t)){
				cov_list.add(t);
			}
		}
		System.out.println("Non_cov " + coverage.getNonCoveredtransitions(CunionK));
		System.out.println("Coverage "+ cov_list);
		for(Transition t : cov_list){
			State s = t.getIn();
			boolean cond = false;
			for (String alpha : CunionK) {				
				if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha) == s) {				
					String alphax = TestSequence.concat(alpha, t.getInput());						
					if(CunionK.contains(alphax)){	
						System.out.println("\nTESTY " + alphax);
						cond = step4_5(alphax,K,D0,C0,T0,T4);						
					}
				}
				if(cond){	
					System.out.println("Covered " + alpha + " / " + t.getInput());
					break;
				}
			}
			System.out.println("Transition " + t); 
		}
		
		Relative = new ArrayList<String>();		
		Relative.addAll(T0);
				
		return T0;
	}

	public boolean step4_7(String fi, ArrayList<String> K, 
			Map<String, ArrayList<String>> D4, Map<String, ArrayList<String>> C4,
			ArrayList<String> T, ArrayList<String> T4){
		
		String chi = findChi(K, fi);			
		ArrayList<String> new_rel = new ArrayList<String>();		
		
		int up = 0;
		for (String upsilon : TestSet.minus(K, chi)) {
			if (HashList.pair_hash_in(D4,upsilon, fi)) {				
				
				ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C4);
				ArrayList<String> Cfi = HashList.getPartition(fi, C4);
				if(Cfi.size() > 0 && Cupsilon.size() > 0){				
					for(String alpha : Cupsilon){
						boolean found = false;
						for(String beta : Cfi){	
							ArrayList<String> alpha_ext = getExtensionsFrom(T4, alpha);
							ArrayList<String> beta_ext = getExtensionsFrom(T4, beta);
							
							for (String gamma : getCommonSufix(alpha, beta, alpha_ext,
									beta_ext)) {						
								State sa = fsm.nextStateWithSequence(
										fsm.getInitialState(), alpha);
								State sb = fsm.nextStateWithSequence(
										fsm.getInitialState(), beta);
								if (fsm.separe(gamma, sa, sb)) {
									String seq1 = TestSequence.concat(alpha, gamma);
									String seq2 = TestSequence.concat(beta, gamma);
									if(T4.contains(seq1) && T4.contains(seq2)){
																	
										if(!new_rel.contains(seq1)){
											new_rel.add(seq1);
										}
										if(!new_rel.contains(seq2)){
											new_rel.add(seq2);
										}										
																			
										System.out.println("New relat " + fi + " : " + seq1 + " -> " 
												+ seq2 + " -gamma: " + gamma + " up: "+ upsilon);
										up++;
										found = true;
										break;
									}
								}
							}if(found) break;
						}if(found) break;
					}
				}
			}			
		}
		if(up >= TestSet.minus(K, chi).size()){
			
			for(String s: new_rel){
				TestSet.addAllPrefsOf(T, s);								
			}			
			TestSet.addAllPrefsOf(T, fi);
			
			return true;
		}		
		return false;
	}
	
	public boolean step4_6(String fi, ArrayList<String> K, Map<String, ArrayList<String>> D,
			Map<String, ArrayList<String>> C, Map<String, ArrayList<String>> C4,
			ArrayList<String> T, ArrayList<String> T4){
		
		String chi = findChi(K, fi);		
		int count = 0;
		ArrayList<String> new_rel = new ArrayList<String>();
		ArrayList<String> new_alpha = new ArrayList<String>();
		ArrayList<String> new_beta = new ArrayList<String>();
		
		int up = 0;
		for (String upsilon : TestSet.minus(K, chi)) {
			if (HashList.pair_hash_in(D,upsilon, fi)) {				
				up++;
			}			
		}
		if(up >= TestSet.minus(K, chi).size()){
			
			TestSet.addAllPrefsOf(T, fi);
			updateC2(T, C);
			updateD3(D, T, fi);
			Pair p_fi_chi = new Pair(fi, chi);			
			if (HashList.add_pair_hash(C, fi, chi)) {
				ruler.applyRules3(p_fi_chi, AddedTo.C); 
			}
			return true;
		}
		TestSet.addAllPrefsOf(T, fi);
		updateC2(T, C);
		updateD3(D, T, fi);
		new_rel.clear();
		
		for (String upsilon : TestSet.minus(K, chi)) {			
			ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C);
			ArrayList<String> Cfi = HashList.getPartition(fi, C);
			
			if(Cfi.size() > 0 && Cupsilon.size() > 0){				
				for(String alpha : Cupsilon){
					boolean found = false;
					for(String beta : Cfi){						
						ArrayList<String> alpha_ext = getExtensionsFrom(T4, alpha);
						ArrayList<String> beta_ext = getExtensionsFrom(T4, beta);
						
						for (String gamma : getCommonSufix(alpha, beta, alpha_ext,
								beta_ext)) {						
							State sa = fsm.nextStateWithSequence(
									fsm.getInitialState(), alpha);
							State sb = fsm.nextStateWithSequence(
									fsm.getInitialState(), beta);
							if (fsm.separe(gamma, sa, sb)) {
								String seq1 = TestSequence.concat(alpha, gamma);
								String seq2 = TestSequence.concat(beta, gamma);
								if(T4.contains(seq1) && T4.contains(seq2)){
																
									if(!new_rel.contains(seq1)){
										new_rel.add(seq1);
									}
									if(!new_rel.contains(seq2)){
										new_rel.add(seq2);
									}
									new_alpha.add(alpha);
									new_beta.add(beta);
																		
									System.out.println("New relat " + fi + " : " + seq1 + " -> " 
											+ seq2 + " -gamma: " + gamma + " up: "+ upsilon);
									count++;
									found = true;
									break;
								}
							}
						}											
						if(found) break;
					}if(found) break;						
				}			
			}			
		}
		if(count >= TestSet.minus(K, chi).size()){
			System.out.println("upsilon: " + count + " : " + TestSet.minus(K, chi).size() + " -> " + chi);
				
			for(String s: new_rel){
				TestSet.addAllPrefsOf(T, s);								
			}
			updateC2(T, C);
			updateD3(D, T, fi);
			
			for(int i=0;i<new_alpha.size();i++){
				Pair p_alphabeta = new Pair(new_alpha.get(i), new_beta.get(i));				
				if (HashList.add_pair_hash(D, new_alpha.get(i), new_beta.get(i))) {
					ruler.applyRules3(p_alphabeta, AddedTo.D); 
				}
			}
		
			Pair p_fi_chi = new Pair(fi, chi);
			if (HashList.add_pair_hash(C, p_fi_chi.getLeft(), p_fi_chi.getRight())) {
				ruler.applyRules3(p_fi_chi, AddedTo.C); 
			}
			
			return true;
		}
		return false;
	}
	
	public void updateD3(Map<String, ArrayList<String>> D, ArrayList<String> T, String alphax) {
		for (String alpha : TestSequence.getAllPrefixesFrom(alphax)) {
			for (String test : T) {
				if (!alpha.equals(test)) {
					// common extensions
					ArrayList<String> alpha_ext = getExtensionsFrom(T, alpha);
					ArrayList<String> beta_ext = getExtensionsFrom(T, test);					
					for (String gamma : getCommonSufix(alpha, test, alpha_ext,
							beta_ext)) {						
						State sa = fsm.nextStateWithSequence(
								fsm.getInitialState(), alpha);
						State sb = fsm.nextStateWithSequence(
								fsm.getInitialState(), test);
						if (fsm.separe(gamma, sa, sb)) {
							Pair p = new Pair(alpha, test);
							// System.out.println(p);
							//if (Pair.add(D, p)) {
							if(HashList.add_pair_hash(D, alpha, test)){
								ruler.applyRules3(p, AddedTo.D);
							}
							//break;
						}
					}
				}
			}
		}
	}
	
	public boolean step4_5(String fi, ArrayList<String> K, ArrayList<Pair> D,
			ArrayList<Pair> C, ArrayList<String> T, ArrayList<String> T4){
		
		String chi = findChi(K, fi);		
		int count = 0;
		ArrayList<String> new_rel = new ArrayList<String>();
		ArrayList<String> new_alpha = new ArrayList<String>();
		ArrayList<String> new_beta = new ArrayList<String>();
		int up = 0;
		for (String upsilon : TestSet.minus(K, chi)) {
			if (Pair.in(new Pair(upsilon, fi), D)) {
				up++;
			}
		}
		if(up >= TestSet.minus(K, chi).size()){			
			Pair p_fi_chi = new Pair(fi, chi);
			if (Pair.add(C, p_fi_chi)) {
				ruler.applyRules(p_fi_chi, AddedTo.C);
			}			
			return true;
		}
		TestSet.addAllPrefsOf(T, fi);
		updateC(T, C);
		updateD(D, T, fi);
		
		for (String upsilon : TestSet.minus(K, chi)) {
						
			ArrayList<String> Cupsilon = Pair.getPartition(upsilon, C);
			ArrayList<String> Cfi = Pair.getPartition(fi, C);
			
			if(Cfi.size() > 0 && Cupsilon.size() > 0){
				//String alpha = Cupsilon.get(0);
				//String beta = Cfi.get(0);
				for(String alpha : Cupsilon){
					boolean found = false;
					for(String beta : Cfi){
						ArrayList<String> alpha_ext = getExtensionsFrom(T4, alpha);
						ArrayList<String> beta_ext = getExtensionsFrom(T4, beta);
						
						for (String gamma : getCommonSufix(alpha, beta, alpha_ext,
								beta_ext)) {						
							State sa = fsm.nextStateWithSequence(
									fsm.getInitialState(), alpha);
							State sb = fsm.nextStateWithSequence(
									fsm.getInitialState(), beta);
							if (fsm.separe(gamma, sa, sb)) {							
								String seq1 = TestSequence.concat(alpha, gamma);
								String seq2 = TestSequence.concat(beta, gamma);
								if(T4.contains(seq1) && T4.contains(seq2)){
																
									if(!new_rel.contains(seq1)){
										new_rel.add(seq1);
									}
									if(!new_rel.contains(seq2)){
										new_rel.add(seq2);
									}	
									new_alpha.add(alpha);
									new_beta.add(beta);
									
									System.out.println("New relat " + fi + " : " + seq1 + " -> " 
											+ seq2 + " -gamma: " + gamma + " up: "+ upsilon);
									count++;
									found = true;
									break;
								}
							}
						}
						if(found) break;
					}if(found) break;						
				}										
			}
			
		}
		if(count >= TestSet.minus(K, chi).size()){
			System.out.println("upsilon: " + count + " : " + TestSet.minus(K, chi).size() + " -> " + chi);
				
			for(String s: new_rel){
				TestSet.addAllPrefsOf(T, s);								
			}
			updateC(T, C);

			for(int i=0;i<new_alpha.size();i++){
				Pair p_alphabeta = new Pair(new_alpha.get(i), new_beta.get(i));
				if (Pair.add(D, p_alphabeta)) {
					ruler.applyRules(p_alphabeta, AddedTo.D);
				}
			}
			
			Pair p_fi_chi = new Pair(fi, chi);
			if (Pair.add(C, p_fi_chi)) {
				ruler.applyRules(p_fi_chi, AddedTo.C);
			}
			
			return true;
		}
		return false;
	}
		
	/*
	public ArrayList<Triple> getTSeparatedTestPairs2(ArrayList<String> T) {
		ArrayList<Triple> ret = new ArrayList<Triple>();
		
		for (String alpha : T) {
			for (String beta : T) {
				if (!alpha.equals(beta)) {
					// common extensions
					ArrayList<String> alpha_ext = getExtensionsFrom(T, alpha);
					ArrayList<String> beta_ext = getExtensionsFrom(T, beta);

					for (String gamma : getCommonSufix(alpha, beta, alpha_ext,
							beta_ext)) {
						State sa = fsm.nextStateWithSequence(
								fsm.getInitialState(), alpha);
						State sb = fsm.nextStateWithSequence(
								fsm.getInitialState(), beta);
						if (fsm.separe(gamma, sa, sb)) {
							Triple.add(ret, new Triple(alpha, gamma, beta));							
							break;
						}
					}
				}
			}
		}

		return ret;
	}
	*/
	
	public void step02_v03(ArrayList<String> T, ArrayList<String> T4, ArrayList<Pair> C,
			ArrayList<Pair> D, ArrayList<String> K) {
				
		String alpha = selectAlpha(K);
		for (String beta : K) {		
			if (!Pair.in(new Pair(alpha, beta), D)) {
				CostTuple tuple = selectGamma(alpha, beta, T, C);
				String gamma = tuple.getGamma();
				alpha = tuple.getAlpha();
				beta = tuple.getBeta();
				
				String seq1 = TestSequence.concat(alpha, gamma);
				String seq2 = TestSequence.concat(beta, gamma);
								
				TestSet.addAllPrefsOf(T, seq1);
				TestSet.addAllPrefsOf(T, seq2);
			
				updateC(T, C);
				Pair p_alphabeta = new Pair(alpha, beta);
				if (Pair.add(D, p_alphabeta)) {
					ruler.applyRules(p_alphabeta, AddedTo.D); 
				}
								
			}
		}		
		K.add(alpha);
	}
	
	public void step02_v02(ArrayList<String> T, ArrayList<String> T2, ArrayList<Pair> C,
			ArrayList<Pair> D, ArrayList<String> K) {
		
		String alpha = selectAlpha(K);		
		for (String beta : K) {
			// if(isDivergent(alpha, beta) && ! Pair.in(new Pair(alpha, beta),
			// D) )
			if (!Pair.in(new Pair(alpha, beta), D)) {
				CostTuple tuple = selectGamma(alpha, beta, T, C);
				String gamma = tuple.getGamma();
				alpha = tuple.getAlpha();
				beta = tuple.getBeta();
				
				Pair p_alphabeta = new Pair(alpha, beta);
				if (Pair.add(D, p_alphabeta)) {
					ruler.applyRules(p_alphabeta, AddedTo.D); 
				}
			}
		}
		K.add(alpha);
	}
	
	public Pair findFiChi2(ArrayList<String> T,
			ArrayList<String> K, ArrayList<Pair> D) {		
		for (String fi : T) {
			//System.out.println("FINDfi "+fi);		
			if(fi.equals("EPSILON")){
				continue;
			}
			for (String chi : K) {
				//System.out.println("chi "+chi);
				boolean in = true;				
				for (String upsilon : TestSet.minus(K, chi)) {
					//System.out.println("upsilon "+upsilon);
					if (!Pair.in(new Pair(fi, upsilon), D)) {
						in = false;
						break;
					}
				}
				if (in && isConvergent(fi, chi))
					return new Pair(fi, chi);
			}
		}
		return null;
	}
	
	public Pair step04_v2(String fi, ArrayList<String> K, ArrayList<Pair> D,
			ArrayList<Pair> C, ArrayList<String> T, ArrayList<String> T2) {
		
		String chi = findChi(K, fi);
		for (String upsilon : TestSet.minus(K, chi)) {
			if (!Pair.in(new Pair(upsilon, fi), D)) // change chi by fi
			{
				ArrayList<String> Cupsilon = Pair.getPartition(upsilon, C);
				ArrayList<String> Cfi = Pair.getPartition(fi, C); // change chi
												
				String alpha = Cupsilon.get(0);
				String beta = Cfi.get(0);
				
				CostTuple tuple = selectGamma(alpha, beta, T, C);
				String gamma = tuple.getGamma();
				alpha = tuple.getAlpha();
				beta = tuple.getBeta();

				if (gamma != null) {
					String seq1 = TestSequence.concat(alpha, gamma);
					String seq2 = TestSequence.concat(beta, gamma);

					boolean found_T2 = false;
					for(String t2 : T2){
						if(TestSequence.isPrefixOf(seq1, t2)){
							TestSet.addAllPrefsOf(T, t2);
							if(!Relative.contains(t2)){
								Relative.add(t2);								
							}
							System.out.println("step4-0 " + seq1 + "//"+ gamma +"\n 	-> "+ t2);
							found_T2 = true;
							//break;
						}
					}
					if(!found_T2){
						TestSet.addAllPrefsOf(T, seq1);
					}
					
					found_T2 = false;
					for(String t2 : T2){
						if(TestSequence.isPrefixOf(seq2, t2)){
							TestSet.addAllPrefsOf(T, t2);
							if(!Relative.contains(t2)){
								Relative.add(t2);								
							}
							System.out.println("step4-1 " + seq2 + "//"+ gamma +"\n 	-> "+ t2);
							found_T2 = true;
							//break;
						}
					}
					if(!found_T2){
						TestSet.addAllPrefsOf(T, seq2);
					}
					
					//TestSet.addAllPrefsOf(T0, seq1);
					//TestSet.addAllPrefsOf(T0, seq2);

					updateC(T, C);

					Pair p_alphabeta = new Pair(alpha, beta);
					if (Pair.add(D, p_alphabeta)) {
						ruler.applyRules(p_alphabeta, AddedTo.D);
					}
				}
			}
		}
		return new Pair(fi, chi);
	}
	
	private String step5_v2(FsmCoverage coverage, ArrayList<String> T0,
			ArrayList<Pair> C, ArrayList<Pair> D,
			ArrayList<String> T2, ArrayList<String> T4){
		
		Transition transition = selectTransition(CunionK, coverage, T0);
		State s = transition.getIn();	
		boolean found_alpha_T4 = false;
		for (String alpha : T4) {
			if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha) == s) {
				found_alpha_T4 = true;
				String alphax = TestSequence.concat(alpha,
						transition.getInput());
				boolean found_alphax_T2 = false;
				for(String t2 : T2){
					
					String t2_alpha = TestSequence.getPrefixFrom(t2, transition.getInput());
					if(isDivergent(alpha,t2_alpha) && isConvergent(alphax,t2)){
						
						String a[] = alpha.split(",");
						String b[] = t2.split(",");
						if(b.length >= a.length && a[0].equals(b[0])){
							TestSet.addAllPrefsOf(T0, t2);
							if(!Relative.contains(t2)){
								Relative.add(t2);
							}
							System.out.println("step5 " + alphax + " //" +alpha+"\n -> "+ t2);
							found_alphax_T2 = true;
							break;
						}
					}	
					/*	
					if(TestSequence.isPrefixOf(alphax, t2)){
						
						TestSet.addAllPrefsOf(T0, t2);
						if(!Relative.contains(t2)){
							Relative.add(t2);
						}
						System.out.println("step5 " + alphax + " //" +alpha+"\n -> "+ t2);
						found_alphax_T2 = true;
						//break;
					}
					*/
					if(alphax.equals(t2)){
						TestSet.addAllPrefsOf(T0, t2);
						if(!Relative.contains(t2)){
							Relative.add(t2);
						}
						System.out.println("step5 " + alphax + " //" +alpha+"\n -> "+ t2);
						found_alphax_T2 = true;
					}
				}
				if(!found_alphax_T2){
					TestSet.addAllPrefsOf(T0, alphax);
				}					

				updateC(T0, C);				
				updateD(D, T0, alphax);				
				return alphax;	
			}
		}
	/*		
		if(!found_alpha_T4){
			for (String alpha : CunionK) {
				if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha) == s) {
					
					String alphax = TestSequence.concat(alpha,
							transition.getInput());
					TestSet.addAllPrefsOf(T0, alphax);
					
					updateC(T0, C);				
					updateD(D, T0, alphax);	
					return alphax;					
				}
			}
		}
		*/
		return "";		
	}
	
	
	
	public String get_relevant(ArrayList<String> T, ArrayList<String> K_old){
		
		ArrayList<String> T3 = new ArrayList<String>(); //test suite for All_pref of each T input test case		
		ArrayList<String> DD = new ArrayList<String>(); //test cases from T input that is convergent-conserving
		ArrayList<String> T2 = new ArrayList<String>(); //test cases from T input without prefixes
		for (String s : initialTestSet){
			T2.add(s);
		}			
			
		ArrayList<String> T4 = new ArrayList<String>();//all test cases from T input with all prefixes
		for (String typ : T2) {
			TestSet.addAllPrefsOf(T4, typ);
		}
		
		//System.out.println("T4 ---\n" + T4 + "----\n");
		
		ArrayList<Pair> C4 = getIdentityRelation(T4);		//convergence set
		ArrayList<Pair> temp_D = getTSeparatedTestPairs(T4);	//divergence set
						
		ruler = new Ruler(C4, temp_D, T4);		
		// apply rules 1.3
		for (Pair p : temp_D) {
			ruler.applyRules(p, AddedTo.D);
		}
		
		//ArrayList<String> K = findK(T, temp_D);	
		ArrayList<String> K = K_old;	
	/*	
		int n = fsm.getStates().size();
		while (K.size() < Math.min(p + 1, n)) // CONDITION 1
		{
			// -------STEP 2
			step02(T, C4, temp_D, K);
			System.out.println("step2");			
		}
	*/	
		CunionK = findCunionK(C4, K);					//test cases from T that is convergent-conserving
		
		print_set(CunionK,"CunionK\n");	
						
		for(int i=0;i<T2.size();i++){
			T3.clear();
			TestSet.addAllPrefsOf(T3, T2.get(i));
			
			Pair p_fichi = findFiChi(T3, CunionK, K, temp_D);	//from each isolated test cases from T input...
			
			//System.out.println("\nT3 ---" + T3);
			//System.out.println("CunionK ---" + CunionK);
			//System.out.println("Minus ---" +TestSet.minus(T3, CunionK));
			while(p_fichi != null) {
				step03(C4, temp_D, p_fichi);	
				//Pair.add(C4, p_fichi);
							
				if(!DD.contains(T2.get(i))){
					DD.add(T2.get(i));
				}				
				System.out.println("Fi ---" + p_fichi.getLeft());
				
				CunionK = findCunionK(C4, K);
				p_fichi = findFiChi(T3, CunionK, K, temp_D);
			}
			
		}
		
		
		print_set(DD,"\nSet esperado\n");
		
		print_set(CunionK,"CunionK\n");	
		
	/*	
		String fi = step05(CunionK, T, C, D);
		//String fi = step05_2(CunionK, T, C, D, T2);
		Pair p_fichi2 = step04(fi, K, D, C, T);
		step03(C, D, p_fichi2);
		
		
		FsmCoverage coverage = new FsmCoverage(fsm);	
		Transition transition = selectTransition(CunionK, coverage, T);
		State s = transition.getIn();		
		for (String alpha : T4) {
			if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha) == s) {
				
				String alphax = TestSequence.concat(alpha,
						transition.getInput());
				TestSet.addAllPrefsOf(T, alphax);

				updateC(T, C);				
				updateD(D, T, alphax);
				
				return alphax;
			}
		}
	*/	
		
		
		
		//System.out.println("T-separated");
		//for(int i=0;i<temp_D.size();i++){
		//	System.out.println(temp_D.get(i).getLeft() + " -> " + temp_D.get(i).getRight());			
		//}
		
		
		boolean found = false;
		ArrayList<String> CuK = TestSequence.getNoPrefixes(CunionK);
		ArrayList<String> equal = new ArrayList<String>();
		ArrayList<String> diff = new ArrayList<String>();
		ArrayList<Pair> prefix = new ArrayList<Pair>();
		ArrayList<Pair> sufix = new ArrayList<Pair>();
				
		for(String tc : CuK){
			for(String ti : T2){
				if(ti.equals(tc)){
					found = true;
					equal.add(tc);
					break;
				}
				if(TestSequence.isPrefixOf(tc, ti)){
					found = true;
					Pair o = new Pair(tc, ti);
					prefix.add(o);
					break;
				}
				if(TestSequence.isPrefixOf(ti, tc)){
					found = true;
					Pair o = new Pair(tc, ti);
					sufix.add(o);
					break;
				}
			}
			if(!found){
				//System.out.println(line2);
				diff.add(tc);
			}
			found = false;
		}
		
		ArrayList<String> equiv = new ArrayList<String>();
				
		System.out.println("Diff-----file2 - file1");
		for(int i=0;i<diff.size();i++){
			System.out.println(diff.get(i));
		}
		System.out.println("Equal-----");
		for(int i=0;i<equal.size();i++){
			System.out.println(equal.get(i));
			if(!equiv.contains(equal.get(i))){
				equiv.add(equal.get(i));
			}
		}
		System.out.println("Prefix-----file2 -> file1");
		for(int i=0;i<prefix.size();i++){
			System.out.println(prefix.get(i).getLeft() + " -> " + prefix.get(i).getRight());
			if(!equiv.contains(prefix.get(i).getRight())){
				equiv.add(prefix.get(i).getRight());
			}
			//diff.add(prefix.get(i).getRight());
		}
		System.out.println("Sufix-----file2 -> file1");
		for(int i=0;i<sufix.size();i++){
			System.out.println(sufix.get(i).getLeft() + " -> " + sufix.get(i).getRight());
			diff.add(sufix.get(i).getLeft());
			//if(T2.contains(sufix.get(i).getRight())){
			//	if(!equiv.contains(sufix.get(i).getRight())){
			//		equiv.add(sufix.get(i).getRight());
			//	}
			//}
		}
					
		equiv = get_a_b_y(equiv, diff, T2, false);
	/*	
		ArrayList<String> aux = new ArrayList<String>();
		int size = 0;
		for(int i=0;i<prefix.size();i++){			
			aux.clear();			
			aux.add(prefix.get(i).getRight());
			size = equiv.size();			
			equiv = get_a_b_y(equiv, aux, T2);			
			if(size == equiv.size()){
				if(!equiv.contains(prefix.get(i).getRight())){
					equiv.add(prefix.get(i).getRight());
				}
			}
		}
	*/	
		
		String result = "";		
		result = merge(equiv,DD);		
		System.out.println("Test case FINAL\n" + result);
		
		
		FsmCoverage coverage = new FsmCoverage(fsm);
		ArrayList<Transition> tr_no1 = coverage.getNonCoveredtransitions(CunionK);
		int total = fsm.getNumberOfTransitions();
		System.out.println("total "+ total+ " non-covered1: "+ tr_no1.size());
			
		return result;
		
	}
	
	private ArrayList<String> get_a_b_y(ArrayList<String> equiv,
			ArrayList<String> diff, ArrayList<String> T2, boolean is_sufix){
		
		ArrayList<String> prefix_diff = new ArrayList<String>();
		ArrayList<String> prefix_T2 = new ArrayList<String>();		
		
		String test_equiv = "";		
		int max_gamma = 0;				
		int max_prefix_alpha = 0;
		
		for(String alpha : diff){						
			prefix_diff.clear();
			TestSet.addAllPrefsOf(prefix_diff, alpha);					
			max_gamma = 0;			
			max_prefix_alpha = 0;
			test_equiv = "";
			for(String beta : T2){								
				prefix_T2.clear();
				TestSet.addAllPrefsOf(prefix_T2, beta);				
				for(String d_pre : prefix_diff){					
					String suf_d = TestSequence.getSuffixFrom(alpha, d_pre);
						for(String t_pre : prefix_T2){
							String suf_t = TestSequence.getSuffixFrom(beta, t_pre);
							//System.out.println("suf_t " +suf_t);
							if(!suf_d.equals("EPSILON") && suf_d.equals(suf_t)){
								int gamma = suf_d.split(",").length;
								
								State si = fsm.nextStateWithSequence(fsm.getInitialState(), d_pre);
								State sj = fsm.nextStateWithSequence(fsm.getInitialState(), t_pre);
								if(si.equals(sj)){
									String a[] = d_pre.split(",");
									String b[] = t_pre.split(",");	
									//if((!t_pre.equals("EPSILON") && TestSequence.isProperPrefixOf(t_pre, d_pre))
									//		|| (!d_pre.equals("EPSILON") && TestSequence.isProperPrefixOf(d_pre, t_pre))){										
									if((!t_pre.equals("EPSILON") && (!d_pre.equals("EPSILON")))){	
										int prefix_alpha=0;
										while(a[prefix_alpha].equals(b[prefix_alpha])){											
											prefix_alpha++;
											if(prefix_alpha>=a.length || prefix_alpha>=b.length){
												break;
											}
										}
										//System.out.println("Test case sufix ! " +alpha+ " Equiv "+beta);
										//if(gamma >= max_gamma && prefix_alpha >= max_prefix_alpha){
										if(gamma >= max_gamma && prefix_alpha > 0 && b.length >= max_prefix_alpha){
											max_gamma = gamma;
											max_prefix_alpha = b.length;
											test_equiv = beta;
											System.out.println("Test case ??? " +alpha+ " Equiv "+beta);
										}
									}									
								}
							}
						}
				}							
			}			
			if(!equiv.contains(test_equiv) && !test_equiv.equals("")){
				System.out.println("Test case IN  " +alpha+ " Equiv "+test_equiv);
				equiv.add(test_equiv);												
			}else{
				System.out.println("Test case OUT " +alpha+ " Equiv "+test_equiv);
			}
		}
		return equiv;
		
	}
		
	private static String merge(ArrayList<String> set1, ArrayList<String> set2)	{			
		boolean found = false;
		String out = "";
								
		for(String tc : set2){
			for(String ti : set1){				
				if(ti.equals(tc) || (TestSequence.isPrefixOf(tc, ti))){
					found = true;
					break;
				}
			}
			if(!found){
				out = out.concat(tc + "\n");
			}
			found = false;
		}
		
		found = false;
		
		for(String tc : set1){
			for(String ti : set2){				
				if(TestSequence.isProperPrefixOf(tc, ti)){
					found = true;
					break;				
				}
			}
			if(!found){				
				out = out.concat(tc + "\n");
			}
			found = false;
		}		
		return out;
	}
	
	public void generate_old() {
		logger.info("W: " + W);

		logger.info("p: " + p);
		int n = fsm.getStates().size();
		logger.info("Initial T: " + initialTestSet);

		ArrayList<String> T = new ArrayList<String>();
		for (String s : initialTestSet)
			T.add(s);

		/*----------------------------------------------------------------------------*/
		// -------STEP 1
		logger.info("------------------------------");
		logger.info("STEP 1");
		ArrayList<Pair> C = getIdentityRelation(T);
		ArrayList<Pair> temp_D = getTSeparatedTestPairs(T);
		ArrayList<Pair> D = getTSeparatedTestPairs(T);
		ruler = new Ruler(C, D, T);
					
		//print_T(C);
		//print_T(D);
		
		//%%%%%%%%%%%%%%%%%%%%%%%%
		ArrayList<String> DD = new ArrayList<String>();
		//%%%%%%%%%%%%%%%%%%%%%%%%
		
		// apply rules 1.3
		for (Pair p : temp_D) {
			ruler.applyRules(p, AddedTo.D);
		}
		ArrayList<String> K = findK(T, D);
		logger.info("T1: " + T);
		logger.info("C1: " + C);
		logger.info("D1: " + D);
		logger.info("K1: " + K);

		// -------STEP 1
		/*----------------------------------------------------------------------------*/
		while (K.size() < Math.min(p + 1, n)) // CONDITION 1
		{
			// -------STEP 2
			step02(T, C, D, K);
			System.out.println("step2");
		}
		if (K.size() >= (p + 1)) // CONDITION 2
		{
			// System.out.println("T: " + T);
			finalTestSet = T;
		} else {
			// CONDITION 3
			CunionK = findCunionK(C, K);
			logger.info("C union K2: " + CunionK);

			FsmCoverage coverage = new FsmCoverage(fsm);
			while (!coverage.isInitializedTransitionCoverage(CunionK)) {
				// CONDITION 4
				Pair p_fichi = findFiChi(T, CunionK, K, D);
				
				if (p_fichi != null) // C4 YES
				{
					step03(C, D, p_fichi);
					
					//%%%%%%%%%%%%%%%%%%%%%%%%
					set_pair(DD, p_fichi);
					//%%%%%%%%%%%%%%%%%%%%%%%%
					
				} else // C4 NO
				{
					// CONDITION 5
					if (!CunionK.contains("EPSILON")) // C5 NO
					{
						// step 4 fi = epsilon
						Pair p_fichi2 = step04("EPSILON", K, D, C, T);
						step03(C, D, p_fichi2);						
					} else // C5 YES
					{
						String fi = step05(CunionK, T, C, D);						
						Pair p_fichi2 = step04(fi, K, D, C, T);
						step03(C, D, p_fichi2);						
					}
				}

				CunionK = findCunionK(C, K);
				// System.out.println("C union K: " + CunionK);
				// System.out.println("fi: " + p_fichi);

				// System.out.println("D: " + TestSequence.getNoPrefixes(DD));
				System.out.println("coverage: "
						+ coverage.transitionCoverage(CunionK));
				// System.out.println("trans: " +
				// coverage.getCoveredtransitions(CunionK));
			}

			finalTestSet = T;
			//print_set(DD + "\n----");
		}

		// System.out.println();
		// System.out.println("Final Test Set: " +
		// TestSequence.getNoPrefixes(finalTestSet));
	}

	private void print_set(ArrayList<String> DD, String a) {		
		
		DD = TestSequence.getNoPrefixes(DD);
		System.out.println("Set "+a+"----\n");
		for (int i = 0; i < DD.size(); i++) {
			System.out.println(DD.get(i));
		}
		System.out.println("----\n");
	}
	
	private String print_T(ArrayList<Pair> D, String a, boolean show_dif){
		ArrayList<String> OUT = new ArrayList<String>();
		ArrayList<String> OUT_r = new ArrayList<String>();
		//System.out.println("Set pairs "+a+"----\n");
		for(int i=0;i<D.size();i++){
			Pair DT = D.get(i);
			if(show_dif){
				if(!DT.getLeft().equals(DT.getRight())){
					if(!OUT.contains(DT.getLeft())){
						OUT.add(DT.getLeft());				
					}
					if(!OUT.contains(DT.getRight())){				
						OUT.add(DT.getRight());
					}
				}
			}else{
				if(!OUT.contains(DT.getLeft())){
					OUT.add(DT.getLeft());				
				}
				if(!OUT.contains(DT.getRight())){				
					OUT.add(DT.getRight());
				}
			}
			//System.out.println(DT.getLeft()+"<-->"+DT.getRight());
			
		}
		System.out.println("Set "+a+"----\n");
		OUT_r = TestSequence.getNoPrefixes(OUT);
		for (int i = 0; i < OUT_r.size(); i++) {
			System.out.println(OUT_r.get(i));
		}
		System.out.println("----\n");
		return a+OUT_r.get(0);
	}
	
	private ArrayList<String> set_pair(ArrayList<String> L, Pair p) {		
		ArrayList<String> DD = L;
		if (!DD.contains(p.getLeft())) {
			DD.add(p.getLeft());
		}
		if (!DD.contains(p.getRight())) {
			DD.add(p.getRight());
		}
		return DD;
	}
	
	private String step05_2(ArrayList<String> CunionK, ArrayList<String> T,
			ArrayList<Pair> C, ArrayList<Pair> D, ArrayList<String> T2) {
		logger.info("------------------------------");
		logger.info("STEP 5");

		FsmCoverage coverage = new FsmCoverage(fsm);
		logger.info("CunionK:  " + CunionK);
		logger.info(":  " + coverage.getNonCoveredtransitions(CunionK));

		// select the transition
		Transition transition = selectTransition(CunionK, coverage, T);
		State s = transition.getIn();
		
		
		
		
		
		for (String alpha : CunionK) {
			if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha) == s) {
				logger.info("selected transition: " + transition);
				logger.info("alpha: " + alpha);
				
				for (String alpha2 : T2) {
					if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha2) == s) {
						String alphax2 = TestSequence.concat(alpha2,transition.getInput());
						if(alphax2.equals(alpha2)){
							System.out.println("LOOOOOL "+ alphax2);
						}
						//if(TestSequence.isPrefixOf(alphax, alpha2)){ //get first prefix
							//alpha = alpha2;
							//System.out.println("LOOOOOL "+ alpha2);
							//break;
						//}
					}
				}
				
				
				String alphax = TestSequence.concat(alpha,
						transition.getInput());
								
				TestSet.addAllPrefsOf(T, alphax);

				// update C, adding new (alpha, alpha)'s
				updateC(T, C);

				// D
				updateD(D, T, alphax);

				logger.info("T5: " + T);
				logger.info("C5: " + C);
				logger.info("D5: " + D);
				logger.info("alpha = " + alpha + "; x = "
						+ transition.getInput());
				return alphax;
			}
		}

		return null;
	}

	private String step05(ArrayList<String> CunionK, ArrayList<String> T,
			ArrayList<Pair> C, ArrayList<Pair> D) {
		logger.info("------------------------------");
		logger.info("STEP 5");

		FsmCoverage coverage = new FsmCoverage(fsm);
		logger.info("CunionK:  " + CunionK);
		logger.info(":  " + coverage.getNonCoveredtransitions(CunionK));

		// select the transition
		Transition transition = selectTransition(CunionK, coverage, T);
		State s = transition.getIn();		
		for (String alpha : CunionK) {
			if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha) == s) {
				logger.info("selected transition: " + transition);
				logger.info("alpha: " + alpha);
				String alphax = TestSequence.concat(alpha,
						transition.getInput());
				TestSet.addAllPrefsOf(T, alphax);

				// update C, adding new (alpha, alpha)'s
				updateC(T, C);

				// D
				updateD(D, T, alphax);

				logger.info("T5: " + T);
				logger.info("C5: " + C);
				logger.info("D5: " + D);
				logger.info("alpha = " + alpha + "; x = "
						+ transition.getInput());
				return alphax;
			}
		}

		return null;
	}

	private Transition selectTransition(ArrayList<String> CunionK,
			FsmCoverage coverage, ArrayList<String> T) {
		Transition transition = coverage.getNonCoveredtransitions(CunionK).get(
				0);
		return transition;

		/*
		 * 
		 * there is no big change here
		 * 
		 * ArrayList<Transition> uncoverTransitions =
		 * coverage.getNonCoveredtransitions(CunionK); ArrayList<Transition>
		 * coveredByT = coverage.getCoveredtransitions(T);
		 * 
		 * for(Transition transition : uncoverTransitions) { if(!
		 * coveredByT.contains(transition)) //it is not covered by CuK but it is
		 * covered by T { return transition; } } return
		 * uncoverTransitions.get(0);
		 */
	}

	public void updateD(ArrayList<Pair> D, ArrayList<String> T, String alphax) {
		for (String alpha : TestSequence.getAllPrefixesFrom(alphax)) {
			for (String test : T) {
				if (!alpha.equals(test)) {
					// common extensions
					ArrayList<String> alpha_ext = getExtensionsFrom(T, alpha);
					ArrayList<String> beta_ext = getExtensionsFrom(T, test);
					// System.out.println("test: " + test);
					// System.out.println(alpha_ext);
					// System.out.println(beta_ext);
					for (String gamma : getCommonSufix(alpha, test, alpha_ext,
							beta_ext)) {
						// System.out.println("gamma: " + gamma);
						State sa = fsm.nextStateWithSequence(
								fsm.getInitialState(), alpha);
						State sb = fsm.nextStateWithSequence(
								fsm.getInitialState(), test);
						if (fsm.separe(gamma, sa, sb)) {
							Pair p = new Pair(alpha, test);
							// System.out.println(p);
							if (Pair.add(D, p)) {
								ruler.applyRules(p, AddedTo.D);
							}
							break;
						}
					}
				}
			}
		}
	}

	public Pair step04(String fi, ArrayList<String> K, ArrayList<Pair> D,
			ArrayList<Pair> C, ArrayList<String> T) {
		logger.info("------------------------------");
		logger.info("STEP 4");

		String chi = findChi(K, fi);

		logger.info("ST04 - fi: " + fi);
		logger.info("ST04 - chi: " + chi);

		for (String upsilon : TestSet.minus(K, chi)) {
			if (!Pair.in(new Pair(upsilon, fi), D)) // change chi by fi
			{
				ArrayList<String> Cupsilon = Pair.getPartition(upsilon, C);
				ArrayList<String> Cfi = Pair.getPartition(fi, C); // change chi
																	// by fi
				logger.info("Cupsilon: " + Cupsilon);
				logger.info("Cfi:     " + Cfi);

				String alpha = Cupsilon.get(0);
				String beta = Cfi.get(0);

				CostTuple tuple = selectGamma(alpha, beta, T, C);
				String gamma = tuple.getGamma();
				alpha = tuple.getAlpha();
				beta = tuple.getBeta();

				logger.info("alpha: " + alpha);
				logger.info("beta: " + beta);
				logger.info("gamma: " + gamma);

				if (gamma != null) {
					String seq1 = TestSequence.concat(alpha, gamma);
					String seq2 = TestSequence.concat(beta, gamma);

					TestSet.addAllPrefsOf(T, seq1);
					TestSet.addAllPrefsOf(T, seq2);

					// update C, adding new (alpha, alpha)'s
					updateC(T, C);

					// update D applying rules

					Pair p_alphabeta = new Pair(alpha, beta);
					if (Pair.add(D, p_alphabeta)) {
						ruler.applyRules(p_alphabeta, AddedTo.D); // update D
																	// applying
																	// rules
					}
				}
			}
		}

		logger.info("T4: " + T);
		logger.info("C4: " + C);
		logger.info("D4: " + D);
		logger.info("K4: " + K);
		logger.info("fi = " + fi + "; chi = " + chi);

		return new Pair(fi, chi);
	}

	public String findChi(ArrayList<String> K, String fi) {
		for (String chi : K)
			if (isConvergent(fi, chi))
				return chi;

		return null;
	}

	public Pair findFiChi(ArrayList<String> T, ArrayList<String> CunionK,
			ArrayList<String> K, ArrayList<Pair> D) {
		
		for (String fi : TestSet.minus(T, CunionK)) {
			//System.out.println("FINDfi "+fi);			
			for (String chi : K) {
				//System.out.println("chi "+chi);
				boolean in = true;				
				for (String upsilon : TestSet.minus(K, chi)) {
					//System.out.println("upsilon "+upsilon);
					if (!Pair.in(new Pair(fi, upsilon), D)) {
						in = false;
						break;
					}
				}

				if (in && isConvergent(fi, chi))
					return new Pair(fi, chi);
			}
		}

		return null;
	}

	public void step03(ArrayList<Pair> C, ArrayList<Pair> D, Pair pair) {
		logger.info("------------------------------");
		logger.info("STEP 3");
		logger.info("fi = " + pair.getLeft() + "; chi = " + pair.getRight());

		if (Pair.add(C, pair)) {
			ruler.applyRules(pair, AddedTo.C);
		}

		logger.info("C3: " + C);
		logger.info("D3: " + D);
	}

	public ArrayList<String> findCunionK(ArrayList<Pair> C, ArrayList<String> K) {
		ArrayList<String> ret = new ArrayList<String>();
		for (Pair pair : C) {
			String alpha = pair.getLeft();
			String beta = pair.getRight();

			if (K.contains(alpha) && !ret.contains(beta))
				ret.add(beta);

			alpha = pair.getRight();
			beta = pair.getLeft();

			if (K.contains(alpha) && !ret.contains(beta))
				ret.add(beta);
		}

		return ret;
	}

	public void step02(ArrayList<String> T, ArrayList<Pair> C,
			ArrayList<Pair> D, ArrayList<String> K) {
		logger.info("------------------------------");
		logger.info("STEP 2");

		String alpha = selectAlpha(K);
		logger.info("ST02 - alpha: " + alpha);
		for (String beta : K) {
			// if(isDivergent(alpha, beta) && ! Pair.in(new Pair(alpha, beta),
			// D) )
			if (!Pair.in(new Pair(alpha, beta), D)) {
				CostTuple tuple = selectGamma(alpha, beta, T, C);
				String gamma = tuple.getGamma();
				alpha = tuple.getAlpha();
				beta = tuple.getBeta();

				logger.info("ST02 - gamma: " + gamma);
				String seq1 = TestSequence.concat(alpha, gamma);
				String seq2 = TestSequence.concat(beta, gamma);

				TestSet.addAllPrefsOf(T, seq1);
				TestSet.addAllPrefsOf(T, seq2);

				// update C, adding new (alpha, alpha)'s
				updateC(T, C);

				// update D applying rules

				Pair p_alphabeta = new Pair(alpha, beta);
				if (Pair.add(D, p_alphabeta)) {
					ruler.applyRules(p_alphabeta, AddedTo.D); // update D
																// applying
																// rules
				}
			}
		}
		K.add(alpha);

		logger.info("T2: " + T);
		logger.info("C2: " + C);
		logger.info("D2: " + D);
		logger.info("K2:" + K);
	}

	private void updateC(ArrayList<String> T, ArrayList<Pair> C) {
		for (String test : T) {
			Pair p = new Pair(test, test);
			if (!Pair.in(p, C))
				C.add(p);
		}
	}

	private ArrayList<Pair> getIdentityRelation(ArrayList<String> T) {
		ArrayList<Pair> ret = new ArrayList<Pair>();
		for (String test : T)
			ret.add(new Pair(test, test));

		return ret;
	}

	public CostTuple selectGamma(String alpha, String beta,
			ArrayList<String> T, ArrayList<Pair> C) {
		CharacterizationSetConstructor csc = new CharacterizationSetConstructor();
		csc.setFsm(fsm);

		return csc.getDistinguishSequence(alpha, beta, T, C);
	}

	/*
	 * public String selectGamma2(String alpha, String beta) { State si =
	 * fsm.nextStateWithSequence(fsm.getInitialState(), alpha); State sj =
	 * fsm.nextStateWithSequence(fsm.getInitialState(), beta);
	 * 
	 * for(String gamma : W) { if(fsm.separe(gamma, si, sj)) return gamma; }
	 * return null; }
	 */

	public String selectAlpha(ArrayList<String> K) {
		if (!K.contains(TestSequence.EPSILON)) {
			ArrayList<String> K_l = new ArrayList<String>(K); // clone
			K_l.add(TestSequence.EPSILON);

			if (isM_Divergent(K_l))
				return TestSequence.EPSILON;
		}

		for (int i = 1; i <= 1000; i++) {
			for (String seq : getInputSeqWithLength(i)) {
				if (fsm.isDefinedSeq(seq, fsm.getInitialState())
						&& !K.contains(seq)) {
					ArrayList<String> K_l = new ArrayList<String>(K); // clone
					K_l.add(seq);

					if (isM_Divergent(K_l))
						return seq;
				}
			}
		}
		return null;
	}

	public boolean isM_Divergent(ArrayList<String> K_l) {
		for (int i = 0; i < K_l.size() - 1; i++) {
			for (int j = i + 1; j < K_l.size(); j++) {
				String seqi = K_l.get(i);
				String seqj = K_l.get(j);
				if (i != j) {
					if (!isDivergent(seqi, seqj))
						return false;
				}
			}
		}
		return true;
	}

	public boolean isDivergent(String seqi, String seqj) {
		// two seqs are divergent if they lead the machine to different states
		State si = fsm.nextStateWithSequence(fsm.getInitialState(), seqi);
		State sj = fsm.nextStateWithSequence(fsm.getInitialState(), seqj);
		if (si != sj)
			return true;

		return false;
	}

	public boolean isConvergent(String seqi, String seqj) {
		// two seqs are convergent if they lead the machine to the same states
		State si = fsm.nextStateWithSequence(fsm.getInitialState(), seqi);
		State sj = fsm.nextStateWithSequence(fsm.getInitialState(), seqj);
		if (si == sj)
			return true;

		return false;
	}

	public ArrayList<String> findK(ArrayList<String> T, ArrayList<Pair> D) {
		DivergenceGraph dg = new DivergenceGraph(T, D, fsm.getNumberOfStates());
		ArrayList<String> K = dg.getK();
		return K;
	}

	public ArrayList<Pair> getTSeparatedTestPairs(ArrayList<String> T) {
		ArrayList<Pair> ret = new ArrayList<Pair>();
		
		for (String alpha : T) {
			for (String beta : T) {
				if (!alpha.equals(beta)) {
					// common extensions
					ArrayList<String> alpha_ext = getExtensionsFrom(T, alpha);
					ArrayList<String> beta_ext = getExtensionsFrom(T, beta);

					for (String gamma : getCommonSufix(alpha, beta, alpha_ext,
							beta_ext)) {
						State sa = fsm.nextStateWithSequence(
								fsm.getInitialState(), alpha);
						State sb = fsm.nextStateWithSequence(
								fsm.getInitialState(), beta);
						if (fsm.separe(gamma, sa, sb)) {
							Pair.add(ret, new Pair(alpha, beta));							
							break;
						}
					}
				}
			}
		}

		return ret;
	}

	public ArrayList<String> getCommonSufix(String alpha, String beta,
			ArrayList<String> alphaExt, ArrayList<String> betaExt) {
		ArrayList<String> ret = new ArrayList<String>();

		for (String seq1 : alphaExt) {
			String gamma = TestSequence.getSuffixFrom(seq1, alpha);
			for (String seq2 : betaExt) {
				String gamma2 = TestSequence.getSuffixFrom(seq2, beta);
				if (gamma.equals(gamma2))
					ret.add(gamma);
			}
		}
		return ret;
	}

	public ArrayList<String> getExtensionsFrom(ArrayList<String> T, String alpha) {
		ArrayList<String> ret = new ArrayList<String>();

		for (String seq : T) {
			if (TestSequence.isProperPrefixOf(alpha, seq))
				ret.add(seq);
		}
		return ret;
	}

	public ArrayList<String> getInputSeqWithLength(int k) {
		ArrayList<String> ret = new ArrayList<String>();
		HashSet<String> Li = fsm.getInputAlphabet();

		for (String in : Li)
			ret.add(in);

		for (int i = 2; i <= k; i++) {
			ArrayList<String> temp = new ArrayList<String>();
			for (String seq : ret)
				for (String in : Li)
					temp.add(seq + "," + in);

			ret = temp;
		}
		return ret;
	}
}
