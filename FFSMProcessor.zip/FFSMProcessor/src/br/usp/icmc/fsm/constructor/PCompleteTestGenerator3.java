package br.usp.icmc.fsm.constructor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.logging.Level;

import br.usp.icmc.fsm.common.CostTuple;
import br.usp.icmc.fsm.common.FiniteStateMachine;
import br.usp.icmc.fsm.common.FsmCoverage;
import br.usp.icmc.fsm.common.HashList;
import br.usp.icmc.fsm.common.Pair;
import br.usp.icmc.fsm.common.Ruler;
import br.usp.icmc.fsm.common.State;
import br.usp.icmc.fsm.common.TestSequence;
import br.usp.icmc.fsm.common.TestSet;
import br.usp.icmc.fsm.common.TestSuite;
import br.usp.icmc.fsm.common.Transition;
import br.usp.icmc.fsm.common.Ruler.AddedTo;
import br.usp.icmc.fsm.constructor.CharacterizationSetConstructor;

public class PCompleteTestGenerator3 {

	private FiniteStateMachine fsm;
	private ArrayList<String> initialTestSet;
	private ArrayList<String> Relative;
	static boolean print_debug = false;
	static boolean print_time_debug = false;
	private int p;	
	private Ruler ruler;
	private ArrayList<String> CunionK;
	ArrayList<String[]> ident_rel = new ArrayList<String[]>();
	ArrayList<String[]> open_branch = new ArrayList<String[]>();
	
	Map<String, ArrayList<String>> C = new HashMap<String, ArrayList<String>>();			
	Map<String, ArrayList<String>> D = new HashMap<String, ArrayList<String>>();
	Map<String, ArrayList<String[]>> D3 = new HashMap<String, ArrayList<String[]>>();
	Map<String, ArrayList<String[]>> C3 = new HashMap<String, ArrayList<String[]>>();
	
	public PCompleteTestGenerator3(FiniteStateMachine fsm, boolean debug) {
		this.fsm = fsm;
		initialTestSet = new ArrayList<String>();
		initialTestSet.add("EPSILON");
		p = fsm.getNumberOfStates();
		print_time_debug = debug;
	}
	
	public void set_debug (boolean value){
		print_debug = value;
	}
	
	public void setInitialTestSet(ArrayList<String> initialTestSet) {
		this.initialTestSet = initialTestSet;
	}
	
	public ArrayList<String> process_reduced_suite() throws IOException, InterruptedException {
						
		ArrayList<String> T4 = new ArrayList<String>();
		if(!initialTestSet.isEmpty()){			
			for (String s : initialTestSet){
				TestSet.addAllPrefsOf(T4, s);
			}
		}		
		
		Relative = new ArrayList<String>();
		boolean found = processTestSuite(T4);
		if(!found){
			Relative.clear();
			return new ArrayList<String>();
		}
		return TestSequence.getNoPrefixes(Relative);
	}
	
	public boolean processTestSuite(ArrayList<String> T){
		
		if(print_time_debug)System.out.println("Incrementing...");
		long startTime = System.currentTimeMillis();
		ArrayList<String> K = increment_P(T);	
		long stopTime = System.currentTimeMillis();
	    long elapsedTime = stopTime - startTime;
	    if(print_time_debug)System.out.println("Total time P method "+elapsedTime);
		
		//Relative = T;
		//return true;
		
		
		if(print_time_debug)System.out.println("Reduncing...");
		startTime = System.currentTimeMillis();
		boolean res = indentify_all(T, K);	
		stopTime = System.currentTimeMillis();
	    elapsedTime = stopTime - startTime;
	    if(print_time_debug)System.out.println("Total time removing redundant tests "+elapsedTime);
		
		return res;
	}
	
	public boolean processTestSuite_old(ArrayList<String> T){
		
		ArrayList<String> K = increment_P(T);
				
		ArrayList<Transition> non_trans = fsm.getTransitions();		
		Map<Transition, ArrayList<String>> requirement = indentify_all_old(T, K);
				
		if(print_debug)System.out.println("non_trans "+ non_trans);
		if(requirement == null){
			return false;
		}		
		req:for(Transition non_t : non_trans){			
			String fi = requirement.get(non_t).get(0);
			//check where the convergent pair came from: rule or divergent'
			String chi = findChi(K,fi);
			for(String k : C3.keySet()){
				for(String[] nd : C3.get(k)){
					String l1 = "("+fi+";"+chi+")";
					String r1 = "("+chi+";"+fi+")";				
					if(nd[0].equals(l1) || nd[0].equals(r1)){
						if(nd[1].startsWith("rule")){
							if(identify_rule2(K, fi, chi)){
								continue req;
							}							
						}						
					}
				}
			}
			identify_rules(fi, chi, K);					
		}
		return true;
	}
	
	public boolean identify_rules(String fi, String chi, ArrayList<String> K){
		if(print_debug)System.out.println("RULE IDENTIFY " + fi + " "+ chi);
		open_branch = new ArrayList<String[]>();
		ident_rel = new ArrayList<String[]>();
		for (String upsilon : TestSet.minus(K, chi)) {
			boolean found = false;
			String upgamma = "";
			String figamma = "";
			if(D3.get(upsilon) != null){
				for(String[] node : D3.get(upsilon)){
					if(node[0].equals(fi)){
						found = true;
						upgamma = TestSequence.concat(upsilon, node[1]);
						figamma = TestSequence.concat(fi, node[1]);
						break;
					}
				}
			}			
			if(print_debug)System.out.println("IDENTIFY up "+ upsilon + " fi " + fi);
			//if exist as T-sep pair
			if(found){
				if(print_debug)System.out.println("ADD T-set part 1 " + upgamma + " + "+ figamma);			
				add_relative(figamma, upgamma);
			}else{
				//deal with rules			
				identify_rule_rec(fi, upsilon, K);
			}
		}	
		if(open_branch.size()!=0){
			return false;
		}
		return true;
	}
	
	public boolean identify_rule_rec(String fi, String upsilon, ArrayList<String> K){
		if(print_debug)System.out.println("RULE RECURSIVE " + fi + " "+ upsilon);	
		add_relative(fi, upsilon);
		String[] w = new String[2];
		w[0]=fi;w[1]=upsilon;
		String[] w1 = new String[2];
		w1[0]=upsilon;w1[1]=fi;
		for(String[] y : ident_rel){
			if((y[0].equals(fi) && y[1].equals(upsilon)) 
					|| (y[0].equals(upsilon) && y[1].equals(fi))){
				if(print_debug)System.out.println("CLOSED LEAF");
				return true;
			}
		}
		if(!open_branch.contains(w)){
			open_branch.add(w);
		}
		if(!open_branch.contains(w1)){
			open_branch.add(w1);
		}
		boolean found = false;
		ky: for(String key : D3.keySet()){
			for(String[] node : D3.get(key)){
				//System.out.println("NODE "+ node[0]);
				String left = "("+upsilon+";"+fi+")";
				String right = "("+fi+";"+upsilon+")";				
				if(node[0].equals(left) || node[0].equals(right)){
					String l = key.substring(1,key.indexOf(";"));
					String r = key.substring(key.indexOf(";")+1,key.length()-1);
					if(!node[0].equals("("+r+";"+l+")") && !node[0].equals("("+l+";"+r+")")){
						if(print_debug)System.out.println("up "+ upsilon + " fi " + fi+
								" Deal with "+ node[0] + "|"+ node[1] + " + key " + key);
						
						if(node[1].equals("rule 4a")){
							found = identify_rule4a(key, node, left, right, fi, upsilon, K);							
							if(!found)continue;
							break ky;
						}
						if(node[1].equals("rule 4b")){
							found = identify_rule4b(key, node, left, right, fi, upsilon, K);
							if(!found)continue;
							break ky;
						}
						if(node[1].equals("rule 5a")){
							found = identify_rule5a(key, node, left, right, fi, upsilon, K);
							if(!found)continue;
							break ky;
						}
						if(node[1].equals("rule 5b")){
							found = identify_rule5b(key, node, left, right, fi, upsilon, K);
							if(!found)continue;
							break ky;
						}
						if(node[1].equals("rule 3")){
							found = identify_rule3(key, node, left, right, fi, upsilon, K);
							if(!found)continue;
							break ky;
						}
						if(node[1].equals("rule 6")){
							found = identify_rule6(key, node, left, right, fi, upsilon, K);
							if(!found)continue;
							break ky;
						}
						if(node[1].equals("rule 7")){
							found = identify_rule7(key, node, left, right, fi, upsilon, K);
							if(!found)continue;
							break ky;
						}
						if(node[1].equals("rule 8")){
							found = identify_rule8(key, node, left, right, fi, upsilon, K);
							if(!found)continue;
							break ky;
						}
						if(node[1].equals("rule 9")){
							found = identify_rule9(key, node, left, right, fi, upsilon, K);
							if(!found)continue;
							break ky;
						}
						if(node[1].equals("rule 10")){
							found = identify_rule10(key, node, left, right, fi, upsilon, K);
							if(!found)continue;
							break ky;
						}
					}					
				}
			}			
		}
		if(!found){
			System.out.println("ERROR rule rec");
			return false;
		}
		open_branch.remove(w);
		open_branch.remove(w1);
		if(!ident_rel.contains(w)){
			ident_rel.add(w);
		}
		if(!ident_rel.contains(w1)){
			ident_rel.add(w1);
		}
		return true;
	}
	
	public boolean identify_rule1(ArrayList<String> K,	String l, String r){
		if(print_debug)System.out.println("RULE 1 " + l + " " + r);
		
		String[] w = new String[2];
		w[0]=l;w[1]=r;
		String[] w1 = new String[2];
		w1[0]=r;w1[1]=l;		
		for(String[] y : ident_rel){
			if((y[0].equals(l) && y[1].equals(r)
					|| (y[0].equals(r) && y[1].equals(l)))){
				if(print_debug)System.out.println("CLOSED LEAF");
				return true;
			}
		}
		for(String[] y : open_branch){
			if((y[0].equals(l) && y[1].equals(r)
					|| (y[0].equals(r) && y[1].equals(l)))){
				if(print_debug)System.out.println("LOOP BRANCH");
				return true;
			}
		}		
		if(!open_branch.contains(w)){
			open_branch.add(w);
		}
		if(!open_branch.contains(w1)){
			open_branch.add(w1);
		}
		
		for(String k : C3.keySet()){
			for(String[] nd : C3.get(k)){
				String l1 = "("+l+";"+r+")";
				String r1 = "("+r+";"+l+")";				
				if(nd[0].equals(l1) || nd[0].equals(r1)){
					if(nd[1].equals("rule 1")){
						String l2 = k.substring(1,k.indexOf(";"));
						String r2 = k.substring(k.indexOf(";")+1,k.length()-1);
						if(!nd[0].equals("("+r2+";"+l2+")")	&& !nd[0].equals("("+l2+";"+r2+")")){
							//identify key
							boolean found = false;
							if(K.contains(l2)){
								ArrayList<String> K_UP = TestSet.minus(K, l2);
								found = identify_conv_preserv(K_UP, k, r2, K);								
								if(found){
									open_branch.remove(w);
									open_branch.remove(w1);
									if(!ident_rel.contains(w)){
										ident_rel.add(w);
									}
									if(!ident_rel.contains(w1)){
										ident_rel.add(w1);
									}
									return true;
								}								
							}if(K.contains(r2)){
								ArrayList<String> K_UP = TestSet.minus(K, r2);
								found = identify_conv_preserv(K_UP, k, l2, K);
								if(found){
									open_branch.remove(w);
									open_branch.remove(w1);
									if(!ident_rel.contains(w)){
										ident_rel.add(w);
									}
									if(!ident_rel.contains(w1)){
										ident_rel.add(w1);
									}
									return true;
								}
							}
							if(!found){
								System.out.println("Recursive 2");
								boolean done = identify_rule2(K, l2, r2);
								if(!done) return false;
								open_branch.remove(w);
								open_branch.remove(w1);
								if(!ident_rel.contains(w)){
									ident_rel.add(w);
								}
								if(!ident_rel.contains(w1)){
									ident_rel.add(w1);
								}
								return true;
							}							
						}													
					}
				}
			}
		}
		System.out.println("RULE 1 FALSE");	
		return false;
	}
	
	public boolean identify_rule2(ArrayList<String> K,	String l, String r){
		if(l.equals(r)) return true;
		if(print_debug)System.out.println("RULE 2 " + l + " " + r);
		String[] w = new String[2];
		w[0]=l;w[1]=r;
		String[] w1 = new String[2];
		w1[0]=r;w1[1]=l;		
		for(String[] y : ident_rel){
			if((y[0].equals(l) && y[1].equals(r)
					|| (y[0].equals(r) && y[1].equals(l)))){
				if(print_debug)System.out.println("CLOSED LEAF");
				return true;
			}
		}
		for(String[] y : open_branch){
			if((y[0].equals(l) && y[1].equals(r)
					|| (y[0].equals(r) && y[1].equals(l)))){
				if(print_debug)System.out.println("LOOP BRANCH");
				return true;
			}
		}		
		if(!open_branch.contains(w)){
			open_branch.add(w);
		}
		if(!open_branch.contains(w1)){
			open_branch.add(w1);
		}
		
		for(String k : C3.keySet()){
			for(String[] nd : C3.get(k)){
				String l1 = "("+l+";"+r+")";
				String r1 = "("+r+";"+l+")";				
				if(nd[0].equals(l1) || nd[0].equals(r1)){
					if(nd[1].equals("rule 1")){		
						add_relative(l, r);
						boolean done = identify_rule1(K, l, r);						
						if(!done){			
							return false;
						}
						open_branch.remove(w);
						open_branch.remove(w1);						
						if(!ident_rel.contains(w)){
							ident_rel.add(w);
						}
						if(!ident_rel.contains(w1)){
							ident_rel.add(w1);
						}
						return true;
					}
					if(nd[1].equals("rule 2")){
						String l2 = k.substring(1,k.indexOf(";"));
						String r2 = k.substring(k.indexOf(";")+1,k.length()-1);
						add_relative(l, r);
						//se l2 esta em K entao definitivamente existe o par Tn(T)-convergente
						if(K.contains(l2)){
							ArrayList<String> K_UP = TestSet.minus(K, l2);
							boolean done = identify_conv_preserv(K_UP, k, r2, K);
							if(!done) return false;
							open_branch.remove(w);
							open_branch.remove(w1);
							if(!ident_rel.contains(w)){
								ident_rel.add(w);
							}
							if(!ident_rel.contains(w1)){
								ident_rel.add(w1);
							}
							return true;
						}if(K.contains(r2)){
							ArrayList<String> K_UP = TestSet.minus(K, r2);
							boolean done = identify_conv_preserv(K_UP, k, l2, K);
							if(!done) return false;
							open_branch.remove(w);
							open_branch.remove(w1);
							if(!ident_rel.contains(w)){
								ident_rel.add(w);
							}
							if(!ident_rel.contains(w1)){
								ident_rel.add(w1);
							}
							return true;
						}
						if(print_debug)System.out.println("IDENT rule 2 "+ l + " "+ r);						
						boolean done = identify_rule2(K, l2, r2);						
						if(!done)return false;						
						open_branch.remove(w);
						open_branch.remove(w1);
						return true;																																	
					}
				}
			}
		}
		// if it is not a rule then is t(T)-convergent!
		if(K.contains(l)){
			ArrayList<String> K_UP = TestSet.minus(K, l);
			boolean done = identify_conv_preserv(K_UP, "", r, K);
			if(!done)return false;	
			open_branch.remove(w);
			open_branch.remove(w1);
			if(!ident_rel.contains(w)){
				ident_rel.add(w);
			}
			if(!ident_rel.contains(w1)){
				ident_rel.add(w1);
			}
			return true;
		}if(K.contains(r)){
			ArrayList<String> K_UP = TestSet.minus(K, r);
			boolean done = identify_conv_preserv(K_UP, "", l, K);
			if(!done)return false;	
			open_branch.remove(w);
			open_branch.remove(w1);
			if(!ident_rel.contains(w)){
				ident_rel.add(w);
			}
			if(!ident_rel.contains(w1)){
				ident_rel.add(w1);
			}
			return true;
		}	
		System.out.println("ERROR rule 2");
		return false;
	}
	
	public boolean identify_rule3(String key, String[] node, String left, String right, 
			String fi, String upsilon, ArrayList<String> K){
		if(print_debug)System.out.println("RULE 3 "+ left + " "+ right);						
		String l = key.substring(1,key.indexOf(";"));
		String r = key.substring(key.indexOf(";")+1,key.length()-1);
		if(D.get(l).contains(r)){													
			//check which rule activated it D3
			boolean found = false;
			if(D3.get(l)!=null){
				for(String[] nd3 : D3.get(l)){
					if(nd3[0].equals(r)){
						found = true;
						String lgamma = TestSequence.concat(l, nd3[1]);
						String figamma = TestSequence.concat(r, nd3[1]);
						if(print_debug)System.out.println("ADD T-set part 3 " 
								+ lgamma + " + "+ figamma);
						add_relative(figamma, lgamma);
						break;
					}
				}				
			}	
			if(!found){
				for(String[] y : open_branch){
					if((y[0].equals(l) && y[1].equals(r)) 
							|| (y[0].equals(r) && y[1].equals(l))){
						if(print_debug)System.out.println("LOOP BRANCH");
						return true;
					}
				}
				//identify_rule_rec(l, r, K);
				boolean done = identify_rule_rec(l, r, K);
				if(!done) return false;
			}
		}else{
			//find recursive
			System.out.println("ERROR RECURSIVE");
		}
		return true;
	}
	
	public boolean identify_rule4a(String key, String[] node, String left, String right, 
			String fi, String upsilon, ArrayList<String> K){
		if(print_debug)System.out.println("RULE 4A "+ left + " "+ right);						
		String l = key.substring(1,key.indexOf(";"));
		String r = key.substring(key.indexOf(";")+1,key.length()-1);
		if(C.get(l).contains(r)){			
			//check which rule activate it D3
			if(node[0].equals(left)){				
				boolean found = false;
				if(D3.get(fi)!=null){
					for(String[] nd3 : D3.get(fi)){
						if(nd3[0].equals(l)){
							found = true;
							String lgamma = TestSequence.concat(fi, nd3[1]);
							String figamma = TestSequence.concat(l, nd3[1]);
							if(print_debug)System.out.println("ADD T-set part 4a/1 " 
									+ lgamma + " + "+ figamma);
							add_relative(figamma, lgamma);
							break;
						}
					}
				}				
				if(!found){					
					for(String[] y : open_branch){
						if((y[0].equals(fi) && y[1].equals(l)) 
								|| (y[0].equals(l) && y[1].equals(fi))){
							if(print_debug)System.out.println("LOOP BRANCH");
							return true;
						}
					}
					//identify_rule_rec(fi, l, K);
					boolean done = identify_rule_rec(fi, l, K);
					if(!done) return false;
				}
			}if(node[0].equals(right)){
				boolean found = false;
				if(D3.get(upsilon)!=null){
					for(String[] nd3 : D3.get(upsilon)){
						if(nd3[0].equals(l)){
							found = true;
							String rgamma = TestSequence.concat(upsilon, nd3[1]);
							String figamma = TestSequence.concat(l, nd3[1]);
							if(print_debug)System.out.println("ADD T-set part 4a/2 " 
									+ rgamma + " + "+ figamma);						
							add_relative(figamma, rgamma);
							break;
						}
					}
				}				
				if(!found){
					for(String[] y : open_branch){
						if((y[0].equals(upsilon) && y[1].equals(l)) 
								|| (y[0].equals(l) && y[1].equals(upsilon))){
							if(print_debug)System.out.println("LOOP BRANCH");
							return true;
						}
					}
					//identify_rule_rec(upsilon, l, K);
					boolean done = identify_rule_rec(upsilon, l, K);
					if(!done) return false;
				}
			}																				
			//check which rule activated it C3
			boolean done = identify_rule2(K, l, r);
			if(!done) return false;
		}else{
			//find recursive
			System.out.println("ERROR RECURSIVE");
		}
		return true;
	}
	
	public boolean identify_rule4b(String key, String[] node, String left, String right, 
			String fi, String upsilon, ArrayList<String> K){
		if(print_debug)System.out.println("RULE 4B "+ left + " "+ right);					
		String l = key.substring(1,key.indexOf(";"));
		String r = key.substring(key.indexOf(";")+1,key.length()-1);
		if(C.get(l).contains(r)){			
			//check which rule activate it D3
			if(node[0].equals(left)){
				boolean found = false;
				if(D3.get(fi)!=null){
					for(String[] nd3 : D3.get(fi)){
						if(nd3[0].equals(r)){
							found = true;
							String lgamma = TestSequence.concat(fi, nd3[1]);
							String figamma = TestSequence.concat(r, nd3[1]);
							if(print_debug)System.out.println("ADD T-set part 4b/1 " 
									+ lgamma + " + "+ figamma);
							add_relative(figamma, lgamma);
							break;
						}
					}
				}				
				if(!found){
					for(String[] y : open_branch){
						if((y[0].equals(fi) && y[1].equals(r)) 
								|| (y[0].equals(r) && y[1].equals(fi))){
							if(print_debug)System.out.println("LOOP BRANCH");
							return true;
						}
					}
					//identify_rule_rec(fi, r, K);
					boolean done = identify_rule_rec(fi, r, K);
					if(!done) return false;
				}
			}if(node[0].equals(right)){
				boolean found = false;
				if(D3.get(upsilon)!=null){
					for(String[] nd3 : D3.get(upsilon)){
						if(nd3[0].equals(r)){
							found = true;
							String rgamma = TestSequence.concat(upsilon, nd3[1]);
							String figamma = TestSequence.concat(r, nd3[1]);
							if(print_debug)System.out.println("ADD T-set part 4b/2 " 
									+ rgamma + " + "+ figamma);						
							add_relative(figamma, rgamma);
							break;
						}
					}
				}				
				if(!found){
					for(String[] y : open_branch){
						if((y[0].equals(upsilon) && y[1].equals(r)) 
								|| (y[0].equals(r) && y[1].equals(upsilon))){
							if(print_debug)System.out.println("LOOP BRANCH");
							return true;
						}
					}
					//identify_rule_rec(upsilon, r, K);
					boolean done = identify_rule_rec(upsilon, r, K);
					if(!done) return false;
				}
			}																				
			//check which rule activated it C3
			boolean done = identify_rule2(K, l, r);
			if(!done) return false;
		}else{
			//find recursive
			System.out.println("ERROR RECURSIVE");
		}
		return true;
	}
	
	public boolean identify_rule5a(String key, String[] node, String left, String right, 
			String fi, String upsilon, ArrayList<String> K){
		if(print_debug)System.out.println("RULE 5A "+ left + " "+ right);				
		String l = key.substring(1,key.indexOf(";"));
		String r = key.substring(key.indexOf(";")+1,key.length()-1);
		if(D.get(l).contains(r)){			
			//check which rule activate it C3
			if(node[0].equals(left) && !l.equals(fi)){				
				boolean done = identify_rule2(K, fi, l);
				if(!done) return false;
			}if(node[0].equals(right) && !l.equals(upsilon)){
				boolean done = identify_rule2(K, upsilon, l);
				if(!done) return false;
			}																				
			//check which rule activated it D3
			boolean found = false;
			if(D3.get(l)!=null){
				for(String[] nd3 : D3.get(l)){
					if(nd3[0].equals(r)){
						found = true;
						String lgamma = TestSequence.concat(l, nd3[1]);
						String figamma = TestSequence.concat(r, nd3[1]);
						if(print_debug)System.out.println("ADD T-set part 5a " 
								+ lgamma + " + "+ figamma);
						add_relative(figamma, lgamma);
						break;
					}
				}				
			}	
			if(!found){
				for(String[] y : open_branch){
					if((y[0].equals(l) && y[1].equals(r)) 
							|| (y[0].equals(r) && y[1].equals(l))){
						if(print_debug)System.out.println("LOOP BRANCH");
						return true;
					}
				}
				//identify_rule_rec(l, r, K);
				boolean done = identify_rule_rec(l, r, K);
				if(!done) return false;
			}
		}else{
			//find recursive
			System.out.println("ERROR RECURSIVE");
		}
		return true;
	}
	
	public boolean identify_rule5b(String key, String[] node, String left, String right, 
			String fi, String upsilon, ArrayList<String> K){
		if(print_debug)System.out.println("RULE 5B "+ left + " "+ right);						
		String l = key.substring(1,key.indexOf(";"));
		String r = key.substring(key.indexOf(";")+1,key.length()-1);
		if(D.get(l).contains(r)){			
			//check which rule activate it C3
			if(node[0].equals(left)  && !r.equals(fi)){
				boolean done = identify_rule2(K, fi, r);
				if(!done) return false;
			}if(node[0].equals(right)  && !r.equals(upsilon)){
				boolean done = identify_rule2(K, upsilon, r);
				if(!done) return false;
			}																				
			//check which rule activated it D3
			boolean found = false;
			if(D3.get(l)!=null){
				for(String[] nd3 : D3.get(l)){
					if(nd3[0].equals(r)){
						found = true;
						String lgamma = TestSequence.concat(l, nd3[1]);
						String figamma = TestSequence.concat(r, nd3[1]);
						if(print_debug)System.out.println("ADD T-set part 5b " 
								+ lgamma + " + "+ figamma);
						add_relative(figamma, lgamma);
						break;
					}
				}				
			}	
			if(!found){
				for(String[] y : open_branch){
					if((y[0].equals(l) && y[1].equals(r)) 
							|| (y[0].equals(r) && y[1].equals(l))){
						if(print_debug)System.out.println("LOOP BRANCH");
						return true;
					}
				}
				//identify_rule_rec(l, r, K);
				boolean done = identify_rule_rec(l, r, K);
				if(!done) return false;
			}							
		}else{
			//find recursive
			System.out.println("ERROR RECURSIVE");
		}
		return true;
	}
	
	public boolean identify_rule6(String key, String[] node, String left, String right, 
			String fi, String upsilon, ArrayList<String> K){
		if(print_debug)System.out.println("RULE 6 "+ left + " "+ right);			
		String l = key.substring(1,key.indexOf(";"));
		String r = key.substring(key.indexOf(";")+1,key.length()-1);
		if(D.get(l).contains(r)){													
			//check which rule activated it D3
			boolean found = false;
			if(D3.get(l)!=null){
				for(String[] nd3 : D3.get(l)){
					if(nd3[0].equals(r)){
						found = true;
						String lgamma = TestSequence.concat(l, nd3[1]);
						String figamma = TestSequence.concat(r, nd3[1]);
						if(print_debug)System.out.println("ADD T-set part 6 " 
								+ lgamma + " + "+ figamma);
						add_relative(figamma, lgamma);
						break;
					}
				}				
			}	
			if(!found){
				for(String[] y : open_branch){
					if((y[0].equals(l) && y[1].equals(r)) 
							|| (y[0].equals(r) && y[1].equals(l))){
						if(print_debug)System.out.println("LOOP BRANCH");
						return true;
					}
				}				
				//identify_rule_rec(l, r, K);
				boolean done = identify_rule_rec(l, r, K);
				if(!done) return false;
			}
		}else{
			//find recursive
			System.out.println("ERROR RECURSIVE");
		}
		return true;
	}
	
	public boolean identify_rule7(String key, String[] node, String left, String right, 
			String fi, String upsilon, ArrayList<String> K){
		if(print_debug)System.out.println("RULE 7 "+ left + " "+ right);				
		String l = key.substring(1,key.indexOf(";"));
		String r = key.substring(key.indexOf(";")+1,key.length()-1);
		if(C.get(l).contains(r)){			
			//check which rule activate it D3
			Pair newpair = new Pair(l,r);			
			String alpha = newpair.getShorter();
			String alphabetagamma = newpair.getlonger();
			newpair = new Pair(fi,upsilon);
			String alphabeta = newpair.getlonger();
			if(TestSequence.isProperPrefixOf(alpha, alphabetagamma)){
				//String betagamma = TestSequence.getSuffixFrom(alphabetagamma, alpha);
				String gamma = TestSequence.getSuffixFrom(alphabetagamma, alphabeta);
				String alphagamma = TestSequence.concat(alpha, gamma);
				boolean found = false;
				if(D3.get(alpha) != null){
					for(String[] nd3 : D3.get(alpha)){
						if(nd3[0].equals(alphagamma)){
							found = true;
							String lgamma = TestSequence.concat(alpha, nd3[1]);
							String figamma = TestSequence.concat(alphagamma, nd3[1]);
							if(print_debug)System.out.println("ADD T-set part 7 " 
									+ lgamma + " + "+ figamma);
							add_relative(figamma, lgamma);
							break;
						}
					}
				}								
				if(!found){
					for(String[] y : open_branch){
						if((y[0].equals(alpha) && y[1].equals(alphagamma)) 
								|| (y[0].equals(alphagamma) && y[1].equals(alpha))){
							if(print_debug)System.out.println("LOOP BRANCH");
							return true;
						}
					}
					//identify_rule_rec(alpha, alphagamma, K);
					boolean done = identify_rule_rec(alpha, alphagamma, K);
					if(!done) return false;
				}
			}																	
			//check which rule activated it C3
			boolean done = identify_rule2(K, l, r);
			if(!done) return false;
		}else{
			//find recursive
			System.out.println("ERROR RECURSIVE");
		}
		return true;
	}
	
	public boolean identify_rule8(String key, String[] node, String left, String right, 
			String fi, String upsilon, ArrayList<String> K){
		if(print_debug)System.out.println("RULE 8 " + left + " "+ right);					
		String l = key.substring(1,key.indexOf(";"));
		String r = key.substring(key.indexOf(";")+1,key.length()-1);
		if(D.get(l).contains(r)){			
			//check which rule activate it C3
			Pair newpair = new Pair(l,r);			
			String alpha = newpair.getShorter();
			String alphagamma = newpair.getlonger();
			newpair = new Pair(fi,upsilon);
			String alphabeta = newpair.getlonger();
			if(TestSequence.isProperPrefixOf(alpha, alphagamma)){
				String gamma = TestSequence.getSuffixFrom(alphagamma, alpha);
				//String beta = TestSequence.getSuffixFrom(alphabeta, alpha);
				String alphabetagamma = TestSequence.concat(alphabeta, gamma);
				boolean done = identify_rule2(K, alpha, alphabetagamma);
				if(!done) return false;
			}																			
			//check which rule activated it D3			
			boolean found = false;
			if(D3.get(l) != null){
				for(String[] nd3 : D3.get(l)){
					if(nd3[0].equals(r)){
						found = true;
						String lgamma = TestSequence.concat(l, nd3[1]);
						String figamma = TestSequence.concat(r, nd3[1]);
						if(print_debug)System.out.println("ADD T-set part 8 " 
								+ lgamma + " + "+ figamma);
						add_relative(figamma, lgamma);
						break;
					}
				}
			}			
			if(!found){
				for(String[] y : open_branch){
					if((y[0].equals(l) && y[1].equals(r)) 
							|| (y[0].equals(r) && y[1].equals(l))){
						if(print_debug)System.out.println("LOOP BRANCH");
						return true;
					}
				}
				//identify_rule_rec(l, r, K);
				boolean done = identify_rule_rec(l, r, K);
				if(!done) return false;
			}
		}else{
			//find recursive
			System.out.println("ERROR RECURSIVE");
		}
		return true;
	}
	
	public boolean identify_rule9(String key, String[] node, String left, String right, 
			String fi, String upsilon, ArrayList<String> K){
		if(print_debug)System.out.println("RULE 9 " + left + " "+ right);			
		String l = key.substring(1,key.indexOf(";"));
		String r = key.substring(key.indexOf(";")+1,key.length()-1);		
		if(C.get(l).contains(r)){			
			//check which rule activate it D3
			Pair newpair = new Pair(l,r);			
			String alpha = newpair.getShorter();
			String alphagamma = newpair.getlonger();
			if(TestSequence.isProperPrefixOf(alpha, alphagamma)){
				String gamma = TestSequence.getSuffixFrom(alphagamma, alpha);
				String beta = "";
				if(fi.equals(alpha)){
					beta = upsilon;
				}else{
					beta = fi;
				}
				String betagamma = TestSequence.concat(beta, gamma);
				
				boolean found = false;
				if(D3.get(beta) != null){
					for(String[] nd3 : D3.get(beta)){
						if(nd3[0].equals(betagamma)){
							found = true;
							String lgamma = TestSequence.concat(beta, nd3[1]);
							String figamma = TestSequence.concat(betagamma, nd3[1]);
							if(print_debug)System.out.println("ADD T-set part 9 " 
									+ lgamma + " + "+ figamma);
							add_relative(figamma, lgamma);
							break;
						}
					}
				}								
				if(!found){
					for(String[] y : open_branch){
						if((y[0].equals(beta) && y[1].equals(betagamma)) 
								|| (y[0].equals(betagamma) && y[1].equals(beta))){
							if(print_debug)System.out.println("LOOP BRANCH");
							return true;
						}
					}
					//identify_rule_rec(beta, betagamma, K);
					boolean done = identify_rule_rec(beta, betagamma, K);
					if(!done) return false;
				}
			}																			
			//check which rule activated it C3
			boolean done = identify_rule2(K, l, r);
			if(!done) return false;
		}else{
			//find recursive
			System.out.println("ERROR RECURSIVE");
		}
		return true;
	}
		
	public boolean identify_rule10(String key, String[] node, String left, String right, 
			String fi, String upsilon, ArrayList<String> K){
		if(print_debug)System.out.println("RULE 10 " + left + " "+ right);					
		String l = key.substring(1,key.indexOf(";"));
		String r = key.substring(key.indexOf(";")+1,key.length()-1);
		if(D.get(l).contains(r)){			
			//check which rule activate it C3
			Pair newpair = new Pair(l,r);			
			String beta = newpair.getShorter();
			String betagamma = newpair.getlonger();
			
			if(TestSequence.isProperPrefixOf(beta, betagamma)){
				String gamma = TestSequence.getSuffixFrom(betagamma, beta);								
				String alpha = "";
				if(fi.equals(beta)){
					alpha = upsilon;
				}else{
					alpha = fi;
				}
				String alphagamma = TestSequence.concat(alpha, gamma);				
				boolean done = identify_rule2(K, alpha, alphagamma);
				if(!done) return false;
			}																			
			//check which rule activated it D3			
			boolean found = false;
			if(D3.get(l) != null){
				for(String[] nd3 : D3.get(l)){
					if(nd3[0].equals(r)){
						found = true;
						String lgamma = TestSequence.concat(l, nd3[1]);
						String figamma = TestSequence.concat(r, nd3[1]);
						if(print_debug)System.out.println("ADD T-set part 10 " 
								+ lgamma + " + "+ figamma);
						add_relative(figamma, lgamma);
						break;
					}
				}
			}			
			if(!found){
				for(String[] y : open_branch){
					if((y[0].equals(l) && y[1].equals(r)) 
							|| (y[0].equals(r) && y[1].equals(l))){
						if(print_debug)System.out.println("LOOP BRANCH");
						return true;
					}
				}
				//identify_rule_rec(l, r, K);
				boolean done = identify_rule_rec(l, r, K);
				if(!done) return false;
			}
		}else{
			//find recursive
			System.out.println("ERROR RECURSIVE");
		}
		return true;
	}
	
	public boolean identify_conv_preserv(ArrayList<String> K_UP,
			String k, String fi, ArrayList<String> K){
		if(print_debug)System.out.println("RULE CON_PRE");		
		for (String upsilon : K_UP) {
			boolean found = false;
			String upgamma = "";
			String figamma = "";
			//is T-sep?
			if(D3.get(fi) != null){
				for(String[] node : D3.get(fi)){
					if(node[0].equals(upsilon)){
						found = true;
						upgamma = TestSequence.concat(upsilon, node[1]);
						figamma = TestSequence.concat(fi, node[1]);
						break;
					}
				}
			}			
			//if exist as T-sep part
			if(found){
				if(print_debug)System.out.println("ADD T-set part CON_PRE upsilon "+upsilon +" KEY " + 
						k + " " + upgamma + " + "+ figamma);									
				add_relative(figamma, upgamma);
			}else{
				for(String[] y : open_branch){
					if(y[0].equals(fi) && y[1].equals(upsilon)){
						if(print_debug)System.out.println("LOOP BRANCH");
						return true;
					}
				}
				boolean done = identify_rule_rec(fi, upsilon, K);
				if(!done) return false;
			}
		}
		return true;
	}
	
	
	
	public void add_relative(String arg1, String arg2){
		if(!Relative.contains(arg1)){
			Relative.add(arg1);
		}
		if(!Relative.contains(arg2)){
			Relative.add(arg2);
		}
	}
	
	public ArrayList<String> increment_P(ArrayList<String> T){
		C = getIdentityRelation2(T);
		
		if(print_time_debug)System.out.println("Processing a T-separated set...");
		long startTime = System.currentTimeMillis();
		D = getTSeparatedTestPairs5(T);		
		long stopTime = System.currentTimeMillis();
	    long elapsedTime = stopTime - startTime;
	    if(print_time_debug)System.out.println("Total time to get a T-separated set D "+elapsedTime);
		
		
		C3 = new HashMap<String, ArrayList<String[]>>();
		
		Map<String, ArrayList<String>> temp_D = new HashMap<String, ArrayList<String>>();		
		//analyze all	
		for (String a : D.keySet()) {
			ArrayList<String> aux = new ArrayList<String>();
			aux.addAll(D.get(a));
			String b = a;
			temp_D.put(b, aux); 
		}
		ruler = new Ruler(C, D, T, fsm, C3, D3);		
		for (String a : temp_D.keySet()) {
			for (String b : temp_D.get(a)) {				
				ruler.applyRules5(new Pair(a,b), AddedTo.D);			
			}			
		}
			
		ArrayList<String> K = new ArrayList<String>();			
		int n = fsm.getStates().size();
		while (K.size() < Math.min(p + 1, n)) // CONDITION 1
		{
			step02c(T, C, D, K);						
		}		
		CunionK = findCunionK2(C, K);	
		FsmCoverage coverage = new FsmCoverage(fsm);
		while (!coverage.isInitializedTransitionCoverage(CunionK)) {
			// CONDITION 4
			Pair p_fichi = findFiChi3(T, CunionK, K, D);			
			if (p_fichi != null) // C4 YES
			{
				step03a(C, p_fichi);
			} else // C4 NO
			{
				// CONDITION 5
				if (!CunionK.contains("EPSILON")) // C5 NO
				{					
					Pair p_fichi2 = step04a("EPSILON", K, D, C, T);
					step03a(C, p_fichi2);					
				} else // C5 YES
				{					
					String fi = step05a(CunionK, T, C, D);						
					Pair p_fichi2 = step04a(fi, K, D, C, T);
					step03a(C, p_fichi2);										
				}
			}
			CunionK = findCunionK2(C, K);
		}	
		return K;
	}
	
	private String step05a(ArrayList<String> CunionK, ArrayList<String> T,
			Map<String, ArrayList<String>> C, Map<String, ArrayList<String>> D) {
		
		FsmCoverage coverage = new FsmCoverage(fsm);
		
		// select the transition
		Transition transition = selectTransition(CunionK, coverage, T);
		State s = transition.getIn();
		for (String alpha : CunionK) {
			if (fsm.nextStateWithSequence(fsm.getInitialState(), alpha) == s) {
				String alphax = TestSequence.concat(alpha,
						transition.getInput());
				TestSet.addAllPrefsOf(T, alphax);
				ArrayList<String> new_tests = new ArrayList<String>();
				new_tests.addAll(TestSequence.getAllPrefixesFrom(alphax));
								
				updateC2(new_tests, C);							
				updateD2(D, T, alphax);				
				return alphax;				
			}
		}
		return null;
	}	
	
	public ArrayList<CostTuple> selectGamma4(String alpha, String beta,
			ArrayList<String> T, Map<String, ArrayList<String>> C) {
		CharacterizationSetConstructor csc = new CharacterizationSetConstructor();
		csc.setFsm(fsm);		
		ArrayList<CostTuple> tuples = csc.getDistinguishSequence4(alpha, beta, TestSequence.getNoPrefixes(T), C);
		return tuples;
	}
	
	private Transition selectTransition(ArrayList<String> CunionK,
			FsmCoverage coverage, ArrayList<String> T) {
		Transition transition = coverage.getNonCoveredtransitions(CunionK).get(0);
		return transition;
	}
	
	public void updateD2(Map<String, ArrayList<String>> D, ArrayList<String> T, String alphax) {
		for (String alpha : TestSequence.getAllPrefixesFrom(alphax)) {
			for (String test : T) {
				if (!alpha.equals(test)) {
					State sa = fsm.nextStateWithSequence(
							fsm.getInitialState(), alpha);
					State sb = fsm.nextStateWithSequence(
							fsm.getInitialState(), test);
					if(!sa.equals(sb)){
						// common extensions
						ArrayList<String> alpha_ext = getExtensionsFrom(T, alpha);
						ArrayList<String> beta_ext = getExtensionsFrom(T, test);					
						for (String gamma : getCommonSufix(alpha, test, alpha_ext,
								beta_ext)) {
							if (fsm.separe(gamma, sa, sb)) {							
								Pair p = new Pair(alpha, test);							
								if(addD3Pair2(gamma, D, alpha, test)){
									ruler.applyRules5(p, AddedTo.D);
								}
								break;
							}
						}
					}					
				}
			}
		}
	}
	
	public ArrayList<String> getExtensionsFrom(ArrayList<String> T, String alpha) {
		ArrayList<String> ret = new ArrayList<String>();

		for (String seq : T) {
			if(seq.length() > alpha.length()){
				if (TestSequence.isProperPrefixOf(alpha, seq))
					ret.add(seq);
			}			
		}
		return ret;
	}
	
	public ArrayList<String> getCommonSufix(String alpha, String beta,
			ArrayList<String> alphaExt, ArrayList<String> betaExt) {
		ArrayList<String> ret = new ArrayList<String>();

		for (String seq1 : alphaExt) {
			String gamma = TestSequence.getSuffixFrom(seq1, alpha);
			for (String seq2 : betaExt) {
				String gamma2 = TestSequence.getSuffixFrom(seq2, beta);
				if (gamma.equals(gamma2))
					ret.add(gamma);
			}
		}
		return ret;
	}
	
	public void step03a(Map<String, ArrayList<String>> C, Pair p) {		
		if(HashList.add_pair_hash(C, p.getLeft(), p.getRight())){
			HashList.add_pair_hash(C, p.getRight(), p.getLeft());
			ruler.applyRules5(p, AddedTo.C);
		}
	}
	
	public Pair step04a(String fi, ArrayList<String> K, Map<String, ArrayList<String>> D,
			Map<String, ArrayList<String>> C, ArrayList<String> T) {
	
		String chi = findChi(K, fi);
		for (String upsilon : TestSet.minus(K, chi)) {			
			if(!HashList.pair_hash_in(D,upsilon, fi))
			{
				ArrayList<String> Cupsilon = HashList.getPartition(upsilon, C);
				ArrayList<String> Cfi = HashList.getPartition(fi, C); 
			
				String alpha = Cupsilon.get(0);
				String beta = Cfi.get(0);

				CostTuple tuple = selectGamma2(alpha, beta, T, C);
				String gamma = tuple.getGamma();
				alpha = tuple.getAlpha();
				beta = tuple.getBeta();

				if (gamma != null) {
					String seq1 = TestSequence.concat(alpha, gamma);
					String seq2 = TestSequence.concat(beta, gamma);

					TestSet.addAllPrefsOf(T, seq1);
					TestSet.addAllPrefsOf(T, seq2);
					ArrayList<String> new_tests = new ArrayList<String>();
					new_tests.addAll(TestSequence.getAllPrefixesFrom(seq1));
					new_tests.addAll(TestSequence.getAllPrefixesFrom(seq2));
					
					updateC2(new_tests, C);
				
					Pair p_alphabeta = new Pair(alpha, beta);
					if (addD3Pair2(gamma, D, alpha, beta)) {
						ruler.applyRules5(p_alphabeta, AddedTo.D); 
					}					
				}
			}
		}
		return new Pair(fi, chi);
	}
	
	public Pair findFiChi3(ArrayList<String> T, ArrayList<String> CunionK,
			ArrayList<String> K, Map<String, ArrayList<String>> D) {		
		for (String fi : TestSet.minus(T, CunionK)) {				
			for (String chi : K) {				
				boolean in = true;				
				for (String upsilon : TestSet.minus(K, chi)) {					
					if (!HashList.pair_hash_in(D,fi, upsilon)){
						in = false;
						break;
					}
				}
				if (in && isConvergent(fi, chi))
					return new Pair(fi, chi);
			}
		}
		return null;
	}
	
	public ArrayList<String> findCunionK2(Map<String, ArrayList<String>> C, ArrayList<String> K) {
		ArrayList<String> ret = new ArrayList<String>();
		
		for(String k : K){
			if(C.get(k)!=null){
				for(String a : C.get(k)){
					if(!ret.contains(a)){
						ret.add(a);
					}
				}				
			}
		}
		return ret;
	}
	
	public boolean indentify_all(ArrayList<String> T, ArrayList<String> K){
		TestSuite aux = new TestSuite();
		ArrayList<String> min_rel = new ArrayList<String>();
		ArrayList<String> G = new ArrayList<String>();
		for(Transition t: fsm.getTransitions()){
			int min = -1;
			ArrayList<String> min_pre_tests = new ArrayList<String>();
			cuk:for(String test : CunionK){	
				ArrayList<Transition> current = fsm.reachedTransitionsWithSequence(fsm.getInitialState(), test);			
				if(current.size() != 0){
					Transition t1 = current.get(current.size() - 1); //get the last	
					if(t.equals(t1)){
						String x = t.getInput();
						String alp = TestSequence.getPrefixFrom(test, x);
						ArrayList<String> pre_test = new ArrayList<String>();
						pre_test.add(alp);
						pre_test.add(test);						
						if(CunionK.contains(alp)){
							ArrayList<String> temp_rel = new ArrayList<String>();
							temp_rel.addAll(Relative);				
							int before = aux.find_T_size(Relative);
							for(String alpha: pre_test){
								//find the increment for Relative
								String fi = alpha;
								String chi = findChi(K, fi);
																
								if(!identify_rules(fi, chi, K)){
									continue cuk;
								}																															
							}
							ArrayList<String> temp_result = new ArrayList<String>();
							Relative = TestSequence.getNoPrefixes(Relative);
							temp_result.addAll(Relative);
							int after = aux.find_T_size(Relative);
							Relative = new ArrayList<String>();
							Relative.addAll(temp_rel);
							int tsize = after - before;
							
							//put the small local increment on top
							if(min < 0 || tsize < min){
								min = tsize;
								min_rel = temp_result;
								min_pre_tests = pre_test;
							}												
						}
					}
				}				
			}
			if(min_pre_tests.size() == 0){
				System.out.println("ERROR transition "+t);
				return false;
			}
			Relative = new ArrayList<String>();
			Relative.addAll(min_rel);
			G.addAll(min_pre_tests);
		}							
		FsmCoverage coverage = new FsmCoverage(fsm);
		if(print_debug)System.out.println("coverage get-C_D: "
				+ coverage.transitionCoverage(G));
		
		if(coverage.transitionCoverage(G) < 1){
			return false;
		}	
		return true;
	}
	
	public Map<Transition, ArrayList<String>> indentify_all_old(ArrayList<String> T, ArrayList<String> K){		
		Map<Transition, ArrayList<String>> requirement = new HashMap<Transition, ArrayList<String>>();	
		
		TestSuite aux = new TestSuite();
		ArrayList<String> min_rel = new ArrayList<String>();
		ArrayList<String> incr_rel = new ArrayList<String>();
		incr_rel.addAll(Relative);		
		for(Transition t: fsm.getTransitions()){
			int min = -1;			
			for(String test : CunionK){	
				ArrayList<Transition> current = fsm.reachedTransitionsWithSequence(fsm.getInitialState(), test);			
				if(current.size() != 0){
					Transition t1 = current.get(current.size() - 1); //get the last	
					if(t.equals(t1)){
						String x = t.getInput();
						String alpha = TestSequence.getPrefixFrom(test, x);
						if(CunionK.contains(alpha)){
							ArrayList<String> temp_rel = new ArrayList<String>();
							temp_rel.addAll(incr_rel);				
							int before = aux.find_T_size(temp_rel);
							
							//find the increment for Relative
							String fi = test;
							String chi = findChi(K, fi);				
							for (String upsilon : TestSet.minus(K, chi)) {					
								if(HashList.pair_hash_in(D,upsilon, fi)){
									if(D3.get(fi)!=null){
										for(String[] nd3 : D3.get(fi)){
											if(nd3[0].equals(upsilon) && !nd3[1].startsWith("rule")){
												String figamma = TestSequence.concat(fi, nd3[1]);
												String upgamma = TestSequence.concat(upsilon, nd3[1]);									
												temp_rel.add(figamma);
												temp_rel.add(upgamma);
											}
										}
									}
								}
							}
							temp_rel = TestSequence.getNoPrefixes(temp_rel);
							int after = aux.find_T_size(temp_rel);
							int tsize = after - before;
							
							//put the small local increment on top
							if(min < 0 || tsize < min){
								min = tsize;
								min_rel = temp_rel;
								if(requirement.keySet().contains(t)){
									requirement.get(t).add(0,test);
								}else{
									ArrayList<String> list = new ArrayList<String>();
									list.add(0,test);
									requirement.put(t, list);
								}
							}						
						}
					}
				}				
			}
			incr_rel = min_rel;
		}							
		FsmCoverage coverage = new FsmCoverage(fsm);
		if(print_debug)System.out.println("coverage get-C_D: "
				+ coverage.transitionCoverage(CunionK));
		
		if(coverage.transitionCoverage(CunionK) < 1){
			return null;
		}		
		return requirement;	
	}
		
	public HashMap<String, ArrayList<String>> getTSeparatedTestPairs5(ArrayList<String> T) {
		HashMap<String, ArrayList<String>> ret = new HashMap<String, ArrayList<String>>();	
		HashMap<String, ArrayList<String>> gamma_list = new HashMap<String, ArrayList<String>>();	
		ArrayList<String> T2 = new ArrayList<String>();
		T2.addAll(T);	
		for (String alpha : T) {
			T2.remove(alpha);
			beta:for (String beta : T2) {
				if (!alpha.equals(beta)) {
					State sa = fsm.nextStateWithSequence(
							fsm.getInitialState(), alpha);
					State sb = fsm.nextStateWithSequence(
							fsm.getInitialState(), beta);
					if(!sa.equals(sb)){						
						ArrayList<String> gamma_a = new ArrayList<String>();
						ArrayList<String> gamma_b = new ArrayList<String>();
						if(gamma_list.containsKey(alpha)){
							gamma_a = gamma_list.get(alpha);
						}
						if(gamma_list.containsKey(beta)){
							gamma_b = gamma_list.get(beta);
						}
						if(gamma_a.size() > 0 && gamma_b.size() > 0){
							for(String ga : gamma_a){
								if(addD3Pair(gamma_b,ga,sa,sb,ret,alpha,beta)){
									continue beta;
								}								
							}
						}						
						for (String ext : T) {
							String ga = "";
							String gb = "";
							if(ext.length() > alpha.length()){
								if (TestSequence.isProperPrefixOf(alpha, ext)){
									ga = TestSequence.getSuffixFrom(ext, alpha);
									gamma_a.add(ga);
									gamma_list.put(alpha, gamma_a);
									if(addD3Pair(gamma_b,ga,sa,sb,ret,alpha,beta)){
										break;
									}								
								}
							}			
							if(ext.length() > beta.length()){
								if (TestSequence.isProperPrefixOf(beta, ext)){
									gb = TestSequence.getSuffixFrom(ext, beta);
									gamma_b.add(gb);
									gamma_list.put(beta, gamma_b);
									if(addD3Pair(gamma_a,gb,sa,sb,ret,alpha,beta)){
										break;
									}								
								}
							}										
						}
					}					
				}
			}
		}
		return ret;
	}
	
	public boolean addD3Pair2(String gamma,
			Map<String, ArrayList<String>> d2, String alpha, String beta){
		
		boolean add = HashList.add_pair_hash(d2, alpha, beta);
		HashList.add_triple_hash(D3, alpha, beta, gamma);
		HashList.add_pair_hash(d2, beta, alpha);
		HashList.add_triple_hash(D3, beta, alpha, gamma);
			
		return add;
	}
	
	public boolean addD3Pair(ArrayList<String> gamma_a, String gb, State sa, State sb,
			HashMap<String, ArrayList<String>> ret, String alpha, String beta){
		if(gamma_a.contains(gb)){								
			if(fsm.separe(gb, sa, sb)) {
				HashList.add_pair_hash(ret, alpha, beta);
				HashList.add_triple_hash(D3, alpha, beta, gb);
				HashList.add_pair_hash(ret, beta, alpha);
				HashList.add_triple_hash(D3, beta, alpha, gb);
				return true;
			}
		}
		return false;
	}
	
	private HashMap<String, ArrayList<String>> getIdentityRelation2(ArrayList<String> T) {
		HashMap<String, ArrayList<String>> ret = new HashMap<String, ArrayList<String>>();
		ArrayList<String> arr = null;
		for (String test : T){
			arr = new ArrayList<String>();
			arr.add(test);			
			if(ret.get(test)==null){
				ret.put(test, arr);
			}	
		}
		return ret;
	}
	
	public void step02c(ArrayList<String> T, Map<String, ArrayList<String>> C,
			Map<String, ArrayList<String>> D, ArrayList<String> K) {
		
		String alpha = selectAlpha(K);
		for (String beta : K) {						
			if(!HashList.pair_hash_in(D,alpha,beta)){									
				CostTuple tuple = selectGamma2(alpha, beta, T, C);
				String gamma = tuple.getGamma();
				alpha = tuple.getAlpha();
				beta = tuple.getBeta();				
								
				String seq1 = TestSequence.concat(alpha, gamma);
				String seq2 = TestSequence.concat(beta, gamma);
				
				TestSet.addAllPrefsOf(T, seq1);
				TestSet.addAllPrefsOf(T, seq2);
				ArrayList<String> new_tests = new ArrayList<String>();
				new_tests.addAll(TestSequence.getAllPrefixesFrom(seq1));
				new_tests.addAll(TestSequence.getAllPrefixesFrom(seq2));
				
				updateC2(new_tests, C);
			
				Pair p_alphabeta = new Pair(alpha, beta);
				if (addD3Pair2(gamma, D, alpha, beta)) {
					ruler.applyRules5(p_alphabeta, AddedTo.D); 
				}
			}
		}
		K.add(alpha);		
	}
	
	private void updateC2(ArrayList<String> T, Map<String, ArrayList<String>> C) {
		for (String test : T) {			
			if(C.get(test)==null){
				ArrayList<String> arr = new ArrayList<String>();
				arr.add(test);
				C.put(test, arr);
			}
		}
	}
	
	public CostTuple selectGamma2(String alpha, String beta,
			ArrayList<String> T, Map<String, ArrayList<String>> C) {
		CharacterizationSetConstructor csc = new CharacterizationSetConstructor();
		csc.setFsm(fsm);		
		return csc.getDistinguishSequence2(alpha, beta, T, C);
	}
	
	public String selectAlpha(ArrayList<String> K) {
		if (!K.contains(TestSequence.EPSILON)) {
			ArrayList<String> K_l = new ArrayList<String>(K); // clone
			K_l.add(TestSequence.EPSILON);

			if (isM_Divergent(K_l))
				return TestSequence.EPSILON;
		}

		for (int i = 1; i <= 1000; i++) {
			for (String seq : getInputSeqWithLength(i)) {
				if (fsm.isDefinedSeq(seq, fsm.getInitialState())
						&& !K.contains(seq)) {
					ArrayList<String> K_l = new ArrayList<String>(K); // clone
					K_l.add(seq);

					if (isM_Divergent(K_l))
						return seq;
				}
			}
		}
		return null;
	}
	
	public String findChi(ArrayList<String> K, String fi) {
		for (String chi : K)
			if (isConvergent(fi, chi))
				return chi;

		return null;
	}
	
	public boolean isM_Divergent(ArrayList<String> K_l) {
		for (int i = 0; i < K_l.size() - 1; i++) {
			for (int j = i + 1; j < K_l.size(); j++) {
				String seqi = K_l.get(i);
				String seqj = K_l.get(j);
				if (i != j) {
					if (!isDivergent(seqi, seqj))
						return false;
				}
			}
		}
		return true;
	}

	public boolean isDivergent(String seqi, String seqj) {
		// two seqs are divergent if they lead the machine to different states
		State si = fsm.nextStateWithSequence(fsm.getInitialState(), seqi);
		State sj = fsm.nextStateWithSequence(fsm.getInitialState(), seqj);
		if (si != sj)
			return true;

		return false;
	}

	public boolean isConvergent(String seqi, String seqj) {
		// two seqs are convergent if they lead the machine to the same states
		State si = fsm.nextStateWithSequence(fsm.getInitialState(), seqi);
		State sj = fsm.nextStateWithSequence(fsm.getInitialState(), seqj);
		if (si == sj)
			return true;

		return false;
	}
	
	public ArrayList<String> getInputSeqWithLength(int k) {
		ArrayList<String> ret = new ArrayList<String>();
		HashSet<String> Li = fsm.getInputAlphabet();

		for (String in : Li)
			ret.add(in);

		for (int i = 2; i <= k; i++) {
			ArrayList<String> temp = new ArrayList<String>();
			for (String seq : ret)
				for (String in : Li)
					temp.add(seq + "," + in);

			ret = temp;
		}
		return ret;
	}
	
}
