package br.usp.icmc.fsm.common;

import java.util.ArrayList;

public class CostTuple 
{
	private String gamma, alpha, beta;
	int alphacost, betacost;
	private ArrayList<String> t_set;
	
	public String getGamma() {
		return gamma;
	}
	public void setGamma(String gamma) {
		this.gamma = gamma;
	}
	public String getAlpha() {
		return alpha;
	}
	public void setAlpha(String alpha) {
		this.alpha = alpha;
	}
	public String getBeta() {
		return beta;
	}
	public void setBeta(String beta) {
		this.beta = beta;
	}
	public int getAlphacost() {
		return alphacost;
	}
	public void setAlphacost(int alphacost) {
		this.alphacost = alphacost;
	}
	public int getBetacost() {
		return betacost;
	}
	public void setBetacost(int betacost) {
		this.betacost = betacost;
	}
	public ArrayList<String> getT() {
		return t_set;
	}
	public void setT(ArrayList<String> T) {		
		this.t_set = new ArrayList<String>();
		this.t_set.addAll(T);
	}
}
