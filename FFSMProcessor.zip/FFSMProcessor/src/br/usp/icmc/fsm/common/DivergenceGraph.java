package br.usp.icmc.fsm.common;

import java.util.ArrayList;
import java.util.Map;

import br.usp.icmc.fsm.common.Pair;
import br.usp.icmc.fsm.common.Ruler.AddedTo;

public class DivergenceGraph 
{
	ArrayList<String> T;
	ArrayList<Pair> D;
	ArrayList<String> K;
	Map<String, ArrayList<String>> D2;
	int n;
	
	public DivergenceGraph(ArrayList<String> T, ArrayList<Pair> D, int n) 
	{
		this.T = T;
		this.D = D;
		this.n = n;
		build();
	}
	
	public DivergenceGraph(ArrayList<String> T, Map<String, ArrayList<String>> D, int n) 
	{
		this.T = T;
		this.D2 = D;
		this.n = n;
		build2();
	}

	private void build() 
	{
		//build the graph
		Graph graph = new Graph();		
		for(String test : T)
		{
			graph.addNode(test);
		}
		
		//arcs		
		for(Pair pair : D)
		{
			graph.addArc(pair.getLeft(), pair.getRight());
		}
		
		//ArrayList<String> clique = graph.getMaxClique(n);
		ArrayList<String> clique = graph.getMaxCliqueV2(n);
		K = clique;
	}
	
	private void build2() 
	{
		//build the graph
		Graph graph = new Graph();		
		for(String test : T)
		{
			graph.addNode(test);
		}
		
		//arcs
		for (String a : D2.keySet()) {
			for (String b : D2.get(a)) {				
				graph.addArc(a, b);	
			}			
		}		
		
		//ArrayList<String> clique = graph.getMaxClique(n);
		ArrayList<String> clique = graph.getMaxCliqueV2(n);
		K = clique;
	}

	public ArrayList<String> getK() 
	{
		return K;
	}

}
