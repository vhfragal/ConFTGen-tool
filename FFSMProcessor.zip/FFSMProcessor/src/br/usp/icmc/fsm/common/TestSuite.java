package br.usp.icmc.fsm.common;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import br.usp.icmc.fsm.constructor.PCompleteTestGenerator2;
import br.usp.icmc.fsm.constructor.PCompleteTestGenerator3;


public class TestSuite {

	public TestSuite(){
		
	}
	
	ArrayList<String> reduced_suite_P = new ArrayList<String>();
	public ArrayList<String> get_reduced_suite_P(){
		return reduced_suite_P;
	}
	
	public ArrayList<String> generate_reduced_suite_P(FiniteStateMachine fsm,
			String file_in, boolean is_empty_input, boolean debug) throws IOException, InterruptedException{
			
		PCompleteTestGenerator3 generator = new PCompleteTestGenerator3(fsm, debug);		
		File file_T = new File(file_in);			
		TestSuiteReader reader_T = new TestSuiteReader(file_T, true);
		
		ArrayList<String> initialTestSet = new ArrayList<String>();
		//set incremental no prefix input
		for (String testseq : reader_T.getTestSuite()) {
			if (fsm.isDefinedSeq(testseq, fsm.getInitialState())) {
				TestSet.addAllPrefsOf(initialTestSet, testseq);				
			} else {
				System.out.println("A sequencia de teste \"" + testseq
						+ "\" não é definida na FSM");
			}
		}
		generator.setInitialTestSet(initialTestSet);		
		ArrayList<String> result_P_min = generator.process_reduced_suite();
		return result_P_min;
	}
	
	public ArrayList<String> generate_suite_P_2(FiniteStateMachine fsm,
			String file_in, boolean is_empty_input) throws IOException, InterruptedException{
		
		int min_size = 0;		
		ArrayList<String> min_result_P = new ArrayList<String>(); 
		//for(int j=0;j<10;j++){
			PCompleteTestGenerator2 generator = new PCompleteTestGenerator2(fsm);
			if(!is_empty_input) set_initial_set(file_in, generator, fsm);			
			ArrayList<String> result_P = generator.generate_random(is_empty_input);			
			int size = find_T_size(result_P);
			//if(j==0) {
				min_size = size;
				min_result_P = result_P;
			//}
			//if(size < min_size) {
			//	min_size = size;				
			//	min_result_P = result_P;
			//}				
		//}
		generator = new PCompleteTestGenerator2(fsm);
		ArrayList<String> initialTestSet = new ArrayList<String>();
		for (String testseq : min_result_P) {
			TestSet.addAllPrefsOf(initialTestSet, testseq);	
		}
		generator.setInitialTestSet(initialTestSet);
		ArrayList<String> result_P_min = generator.get_retest_set();
		return result_P_min;
	}

	public ArrayList<String> mef_no_comma(FiniteStateMachine fsm){
		
		String in_alp = fsm.getInputAlphabet().toString();
		in_alp = in_alp.substring(1, in_alp.length()-1);
		String[] test = in_alp.split(", ");
		String[] alp = {"a","b","c","d","e","f","g","h","i","j","l"};
		ArrayList<String> MEF_no = new ArrayList<String>();
		ArrayList<Transition> trans = fsm.getTransitions();
		for(Transition t:trans){
			//System.out.println(t);
			String aux = "";
			String[] in = t.toString().split("--");
			String[] in2 = in[1].split("/");
			//System.out.println("Composed "+in[0]+"--"+in2[0]+"/"+in2[1]);
			for(int a=0; a<test.length; a++){
				String t1 = test[a];						
				if(t1.equals(in2[0])){
					aux = in[0]+"--"+alp[a]+"/"+in2[1];
					break;
				}
			}
			MEF_no.add(aux);
		}
		return MEF_no;
	}
	
	public ArrayList<String> con_no_comma(FiniteStateMachine fsm, ArrayList<String> result_P){
		//System.out.println(fsm.getInputAlphabet());
		String in_alp = fsm.getInputAlphabet().toString();
		in_alp = in_alp.substring(1, in_alp.length()-1);
		String[] test = in_alp.split(", ");
		String[] alp = {"a","b","c","d","e","f","g","h","i","j","l"};
		ArrayList<String> P_no = new ArrayList<String>();
		
		for(String p: result_P){
			String[] res = p.split(",");
			String aux = "";
			for(String r: res){
				for(int a=0; a<test.length; a++){
					String t = test[a];						
					if(t.equals(r)){
						aux=aux.concat(alp[a]);
						break;
					}
				}					
			}
			P_no.add(aux);
		}
		return P_no;		
	}
	
	public String concat_result(ArrayList<String> result_P){
		String out = "";
		for (int i = 0; i < result_P.size(); i++) {			
			out = out.concat(result_P.get(i) + "\n");
		}
		return out;
	}
	
	public int find_T_size(ArrayList<String> T){
		int size = 0;
		for(String t : TestSequence.getNoPrefixes(T)){
			String[] data = t.split(",");
			size += data.length;
			size++;
		}
		return size;
	}
	
	public void print_file(String out, String path) throws IOException{
		File file3 = new File(path);
		if(!file3.exists()){
			file3.createNewFile();
		}
		FileWriter w = new FileWriter(file3);
		w.write(out);
		w.close();
	}
	
	public void set_initial_set(String file, PCompleteTestGenerator2 generator,
			FiniteStateMachine fsm){
		File file_T = new File(file);			
		TestSuiteReader reader_T = new TestSuiteReader(file_T, true);
		
		ArrayList<String> initialTestSet = new ArrayList<String>();
		//set incremental no prefix input
		for (String testseq : reader_T.getTestSuite()) {
			if (fsm.isDefinedSeq(testseq, fsm.getInitialState())) {
				TestSet.addAllPrefsOf(initialTestSet, testseq);				
			} else {
				System.out.println("A sequencia de teste \"" + testseq
						+ "\" não é definida na FSM");
			}
		}
		generator.setInitialTestSet(initialTestSet);
	}
	
	public void compare(String f1, String f2, FileWriter w, FileWriter w2, FileWriter w3) throws IOException 
	{				
		File file1 = new File(f1);
		File file2 = new File(f2);	
		
		TestSuiteReader reader_1 = new TestSuiteReader(file1, true);
		TestSuiteReader reader_2 = new TestSuiteReader(file2, true);
		
		ArrayList<String> r1 = new ArrayList<String>();
		ArrayList<String> r2 = new ArrayList<String>();
		for (String testseq : reader_1.getTestSuite()) {
			TestSet.addAllPrefsOf(r1, testseq);
		}
		for (String testseq : reader_2.getTestSuite()) {
			//TestSet.addAllPrefsOf(r2, testseq);
			r2.add(testseq);
		}
		
		ArrayList<String> new_ts = new ArrayList<String>();
		//ArrayList<String> obsolete = new ArrayList<String>();
		ArrayList<String> retest = new ArrayList<String>();
		
		Map<String, String> comp = new HashMap<String, String>();		
		for(String s2: r2){
			for(String s1 : r1){
				if(s1.equals("EPSILON"))continue;
				if(s1.equals(s2)) {
					comp.put(s2, s1);
					break;
				}
				if(TestSequence.isPrefixOf(s1, s2)){
					if(comp.containsKey(s2)){
						if(comp.get(s2).length() < s1.length()){
							comp.put(s2, s1);
						}
					}else comp.put(s2, s1);					
				}
			}
			if(!comp.containsKey(s2)) comp.put(s2, "");
		}
		for(String s: comp.keySet()){
			if(!retest.contains(comp.get(s)) && !comp.get(s).equals("")) retest.add(comp.get(s));			
			if(!s.equals(comp.get(s))) new_ts.add(s+ " -> "+comp.get(s)+"\n");			
		}		
		for(String s: TestSequence.getNoPrefixes(retest)){
			w3.write(s+"\n");			
		}
		for(String s: new_ts){
			w2.write(s);
		}
		
		w.close();
		w2.close();
		w3.close();
		
	}
	
	public void refine(String f1, String f2, FileWriter w, FileWriter w2, FileWriter w3) 
	{				
		File file1 = new File(f1);
		File file2 = new File(f2);		
				
		boolean found = false;
		try 
		{			
			ArrayList<String> equal = new ArrayList<String>();
			ArrayList<String> diff = new ArrayList<String>();
			ArrayList<Pair> prefix = new ArrayList<Pair>();
			ArrayList<Pair> sufix = new ArrayList<Pair>();
			
			BufferedReader reader2 = new BufferedReader(new FileReader(file2));
			String line2 = "";
			while((line2 = reader2.readLine()) != null)
			{
				BufferedReader reader1 = new BufferedReader(new FileReader(file1));
				String line1 = "";
				while((line1 = reader1.readLine()) != null){
					if(line1.equals(line2)){
						found = true;
						equal.add(line2);
						break;
					}
					if(TestSequence.isPrefixOf(line2, line1)){
						found = true;
						Pair o = new Pair(line2, line1);
						prefix.add(o);
					}
					if(TestSequence.isPrefixOf(line1, line2)){
						found = true;
						Pair o = new Pair(line2, line1);
						sufix.add(o);
					}
				}
				if(!found){
					//System.out.println(line2);
					diff.add(line2);
				}
				found = false;
				reader1.close();
			}			
			reader2.close();
			//System.out.println("Diff-----file2 - file1");
			w.write("Diff-----file2 - file1\n");
			for(int i=0;i<diff.size();i++){
				//System.out.println(diff.get(i));
				w.write(diff.get(i)+"\n");
				w2.write(diff.get(i)+"\n");
			}
			//System.out.println("Equal-----");
			w.write("Equal-----\n");
			for(int i=0;i<equal.size();i++){
				//System.out.println(equal.get(i));
				w.write(equal.get(i)+"\n");
				w3.write(equal.get(i)+"\n");
			}
			//System.out.println("Prefix-----file2 -> file1");
			w.write("Prefix-----file2 -> file1\n");
			for(int i=0;i<prefix.size();i++){
				//System.out.println(prefix.get(i).getLeft() + " -> " + prefix.get(i).getRight());
				w.write(prefix.get(i).getLeft() + " -> " + prefix.get(i).getRight()+"\n");
				w3.write(prefix.get(i).getLeft()+"\n");
			}
			//System.out.println("Sufix-----file2 -> file1");
			w.write("Sufix-----file2 -> file1\n");
			for(int i=0;i<sufix.size();i++){
				//System.out.println(sufix.get(i).getLeft() + " -> " + sufix.get(i).getRight());
				w.write(sufix.get(i).getLeft() + " -> " + sufix.get(i).getRight()+"\n");
				w2.write(sufix.get(i).getLeft() + " -> " + sufix.get(i).getRight()+"\n");
			}
			w.close();
			w2.close();
			w3.close();
		} 		
		catch (Exception e) 
		{
			e.printStackTrace();
		}		
	}
	
	public void merge(String f1, String f2, FileWriter w) throws IOException 
	{				
		
		String out = "";		
		File file1 = new File(f1);
		File file2 = new File(f2);
		
		out = merge(file1,file2);			
		w.write(out);
		w.close();
		
	}
	
	public String merge(File file1, File file2) 
	{		
		String out = "";
		boolean found = false;
		try 
		{
			BufferedReader reader2 = new BufferedReader(new FileReader(file2));
			String line2 = "";
			while((line2 = reader2.readLine()) != null)
			{
				BufferedReader reader1 = new BufferedReader(new FileReader(file1));
				String line1 = "";
				while((line1 = reader1.readLine()) != null){
					if(line1.equals(line2) || (TestSequence.isPrefixOf(line2, line1))){
						found = true;
						break;
					}					
				}
				if(!found){
					//System.out.println(line2);
					out = out.concat(line2 + "\n");
				}
				found = false;
				reader1.close();
			}			
			reader2.close();
			
			found = false;
			System.out.println(out + "\n");
			
			BufferedReader reader1 = new BufferedReader(new FileReader(file1));
			String line1 = "";
			while((line1 = reader1.readLine()) != null){
				//System.out.println(line1);
				
				reader2 = new BufferedReader(new FileReader(file2));
				line2 = "";
				while((line2 = reader2.readLine()) != null){
					if(TestSequence.isProperPrefixOf(line1, line2)){
						found = true;
						break;				
					}
				}
				if(!found){					
					out = out.concat(line1 + "\n");
				}
				found = false;
				reader2.close();				
			}			
			reader1.close();
			System.out.println(out + "\n");
		} 		
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return out;
	}
	
	public FileWriter get_file_writer(String file) throws IOException{
		File file3 = new File(file);
		if(!file3.exists()){
			file3.createNewFile();
		}
		return new FileWriter(file3);		
	}
	
	public int new_test_size(String file) throws IOException{
		
		BufferedReader reader1 = new BufferedReader(new FileReader(file));		
		String line1 = "";
		
		int count = 0;
		//ArrayList<String> repeated_prefix = new ArrayList<String>();
				
		while((line1 = reader1.readLine()) != null){
			String sub = line1;	
			String pre = "";
			if(!line1.equals("")){
				if(line1.indexOf("->") > 0){
					sub = line1.substring(0,line1.indexOf("->"));			
					pre = line1.substring(line1.indexOf("->")+3, line1.length());
					String ex = TestSequence.getSuffixFrom(sub, pre);
					String[] data = ex.split(",");				
					count = count + data.length;
					/*if(pre.length()>0){						
						if(repeated_prefix.contains(pre)){							
							count++;
						}else repeated_prefix.add(pre);
					}else count++;
					*/
				}else{
					String[] data = sub.split(",");				
					if(data.length >= 1){
						count++;
					}
					count = count + data.length;
				}
			}			
		}		
		reader1.close();
		/*
		for(String pre: repeated_prefix){
			for(String pre2: repeated_prefix){
				if(!pre.equals(pre2) && TestSequence.isPrefixOf(pre, pre2)){
					count++; break;
				}
			}			
		}*/	
		return count;
		
	}
	
	public int old_test_size(String file) throws IOException{
		
		BufferedReader reader1 = new BufferedReader(new FileReader(file));
		String line1 = "";
		
		int count = 0;
		
		while((line1 = reader1.readLine()) != null){
			String sub = line1;	
			String pre = "";
			if(!line1.equals("")){
				if(line1.indexOf("->") > 0){
					sub = line1.substring(0,line1.indexOf("->"));			
					pre = line1.substring(line1.indexOf("->")+3, line1.length());
					String ex = TestSequence.getSuffixFrom(sub, pre);
					String[] data = ex.split(",");				
					count = count + data.length;
				}else{
					String[] data = sub.split(",");				
					if(data.length >= 1){
						count++;
					}
					count = count + data.length;
				}
			}			
		}		
		reader1.close();
		return count;
		
	}
	
	public ArrayList<String> copy_suite_file(String file_in, String file_out) throws IOException{
		
		File file_pre0 =  new File(file_in);
		TestSuiteReader reader_T0 = new TestSuiteReader(file_pre0, true);
		ArrayList<String> initialTestSet0 = new ArrayList<String>();
		for (String t : reader_T0.getTestSuite()) {
			initialTestSet0.add(t);
		}
		String def_out0 = concat_result(initialTestSet0);
		print_file(def_out0,file_out);
		
		return initialTestSet0;
	}
	
	public String print_f(File file1) 
	{			
		String out = "";
		try 
		{
			BufferedReader reader1 = new BufferedReader(new FileReader(file1));
			String line1 = "";
			while((line1 = reader1.readLine()) != null){
				//System.out.println(line1);
				if(line1.length()>0){
					out = out.concat(line1 + "\n");
				}				
			}
			
			reader1.close();
		} 		
		catch (Exception e) 
		{
			e.printStackTrace();
		}		
		return out;
	}
}
