package br.usp.icmc.model_gen;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import br.usp.icmc.fsm.common.FileHandler;

public class FFeatureModel {
	String clause;
	ArrayList<String> features_list;

	public void gen_FM(String folder, int amount) throws IOException{
		
		for(int k=1; k<=amount; k++){
			String header = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n";
			
			header = header.concat("	<featureModel chosenLayoutAlgorithm=\"4\">\n");
			header = header.concat("		<struct>\n");
			header = header.concat("			<and mandatory=\"true\" name=\"Root [f0]\">\n");
			
			String clause = "";
			for(int i=1; i<=k; i++){
				clause = clause.concat("				<feature name=\"Optional [f"+i+"]\"/>\n");			
			}
			
			String bottom = "			</and>\n";
			bottom = bottom.concat("		</struct>\n");
			bottom = bottom.concat("		<constraints/>\n");
			bottom = bottom.concat("		<calculations Auto=\"true\" Constraints=\"true\" Features=\"true\" Redundant=\"true\" Tautology=\"true\"/>\n");
			bottom = bottom.concat("		<comments/>\n");
			bottom = bottom.concat("		<featureOrder userDefined=\"false\"/>\n");
			bottom = bottom.concat("	</featureModel>\n");
			
			String prop_aux = header.concat(clause);
			prop_aux = prop_aux.concat(bottom);
			
			String path = "./"+folder+"/example"+k+".xml";
			FileHandler fh = new FileHandler();
			fh.print_file(prop_aux, path);
		}
		
	}
	
	public void gen_FM_best(String folder, int amount) throws IOException{
		
		for(int k=1; k<=amount; k++){
			String header = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n";
			
			header = header.concat("	<featureModel chosenLayoutAlgorithm=\"4\">\n");
			header = header.concat("		<struct>\n");
			header = header.concat("			<and mandatory=\"true\" name=\"Root [f0]\">\n");
			
			String clause = "";
			String pre = "				";
			for(int i=1; i<=k; i++){
				if(i == k){
					clause = clause.concat(pre+"<feature name=\"Optional [f"+i+"]\"/>\n");
				}else{
					clause = clause.concat(pre+"<feature name=\"Optional [f"+i+"]\">\n");
				}				
				pre = pre.concat("	");
			}
			for(int i=k; i>1; i--){
				pre = pre.substring(0,pre.length()-1);
				clause = clause.concat(pre+"</feature>\n");
			}
			
			String bottom = "			</and>\n";
			bottom = bottom.concat("		</struct>\n");
			bottom = bottom.concat("		<constraints/>\n");
			bottom = bottom.concat("		<calculations Auto=\"true\" Constraints=\"true\" Features=\"true\" Redundant=\"true\" Tautology=\"true\"/>\n");
			bottom = bottom.concat("		<comments/>\n");
			bottom = bottom.concat("		<featureOrder userDefined=\"false\"/>\n");
			bottom = bottom.concat("	</featureModel>\n");
			
			String prop_aux = header.concat(clause);
			prop_aux = prop_aux.concat(bottom);
			
			String path = "./"+folder+"/example"+k+".xml";
			FileHandler fh = new FileHandler();
			fh.print_file(prop_aux, path);
		}
		
	}
	

	public void gen_FM_mid(String folder, int amount) throws IOException{
		
		for(int k=1; k<=amount; k++){
			String header = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n";
			
			header = header.concat("	<featureModel chosenLayoutAlgorithm=\"4\">\n");
			header = header.concat("		<struct>\n");
			header = header.concat("			<and mandatory=\"true\" name=\"Root [f0]\">\n");
			
			String clause = "";
			String pre = "				";
			
			for(int i=1; i<=(k/2); i++){
				clause = clause.concat("				<feature name=\"Optional [f"+i+"]\"/>\n");			
			}
			
			for(int i=(k/2)+1; i<=k; i++){
				if(i == k){
					clause = clause.concat(pre+"<feature name=\"Optional [f"+i+"]\"/>\n");
				}else{
					clause = clause.concat(pre+"<feature name=\"Optional [f"+i+"]\">\n");
				}				
				pre = pre.concat("	");
			}
			for(int i=k; i>(k/2)+1; i--){
				pre = pre.substring(0,pre.length()-1);
				clause = clause.concat(pre+"</feature>\n");
			}			
			
			String bottom = "			</and>\n";
			bottom = bottom.concat("		</struct>\n");
			bottom = bottom.concat("		<constraints/>\n");
			bottom = bottom.concat("		<calculations Auto=\"true\" Constraints=\"true\" Features=\"true\" Redundant=\"true\" Tautology=\"true\"/>\n");
			bottom = bottom.concat("		<comments/>\n");
			bottom = bottom.concat("		<featureOrder userDefined=\"false\"/>\n");
			bottom = bottom.concat("	</featureModel>\n");
			
			String prop_aux = header.concat(clause);
			prop_aux = prop_aux.concat(bottom);
			
			String path = "./"+folder+"/example"+k+".xml";
			FileHandler fh = new FileHandler();
			fh.print_file(prop_aux, path);
		}
		
	}
	
	public void gen_FM_mid_low(String folder, int amount) throws IOException{
		
		for(int k=1; k<=amount; k++){
			String header = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n";
						
			header = header.concat("	<featureModel chosenLayoutAlgorithm=\"4\">\n");
			header = header.concat("		<struct>\n");
			header = header.concat("			<and mandatory=\"true\" name=\"Root [f0]\">\n");
			
			String clause = "";
			String pre = "				";
			
			for(int i=1; i<=(k/3); i++){
				clause = clause.concat("				<feature name=\"Optional [f"+i+"]\"/>\n");			
			}
			
			for(int i=(k/3)+1; i<=k; i++){
				if(i == k){
					clause = clause.concat(pre+"<feature name=\"Optional [f"+i+"]\"/>\n");
				}else{
					clause = clause.concat(pre+"<feature name=\"Optional [f"+i+"]\">\n");
				}				
				pre = pre.concat("	");
			}
			for(int i=k; i>(k/3)+1; i--){
				pre = pre.substring(0,pre.length()-1);
				clause = clause.concat(pre+"</feature>\n");
			}			
			
			String bottom = "			</and>\n";
			bottom = bottom.concat("		</struct>\n");
			bottom = bottom.concat("		<constraints/>\n");
			bottom = bottom.concat("		<calculations Auto=\"true\" Constraints=\"true\" Features=\"true\" Redundant=\"true\" Tautology=\"true\"/>\n");
			bottom = bottom.concat("		<comments/>\n");
			bottom = bottom.concat("		<featureOrder userDefined=\"false\"/>\n");
			bottom = bottom.concat("	</featureModel>\n");
			
			String prop_aux = header.concat(clause);
			prop_aux = prop_aux.concat(bottom);
			
			String path = "./"+folder+"/example"+k+".xml";
			FileHandler fh = new FileHandler();
			fh.print_file(prop_aux, path);
		}
		
	}
	
	public void gen_FM_random(String file_path, int amount, String[] features) throws IOException{
				
		for(int k=1; k<=amount; k++){
			String header = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n";
						
			features_list = new ArrayList<String>();
			for(String s : features){
				features_list.add(s);
			}
			
			header = header.concat("	<featureModel chosenLayoutAlgorithm=\"4\">\n");
			header = header.concat("		<struct>\n");			
			header = header.concat("			<and mandatory=\"true\" name=\"Feature_"+features[0]+
					"\">\n");
			
			clause = "";
			String pre = "				";
			features_list.remove(0);
			Random ran = new Random();					
			while(features_list.size() > 0){
				int lv_amount = ran.nextInt(features_list.size())+1;
				rec_tree_gen(pre, 1, lv_amount);
			}
						
			String bottom = "			</and>\n";
			bottom = bottom.concat("		</struct>\n");
			bottom = bottom.concat("		<constraints/>\n");
			bottom = bottom.concat("		<calculations Auto=\"true\" Constraints=\"true\" Features=\"true\" Redundant=\"true\" Tautology=\"true\"/>\n");
			bottom = bottom.concat("		<comments/>\n");
			bottom = bottom.concat("		<featureOrder userDefined=\"false\"/>\n");
			bottom = bottom.concat("	</featureModel>\n");
			
			String prop_aux = header.concat(clause);
			prop_aux = prop_aux.concat(bottom);
			
			String path = file_path+"fm_"+k+".xml";
			FileHandler fh = new FileHandler();
			fh.print_file(prop_aux, path);
		}
		
	}
	
	public void gen_single_FM_random(String file_path, String[] features, int k) throws IOException{
		
		//for(int k=1; k<=amount; k++){
			String header = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n";
						
			features_list = new ArrayList<String>();
			for(String s : features){
				features_list.add(s);
			}
			
			header = header.concat("	<featureModel chosenLayoutAlgorithm=\"4\">\n");
			header = header.concat("		<struct>\n");			
			header = header.concat("			<and mandatory=\"true\" name=\"Feature_"+features[0]+
					"\">\n");
			
			clause = "";
			String pre = "				";
			features_list.remove(0);
			Random ran = new Random();					
			while(features_list.size() > 0){
				int lv_amount = ran.nextInt((features_list.size()/2)+1)+1;
				rec_tree_gen(pre, 1, lv_amount);
			}
						
			String bottom = "			</and>\n";
			bottom = bottom.concat("		</struct>\n");
			bottom = bottom.concat("		<constraints/>\n");
			bottom = bottom.concat("		<calculations Auto=\"true\" Constraints=\"true\" Features=\"true\" Redundant=\"true\" Tautology=\"true\"/>\n");
			bottom = bottom.concat("		<comments/>\n");
			bottom = bottom.concat("		<featureOrder userDefined=\"false\"/>\n");
			bottom = bottom.concat("	</featureModel>\n");
			
			String prop_aux = header.concat(clause);
			prop_aux = prop_aux.concat(bottom);
			
			String path = file_path+"fm_"+k+".xml";
			FileHandler fh = new FileHandler();
			fh.print_file(prop_aux, path);
		//}
		
	}
	
	public void rec_tree_gen(String pre, int lv, int level_amount){		
		String[] ftype = {"and","or","alt"};
		//String[] is_optional = {"true","false"};
		String[] is_optional = {"false","false"};
		Random ran = new Random();		
		ArrayList<String> level_features = new ArrayList<String>();	
		for(int i=0; i < level_amount; i++){
			level_features.add(features_list.get(i));		
		}
		for(String s : level_features){			
			features_list.remove(s);
		}
		int next_lv_amount = level_amount;
		for(int i=0; i < level_amount; i++){			
			String type = ftype[ran.nextInt(ftype.length)];
			if(features_list.size() > 0){
				next_lv_amount = ran.nextInt(features_list.size());
			}else {
				next_lv_amount = 0;
			}			
			if(next_lv_amount <= 1) type = "feature";
			String is_opt = is_optional[ran.nextInt(is_optional.length)];
			clause = clause.concat(pre+"<"+type+" mandatory=\""+is_opt+"\" name=\"Feature_"+level_features.get(i)+
					"\">\n");
			//recursive call
			pre = pre.concat("	");
			if(next_lv_amount > 0){
				rec_tree_gen(pre, ++lv, next_lv_amount);
			}
			pre = pre.substring(0,pre.length()-1);
			clause = clause.concat(pre+"</"+type+">\n");
		}
	}
	
	
}
