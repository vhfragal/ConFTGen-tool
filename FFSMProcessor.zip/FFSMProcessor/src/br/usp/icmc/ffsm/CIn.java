package br.usp.icmc.ffsm;

import br.usp.icmc.fsm.common.State;

public class CIn {

	private String in, condition;
	
	public CIn(String in, String cond){
		this.in = in;
		this.condition = cond;
	}
	
	public String getIn() {
		return in;
	}
	public String getCond() {
		return condition;
	}
}


